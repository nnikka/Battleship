import { ActivatedRouteSnapshot, CanActivate, CanLoad, Route, Router, RouterStateSnapshot } from "@angular/router";
import { AuthService } from "../services/auth.service";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { LoginRedirectService } from "../services/login-redirect.service";

@Injectable()
export class LoginRequiredGuard implements CanActivate, CanLoad {
  constructor(private loginService: AuthService, private router: Router, private urlService: LoginRedirectService) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    return this.isAuthenticated(state.url);
  }

  canLoad(route: Route): Observable<boolean> | Promise<boolean> | boolean {
    return this.isAuthenticated(route.path);
  }

  isAuthenticated(url: string | null) {
    if (this.loginService.isAuthenticated()) {
      return true;
    } else {
      this.urlService.set(url);
      this.router.navigateByUrl("/auth/login");
      return false;
    }
  }
}
