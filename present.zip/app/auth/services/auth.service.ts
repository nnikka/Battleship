import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { UserModel } from "../models/user.model";
import { AuthResponseModel } from "../models/authResponse.model";
import { ConfigService } from "@env/service/config.service";
import { JWTHelper } from "../helpers/JWT.helper";

@Injectable()
export class AuthService {
  constructor(private http: HttpClient, private configService: ConfigService) {}

  isAuthenticated(): boolean {
    try {
      const user = this.getUser();
      return user != null && user.token !== null && user.tokenExpireDate > Date.now() / 1000;
    } catch (e) {
      return false;
    }
  }

  getAccessToken(email: string, password: string): Observable<AuthResponseModel> {
    return this.http.post<AuthResponseModel>(`${this.configService.config.apiBaseurl}/api/Auth/login`, {
      email,
      password
    });
  }

  logOut(): Observable<any> {
    return this.http.post(`${this.configService.config.apiBaseurl}/api/Auth/logout`, {});
  }

  getUser(): UserModel {
    return JSON.parse(sessionStorage.getItem("user"));
  }

  getToken(): string {
    const user = this.getUser();
    if (user != null) {
      return user.token;
    }
    return "";
  }

  getUserFullName(): string {
    const user = this.getUser();
    if (user != null) {
      return user.fullName;
    }
    return "";
  }

  getUserId(): string {
    const user = this.getUser();
    if (user != null) {
      return JWTHelper.parseJWT(user.token)["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier"];
    }
    return null;
  }

  // needs refactor
  getUserRoles(): string[] {
    const user = this.getUser();
    if (user != null) {
      return [JWTHelper.parseJWT(user.token)["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"]];
    }
    return [];
  }

  setUser(user: UserModel): void {
    sessionStorage.setItem("user", JSON.stringify(user));
  }

  clearUser(): void {
    sessionStorage.removeItem("user");
    localStorage.setItem("logoutSession", "rmsession");
    localStorage.removeItem("logoutSession");
  }
}
