import { Injectable } from "@angular/core";

@Injectable()
export class LoginRedirectService {
  exists() {
    return sessionStorage.getItem("login-redirect-url") != null;
  }

  get() {
    return sessionStorage.getItem("login-redirect-url");
  }

  set(url) {
    sessionStorage.setItem("login-redirect-url", url);
  }

  clear() {
    sessionStorage.removeItem("login-redirect-url");
  }
}
