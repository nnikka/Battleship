import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { LoginComponent } from "./components/login/login.component";
import { LogoutComponent } from "./components/logout/logout.component";
import { LoginRequiredGuard } from "./guards/login-required.guard";
import { LogoutRequiredGuard } from "./guards/logout-required.guard";

const authRoutes: Routes = [
  {
    path: "auth",
    children: [
      {
        path: "login",
        component: LoginComponent,
        canActivate: [LogoutRequiredGuard]
      },
      {
        path: "logout",
        component: LogoutComponent,
        canActivate: [LoginRequiredGuard]
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(authRoutes)],
  exports: [RouterModule]
})
export class AuthRoutingModule {}
