export class AuthResponseModel {
  token: string;
}
