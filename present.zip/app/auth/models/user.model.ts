export class UserModel {
  fullName: string;
  token: string;
  tokenExpireDate: number;
}
