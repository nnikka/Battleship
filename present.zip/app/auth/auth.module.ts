import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { LoginComponent } from "./components/login/login.component";
import { LogoutComponent } from "./components/logout/logout.component";
import { AuthRoutingModule } from "./auth-routing.module";
import { SharedModule } from "@shared/shared.module";
import { AuthService } from "./services/auth.service";
import { LoginRedirectService } from "./services/login-redirect.service";
import { LoginRequiredGuard } from "./guards/login-required.guard";
import { LogoutRequiredGuard } from "./guards/logout-required.guard";

@NgModule({
  declarations: [LoginComponent, LogoutComponent],
  imports: [CommonModule, AuthRoutingModule, SharedModule],
  providers: [AuthService, LoginRedirectService, LoginRequiredGuard, LogoutRequiredGuard]
})
export class AuthModule {}
