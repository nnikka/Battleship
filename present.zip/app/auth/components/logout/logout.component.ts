import { Component, OnInit, OnDestroy } from "@angular/core";
import { PageLoaderService } from "@components/page-loader/page-loader.service";
import { AuthService } from "../../services/auth.service";
import { NotificationMessageService } from "@core/services/notification-message.service";
import { Router } from "@angular/router";

@Component({
  selector: "app-logout",
  templateUrl: "./logout.component.html",
  styleUrls: ["./logout.component.scss"]
})
export class LogoutComponent implements OnInit, OnDestroy {
  constructor(
    private pageLoaderService: PageLoaderService,
    private authService: AuthService,
    private router: Router,
    private notificationMessageService: NotificationMessageService
  ) {}

  ngOnInit() {
    this.pageLoaderService.show();
    this.authService.logOut().subscribe(
      data => {
        this.authService.clearUser();
        this.router.navigateByUrl("/auth/login");
        this.notificationMessageService.warn("You have logged out");
      },
      error => {
        this.authService.clearUser();
        this.router.navigateByUrl("/auth/login");
        this.notificationMessageService.warn("You have logged out");
      }
    );
  }

  ngOnDestroy(): void {
    this.pageLoaderService.hide();
  }
}
