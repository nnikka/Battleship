import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { AuthService } from "../../services/auth.service";
import { LoginRedirectService } from "../../services/login-redirect.service";
import { JWTHelper } from "../../helpers/JWT.helper";
import { UserModel } from "../../models/user.model";
import { NotificationMessageService } from "@core/services/notification-message.service";
import { Router } from "@angular/router";

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.scss"]
})
export class LoginComponent implements OnInit {
  form: FormGroup;
  loading: boolean = false;

  constructor(
    private formBuilder: FormBuilder,
    private authService: AuthService,
    private loginRedirectService: LoginRedirectService,
    private router: Router,
    private notificationMessageService: NotificationMessageService
  ) {}

  ngOnInit() {
    this.form = this.formBuilder.group({
      email: ["", [Validators.required, Validators.email]],
      password: ["", [Validators.required, Validators.minLength(6)]]
    });
  }

  login(token: string) {
    const parsedJWT = JWTHelper.parseJWT(token);
    const user = new UserModel();
    user.token = token;
    user.fullName = parsedJWT.firstName + " " + parsedJWT.lastName;
    user.tokenExpireDate = parsedJWT.exp;
    this.authService.setUser(user);
    if (this.loginRedirectService.exists()) {
      const url = this.loginRedirectService.get();
      this.loginRedirectService.clear();
      this.router.navigateByUrl(url);
    } else {
      this.router.navigateByUrl("/");
    }
  }

  formSubmit() {
    this.loading = true;
    this.authService.getAccessToken(this.form.controls.email.value, this.form.controls.password.value).subscribe(
      data => {
        this.login(data.token);
        this.loading = false;
        this.notificationMessageService.success("You have logged in successfully");
      },
      error => (this.loading = false)
    );
  }
}
