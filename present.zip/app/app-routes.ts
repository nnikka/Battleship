import { ErrorComponent } from "@core/pages/error/error.component";
import { NotFoundComponent } from "@core/pages/not-found/not-found.component";
import { LoginRequiredGuard } from "@auth/guards/login-required.guard";

import { CountriesResolver } from "@core/resolvers/catalogs/countries.resolver";
import { CurrencyResolver } from "@core/resolvers/catalogs/currency.resolver";

export const appRoutes = [
  {
    path: "",
    redirectTo: "admin",
    pathMatch: "full"
  },
  {
    path: "admin",
    loadChildren: () => import("./admin/admin.module").then(m => m.AdminModule),
    canActivate: [LoginRequiredGuard],
    canLoad: [LoginRequiredGuard],
    resolve: {
      countries: CountriesResolver,
      currency: CurrencyResolver
    }
  },
  { path: "not-found", component: NotFoundComponent },
  { path: "error", component: ErrorComponent },
  { path: "**", redirectTo: "not-found" }
];
