import { Injectable } from "@angular/core";
import { LoadingBarService } from "@ngx-loading-bar/core";

@Injectable()
export class PageLoaderService {
  loading: boolean = false;

  constructor(private loadingBarService: LoadingBarService) {}

  show() {
    this.loading = true;
    this.loadingBarService.start();
  }

  hide() {
    this.loading = false;
    this.loadingBarService.stop();
  }
}
