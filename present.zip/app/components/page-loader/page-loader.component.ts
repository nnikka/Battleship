import { Component, Input } from "@angular/core";
import { PageLoaderService } from "./page-loader.service";
import { FadeInOutAnimation } from "src/app/general/animations/fadeInOut.animation";

@Component({
  selector: "app-page-loader",
  templateUrl: "./page-loader.component.html",
  styleUrls: ["./page-loader.component.scss"],
  animations: [FadeInOutAnimation]
})
export class PageLoaderComponent {
  @Input() loaderType: "Bar" | "Screen" = "Bar";

  get loading() {
    return this.pageLoaderService.loading;
  }

  constructor(private pageLoaderService: PageLoaderService) {}
}
