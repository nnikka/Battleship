import { Component } from "@angular/core";
import { PopupConfirmService } from "./popup-confirm.service";

@Component({
  selector: "app-popup-confirm",
  templateUrl: "./popup-confirm.component.html",
  styleUrls: ["./popup-confirm.component.scss"]
})
export class PopupConfirmComponent {
  get state() {
    return this.popupConfirmService.state;
  }

  get text() {
    return this.popupConfirmService.text;
  }

  get title() {
    return this.popupConfirmService.title;
  }

  constructor(private popupConfirmService: PopupConfirmService) {}

  close() {
    this.popupConfirmService.close();
  }

  confirm() {
    this.popupConfirmService.confirme();
  }
}
