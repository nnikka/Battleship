import { Injectable } from "@angular/core";

@Injectable()
export class PopupConfirmService {
  state: boolean;
  callback: any;
  noCallBalc: any;

  text: string;
  title: string;

  constructor() {}

  show(text: string, title: string, callback: any, noCallBalck?: any) {
    this.state = true;
    this.text = text;
    this.title = title;
    this.callback = callback;
    this.noCallBalc = noCallBalck;
  }

  close() {
    this.state = false;
    if (this.noCallBalc) {
      this.noCallBalc();
    }
  }

  confirme() {
    this.state = false;
    this.callback();
  }
}
