import { BrowserModule } from "@angular/platform-browser";
import { NgModule, APP_INITIALIZER } from "@angular/core";

import { AppComponent } from "./app.component";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { HttpClientModule } from "@angular/common/http";
import { AuthModule } from "@auth/auth.module";
import { RouterModule } from "@angular/router";
import { CoreModule } from "@core/core.module";
import { KendoModule } from "./kendo/kendo.module";
import { LoadingBarModule } from "@ngx-loading-bar/core";
import { FormsModule } from "@angular/forms";

import { PageLoaderComponent } from "@components/page-loader/page-loader.component";
import { PopupConfirmComponent } from "@components/popup-confirm/popup-confirm.component";

import { PopupConfirmService } from "@components/popup-confirm/popup-confirm.service";
import { PageLoaderService } from "@components/page-loader/page-loader.service";

import { ConfigService } from "@env/service/config.service";

import "hammerjs";
import { MenusModule } from "@progress/kendo-angular-menu";

export function createConfigLoader(configService: ConfigService) {
  return () => configService.load();
}

@NgModule({
  declarations: [AppComponent, PageLoaderComponent, PopupConfirmComponent],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    RouterModule,
    AuthModule,
    CoreModule,
    KendoModule,
    LoadingBarModule,
    FormsModule
  ],
  exports: [PageLoaderComponent, PopupConfirmComponent],
  bootstrap: [AppComponent],
  providers: [
    ConfigService,
    PopupConfirmService,
    PageLoaderService,
    {
      provide: APP_INITIALIZER,
      useFactory: createConfigLoader,
      deps: [ConfigService],
      multi: true
    }
  ]
})
export class AppModule { }
