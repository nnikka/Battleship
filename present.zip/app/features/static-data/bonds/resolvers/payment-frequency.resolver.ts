import { Injectable } from "@angular/core";
import { Resolve } from "@angular/router";
import { Observable } from "rxjs";
import { Store, select } from "@ngrx/store";
import { IBondsModuleState } from "../store/state";
import { selectPaymentFrequencyStatuses } from "../store/paymentFrequency/payment-frequency.selector";
import { GetPaymentFrequencies, ClearPaymentFrequency } from "../store/paymentFrequency/payment-frequency.action";
import { tap, filter, take, map } from "rxjs/operators";

@Injectable()
export class PaymentFrequencyResolver implements Resolve<boolean> {
  constructor(private store: Store<IBondsModuleState>) { }

  resolve(): Observable<boolean> {
    return this.store.pipe(
      select(selectPaymentFrequencyStatuses),
      tap((statuses: any) => {
        if (!statuses.loaded && !statuses.failed) {
          this.store.dispatch(new GetPaymentFrequencies());
        }
      }),
      filter(statuses => {
        if (statuses.loaded) { return true; } else if (statuses.failed) {
          this.store.dispatch(new ClearPaymentFrequency());
          return true;
        }
      }),
      map(statuses => {
        if (statuses.loaded) { return true; }
        return false;
      }),
      take(1)
    );
  }
}
