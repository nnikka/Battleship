import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { BondRateFormComponent } from "./bond-rate-form.component";

describe("BondRateFormComponent", () => {
  let component: BondRateFormComponent;
  let fixture: ComponentFixture<BondRateFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BondRateFormComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BondRateFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
