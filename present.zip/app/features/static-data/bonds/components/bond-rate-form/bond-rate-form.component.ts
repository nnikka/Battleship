import { Component, OnInit, Output, EventEmitter, Input } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { IBondRateFormValue } from "../../models/IBondRateFormValue";
import { IBondScheduleItem } from "../../models/IHttpBond";
import { PopupConfirmService } from "@components/popup-confirm/popup-confirm.service";
import { convertToDMY } from "src/utils/date-converter.helper";

@Component({
  selector: "app-bond-rate-form",
  templateUrl: "./bond-rate-form.component.html",
  styleUrls: ["./bond-rate-form.component.scss"]
})
export class BondRateFormComponent implements OnInit {
  form: FormGroup;
  @Output() submit: EventEmitter<IBondRateFormValue> = new EventEmitter();

  @Input() rateItem: IBondScheduleItem;

  constructor(private formBuilder: FormBuilder, private popupConfirmService: PopupConfirmService) {}

  ngOnInit() {
    let dateValue = null;
    let defaultPaymentDate = null;
    if (this.rateItem) {
      if (this.rateItem.paymentDate) {
        dateValue = convertToDMY(this.rateItem.paymentDate).toLocaleDateString();
      }
      if (this.rateItem.defaultPaymentDate) {
        defaultPaymentDate = convertToDMY(this.rateItem.defaultPaymentDate).toLocaleDateString();
      }
    }
    this.form = this.formBuilder.group({
      defaultPaymentDate: [{ value: defaultPaymentDate, disabled: true }, [Validators.required]],
      date: [{ value: dateValue, disabled: true }, [Validators.required]],
      rate: [
        this.rateItem ? this.rateItem.rate : null,
        [Validators.required, Validators.min(0.0001), Validators.max(100)]
      ]
    });
  }

  handleSubmit() {
    this.popupConfirmService.show(null, null, () => {
      this.submit.emit(this.form.getRawValue());
    });
  }
}
