import {
  Component,
  OnInit,
  Input,
  EventEmitter,
  Output,
  ChangeDetectorRef,
  ChangeDetectionStrategy,
  OnDestroy
} from "@angular/core";
import { IIssuer } from "@core/models/catalogs/issuer.interface";
import { ICurrency } from "@core/models/catalogs/currency.interface";
import { FormBuilder, FormGroup, Validators, FormControl } from "@angular/forms";
import { ECouponTypes } from "../../models/CouponTypes.enum";
import { ICouponType } from "../../models/ICouponType";
import { CustomValidators } from "src/app/general/validators/custom.validator";
import { BondFormValue } from "./BondFormValue";
import { inputSlideInOutAnimation } from "src/app/general/animations/inputSlideInOut.animation";
import { IPaymentFrequency } from "../../models/IPaymentFrequency";
import { IDayCountConvention } from "../../models/IDayCountConvention";
import { BondDateValidator, BondMinTradeAmountValidator } from "./helpers/bond-date.validator";
import { IReferenceRate } from "@core/models/catalogs/referenceRate.interface";
import { constructSelectItemsFromEnum } from "src/utils/array.helper";
import { untilDestroyed } from "ngx-take-until-destroy";

@Component({
  selector: "app-bond-form",
  templateUrl: "./bond-form.component.html",
  styleUrls: ["./bond-form.component.scss"],
  animations: [inputSlideInOutAnimation],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class BondFormComponent implements OnInit, OnDestroy {
  @Input() initialFormValue: BondFormValue;

  @Input() referenceRates: IReferenceRate[];
  @Input() issuers: IIssuer[];
  @Input() currencies: ICurrency[];
  @Input() couponType: number;
  @Input() paymentFrequencies: IPaymentFrequency[];
  @Input() dayCountConventions: IDayCountConvention[];

  @Output() formReady = new EventEmitter<FormGroup>();

  form: FormGroup;
  bondTypes: ICouponType[];

  constructor(private formBuilder: FormBuilder, private cdr: ChangeDetectorRef) {}

  ngOnInit() {
    this.bondTypes = constructSelectItemsFromEnum(ECouponTypes);
    this.form = this.formBuilder.group(
      {
        maturityDate: [this.initialFormValue ? this.initialFormValue.maturityDate : null, [Validators.required]],
        issueDate: [this.initialFormValue ? this.initialFormValue.issueDate : null, [Validators.required]],
        // firstCouponDate:
        // [this.initialFormValue ? this.initialFormValue.firstCouponDate : null, [Validators.required]],
        couponType: [
          {
            value: this.initialFormValue ? this.initialFormValue.couponType : this.couponType,
            disabled: true
          },
          [Validators.required]
        ],
        clientId: [this.initialFormValue ? this.initialFormValue.clientId : null, [Validators.required]],
        ISIN: [
          this.initialFormValue ? this.initialFormValue.ISIN : null,
          [Validators.required, CustomValidators.charactersLengthRange(12, 12)]
        ],
        // name: [this.initialFormValue ? this.initialFormValue.name : null, [Validators.required]],
        issueSize: [
          this.initialFormValue ? this.initialFormValue.issueSize : null,
          [Validators.required, Validators.min(0.000001)]
        ],
        parValue: [
          this.initialFormValue ? this.initialFormValue.parValue : null,
          [Validators.required, Validators.min(0.000001)]
        ],
        hasWithholdingTax: [
          this.initialFormValue ? this.initialFormValue.hasWithholdingTax : false,
          [Validators.required]
        ],
        minTradeAmount: [this.initialFormValue ? this.initialFormValue.minTradeAmount : null, []],
        currencyId: [this.initialFormValue ? this.initialFormValue.currencyId : null, [Validators.required]],
        bloombergName: [this.initialFormValue ? this.initialFormValue.bloombergName : null, []],
        comment: [this.initialFormValue ? this.initialFormValue.comment : null, []]
      },
      { validator: [BondDateValidator(), BondMinTradeAmountValidator()] }
    );

    if (this.initialFormValue && this.initialFormValue.hasWithholdingTax && this.initialFormValue.withholdingTax) {
      this.form.addControl(
        "withholdingTax",
        new FormControl(this.initialFormValue.withholdingTax, [Validators.min(0.0001), Validators.required])
      );
    }

    this.constructFormDynamicPart();

    this.formReady.emit(this.form);
  }

  constructFormDynamicPart() {
    this.form
      .get("hasWithholdingTax")
      .valueChanges.pipe(untilDestroyed(this))
      .subscribe((val: boolean) => {
        if (val) {
          this.form.addControl(
            "withholdingTax",
            new FormControl(this.initialFormValue ? this.initialFormValue.withholdingTax : null, [
              Validators.min(0.0001),
              Validators.required
            ])
          );
        } else {
          this.form.removeControl("withholdingTax");
        }
      });
    const couponType = this.form.get("couponType").value;
    if (couponType === ECouponTypes.Fixed) {
      this.form.removeControl("spread");
      this.form.removeControl("referenceRateId");
      if (!this.form.get("dayCountConventionId")) {
        this.form.addControl(
          "dayCountConventionId",
          new FormControl(
            this.initialFormValue ? this.initialFormValue.dayCountConventionId : null,
            Validators.required
          )
        );
      }
      if (!this.form.get("couponRate")) {
        this.form.addControl(
          "couponRate",
          new FormControl(this.initialFormValue ? this.initialFormValue.couponRate : null, [
            Validators.required,
            Validators.min(0.000001)
          ])
        );
      }
      if (!this.form.get("paymentFrequencyId")) {
        this.form.addControl(
          "paymentFrequencyId",
          new FormControl(this.initialFormValue ? this.initialFormValue.paymentFrequencyId : null, Validators.required)
        );
      }
      if (!this.form.get("firstCouponDate")) {
        this.form.addControl(
          "firstCouponDate",
          new FormControl(this.initialFormValue ? this.initialFormValue.firstCouponDate : null, Validators.required)
        );
      }
    } else if (couponType === ECouponTypes.Floating) {
      this.form.removeControl("couponRate");
      this.form.removeControl("referenceRateId");
      if (!this.form.get("dayCountConventionId")) {
        this.form.addControl(
          "dayCountConventionId",
          new FormControl(
            this.initialFormValue ? this.initialFormValue.dayCountConventionId : null,
            Validators.required
          )
        );
      }
      if (!this.form.get("paymentFrequencyId")) {
        this.form.addControl(
          "paymentFrequencyId",
          new FormControl(this.initialFormValue ? this.initialFormValue.paymentFrequencyId : null, Validators.required)
        );
      }
      if (!this.form.get("referenceRateId")) {
        this.form.addControl(
          "referenceRateId",
          new FormControl(this.initialFormValue ? this.initialFormValue.referenceRateId : null, Validators.required)
        );
      }
      if (!this.form.get("spread")) {
        this.form.addControl(
          "spread",
          new FormControl(this.initialFormValue ? this.initialFormValue.spread : null, Validators.required)
        );
      }
      if (!this.form.get("firstCouponDate")) {
        this.form.addControl(
          "firstCouponDate",
          new FormControl(this.initialFormValue ? this.initialFormValue.firstCouponDate : null, Validators.required)
        );
      }
    } else if (couponType === ECouponTypes.Discounted) {
      this.form.removeControl("spread");
      this.form.removeControl("referenceRateId");
      this.form.removeControl("couponRate");
      this.form.removeControl("paymentFrequencyId");
      this.form.removeControl("firstCouponDate");
      if (!this.form.get("dayCountConventionId")) {
        this.form.addControl(
          "dayCountConventionId",
          new FormControl(
            this.initialFormValue ? this.initialFormValue.dayCountConventionId : null,
            Validators.required
          )
        );
      }
    }
  }

  trigerChangeDetection() {
    this.cdr.detectChanges();
  }

  ngOnDestroy(): void {}
}
