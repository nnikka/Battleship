import { IHttpBond } from "../../models/IHttpBond";
import { convertToDMY } from "src/utils/date-converter.helper";

export class BondFormValue {
  ISIN: string;
  bloombergName: string;
  clientId: number;
  currencyId: number;
  firstCouponDate: string;
  issueDate: string;
  issueSize: number;
  maturityDate: string;
  name: string;
  parValue: number;
  minTradeAmount: number;
  couponType: number;
  comment: string;

  dayCountConventionId?: number;
  couponRate?: number;
  paymentFrequencyId?: number;
  spread?: number;
  referenceRateId?: number;

  hasWithholdingTax: boolean;
  withholdingTax: number;

  constructor(init?: IHttpBond) {
    this.ISIN = init.isin;
    this.bloombergName = init.bloombergName;
    this.clientId = init.clientId;
    this.currencyId = init.currencyId;
    this.minTradeAmount = init.minTradeAmount;
    if (init.firstCouponDate) {
      this.firstCouponDate = convertToDMY(init.firstCouponDate).toLocaleDateString();
    }
    if (init.issueDate) {
      this.issueDate = convertToDMY(init.issueDate).toLocaleDateString();
    }
    if (init.maturityDate) {
      this.maturityDate = convertToDMY(init.maturityDate).toLocaleDateString();
    }
    this.parValue = init.parValue;
    this.couponType = init.couponType;
    this.issueSize = init.issueSize;

    this.dayCountConventionId = init.dayCountConventionId;
    this.couponRate = init.couponRate;
    this.paymentFrequencyId = init.paymentFrequencyId;
    this.spread = init.spread;
    this.referenceRateId = init.referenceRateId;
    this.comment = init.comment;

    this.hasWithholdingTax = init.hasWithholdingTax;
    this.withholdingTax = init.withholdingTax;
  }
}
