import { FormGroup } from "@angular/forms";

export function BondDateValidator() {
  return (formGroup: FormGroup) => {
    const maturityDateControl = formGroup.get("maturityDate");
    const issueDateControl = formGroup.get("issueDate");
    const firstCouponDateControl = formGroup.get("firstCouponDate");

    let maturityTime = null;
    let issueTime = null;
    let firstCouponTime = null;

    if (maturityDateControl.value) { maturityTime = new Date(maturityDateControl.value).getTime(); }
    if (issueDateControl.value) { issueTime = new Date(issueDateControl.value).getTime(); }
    if (firstCouponDateControl && firstCouponDateControl.value) {
      firstCouponTime = new Date(firstCouponDateControl.value).getTime();
    }

    if (firstCouponTime && issueTime && firstCouponTime <= issueTime) {
      firstCouponDateControl.setErrors({ firstCouponDateMustBeMoreThenIssueDate: true });
    } else if (firstCouponTime && issueTime && !firstCouponTime <= issueTime) {
      firstCouponDateControl.setErrors(null);
    }

    if (maturityTime && firstCouponTime && maturityTime <= firstCouponTime) {
      maturityDateControl.setErrors({ maturityDateMustBeMoreThenFirstCouponDate: true });
    } else if (maturityTime && firstCouponTime && !maturityTime <= firstCouponTime) {
      maturityDateControl.setErrors(null);
    }

    if (issueTime && maturityTime && maturityTime <= issueTime) {
      issueDateControl.setErrors({ issueDateMustBeLessThenMaturityDate: true });
    } else if (issueTime && maturityTime && !maturityTime <= issueTime) {
      issueDateControl.setErrors(null);
    }
  };
}

export function BondMinTradeAmountValidator() {
  return (formGroup: FormGroup) => {
    const minTradeAmountControl = formGroup.get("minTradeAmount");
    const parValueControl = formGroup.get("parValue");
    const issueSizeControl = formGroup.get("issueSize");

    const minTrade = minTradeAmountControl.value;
    const parValue = parValueControl.value;
    const issueSize = issueSizeControl.value;

    if (parValue && typeof minTrade === "number" && (minTrade < parValue || minTrade % parValue !== 0)) {
      minTradeAmountControl.setErrors({ parValueMustBePositiveDivisorOfMinTrade: true });
    }
    if (issueSize && typeof minTrade === "number" && minTrade > issueSize) {
      minTradeAmountControl.setErrors({ minTradeAmountMustBeLessOrEqualThenIssueSize: true });
    }
    if (
      issueSize &&
      parValue &&
      typeof minTrade === "number" &&
      !(minTrade < parValue || minTrade % parValue !== 0) &&
      !(minTrade > issueSize)
    ) {
      minTradeAmountControl.setErrors(null);
    }

    if (parValue && issueSize && parValue > issueSize) {
      parValueControl.setErrors({ parValueMustBeLessOrEqualThenIssueSize: true });
    } else if (parValue && issueSize && !(parValue > issueSize)) {
      parValueControl.setErrors(null);
    }
  };
}
