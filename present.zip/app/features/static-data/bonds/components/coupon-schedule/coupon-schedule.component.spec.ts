import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { CouponScheduleComponent } from "./coupon-schedule.component";

describe("CouponScheduleComponent", () => {
  let component: CouponScheduleComponent;
  let fixture: ComponentFixture<CouponScheduleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CouponScheduleComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CouponScheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
