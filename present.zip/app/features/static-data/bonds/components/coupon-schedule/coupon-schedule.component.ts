import {
  Component,
  OnInit,
  Input,
  ChangeDetectionStrategy,
  OnChanges,
  SimpleChanges,
  Output,
  EventEmitter
} from "@angular/core";
import { IHttpCouponPayment } from "../../models/IHttpCouponPayment";
import { GridDataResult } from "@progress/kendo-angular-grid";
import { IntlService } from "@progress/kendo-angular-intl";
import { FormBuilder, FormGroup, FormControl, Validators } from "@angular/forms";
import { convertToDMY } from "src/utils/date-converter.helper";
import { ICorrectCouponPaymentDateParam } from "../../models/ICorrectCouponPaymentDateParam";

@Component({
  selector: "app-coupon-schedule",
  templateUrl: "./coupon-schedule.component.html",
  styleUrls: ["./coupon-schedule.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CouponScheduleComponent implements OnInit, OnChanges {
  @Input() schedule: IHttpCouponPayment[];
  @Input() maturityDate: string;
  @Input() issueSize: number;
  @Input() loading: boolean;
  @Input() currencyName: string;
  @Input() changeable: boolean = false;

  @Output() datesChange: EventEmitter<ICorrectCouponPaymentDateParam[]> = new EventEmitter();

  _convertToDMY = convertToDMY;
  editMode: boolean = false;

  get gridView(): GridDataResult {
    return {
      data: [...this.schedule, { paymentDate: this.dateFormat(this.maturityDate), paymentAmount: this.issueSize }],
      total: this.schedule ? this.schedule.length : 0
    };
  }

  form: FormGroup;

  constructor(public intl: IntlService, private formBuilder: FormBuilder) {}

  ngOnInit() {
    this.form = this.formBuilder.group([]);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.schedule && changes.schedule.currentValue && this.changeable) {
      for (const key of Object.keys(this.form.controls)) {
        this.form.removeControl(key);
      }
      this.form.reset();
      for (const [i, v] of changes.schedule.currentValue.entries()) {
        if (i !== 0 && i !== changes.schedule.currentValue.length - 1) {
          const control = new FormControl(convertToDMY(v.paymentDate).toLocaleDateString(), [Validators.required]);
          this.form.addControl(convertToDMY(v.defaultPaymentDate || v.paymentDate).toLocaleDateString(), control);
        }
      }
    }
  }

  handleUpdate() {
    const result: ICorrectCouponPaymentDateParam[] = Object.keys(this.form.controls)
      .filter(key => this.form.get(key).dirty)
      .map(key => ({ oldPaymentDate: key, newPaymentDate: this.form.get(key).value }));
    this.datesChange.emit(result);
    this.editMode = false;
  }

  handleEdit() {
    this.editMode = !this.editMode;
    this.form.markAsPristine();
  }

  dateFormat(date) {
    const split = date.split("/");
    let result = split[1].length === 1 ? "0" + split[1] : split[1];
    result += ".";
    result += split[0].length === 1 ? "0" + split[0] : split[0];
    result += "." + split[2];
    return result;
  }
}
