import { Component, OnInit, Input, ChangeDetectionStrategy, Output, EventEmitter } from "@angular/core";
import { IReferenceRate } from "@core/models/catalogs/referenceRate.interface";
import { IIssuer } from "@core/models/catalogs/issuer.interface";
import { ICurrency } from "@core/models/catalogs/currency.interface";
import { IPaymentFrequency } from "../../models/IPaymentFrequency";
import { IDayCountConvention } from "../../models/IDayCountConvention";
import { IHttpBond, IBondScheduleItem } from "../../models/IHttpBond";
import { ECouponTypes } from "../../models/CouponTypes.enum";
import { GridDataResult } from "@progress/kendo-angular-grid";
import { IntlService } from "@progress/kendo-angular-intl";
import { IBondRateFormValue } from "../../models/IBondRateFormValue";

@Component({
  selector: "app-bond-card",
  templateUrl: "./bond-card.component.html",
  styleUrls: ["./bond-card.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class BondCardComponent implements OnInit {
  @Output() correctRate: EventEmitter<IBondRateFormValue> = new EventEmitter();

  @Input() bondData: IHttpBond;

  @Input() referenceRates: IReferenceRate[];
  @Input() issuers: IIssuer[];
  @Input() currencies: ICurrency[];
  @Input() couponType: number;
  @Input() paymentFrequencies: IPaymentFrequency[];
  @Input() dayCountConventions: IDayCountConvention[];

  issuer: IIssuer = null;
  currencyName: string = null;
  paymentFrequencyName: string = null;
  dayCountConventionName: string = null;
  referenceRate: IReferenceRate = null;
  couponTypeName: string = null;

  changeRateIsOpen: boolean = false;
  selectedRateItem: IBondScheduleItem = null;

  get gridView(): GridDataResult {
    return {
      data: this.bondData
        ? [
          ...this.bondData.couponSchedules,
          {
            paymentDate: this.bondData.maturityDate,
            paymentAmount: this.bondData.issueSize,
            type: "Face Amount",
            noteditable: true
          }
        ]
        : [],
      total: this.bondData && this.bondData.couponSchedules ? this.bondData.couponSchedules.length : 0
    };
  }

  get bondIsFloating(): boolean {
    return this.bondData ? this.bondData.couponType === ECouponTypes.Floating : false;
  }

  constructor(public intl: IntlService) { }

  ngOnInit() {
    if (this.bondData) {
      this.issuers.map(issuer => {
        if (issuer.id === this.bondData.clientId) { this.issuer = issuer; }
      });
      this.currencies.map(cur => {
        if (cur.id === this.bondData.currencyId) { this.currencyName = cur ? cur.name : null; }
      });
      this.paymentFrequencies.map(fr => {
        if (fr.id === this.bondData.paymentFrequencyId) { this.paymentFrequencyName = fr ? fr.name : null; }
      });
      this.dayCountConventions.map(dcc => {
        if (dcc.id === this.bondData.dayCountConventionId) { this.dayCountConventionName = dcc ? dcc.name : null; }
      });
      this.referenceRates.map(rr => {
        if (rr.id === this.bondData.referenceRateId) { this.referenceRate = rr; }
      });
      this.couponTypeName = ECouponTypes[this.bondData.couponType];
    }
  }

  openChangeRate(rateItem: IBondScheduleItem) {
    this.changeRateIsOpen = true;
    this.selectedRateItem = rateItem;
  }

  closeChangeRate() {
    this.changeRateIsOpen = false;
    this.selectedRateItem = null;
  }

  handeCorrectRate(event: IBondRateFormValue) {
    this.closeChangeRate();
    this.correctRate.emit(event);
  }

  showEditButton(date: string): boolean {
    const datearray = date.split(".");
    const newdate = datearray[1] + "/" + datearray[0] + "/" + datearray[2];
    return new Date().getTime() <= new Date(newdate).getTime();
  }
}
