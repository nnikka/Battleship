import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";

@Component({
  selector: "app-bond-type-registration-selector",
  templateUrl: "./bond-type-registration-selector.component.html",
  styleUrls: ["./bond-type-registration-selector.component.scss"]
})
export class BondTypeRegistrationSelectorComponent implements OnInit {
  couponTypes: string[] = ["Fixed", "Discounted", "Floating"];
  selectedType: string = null;

  constructor(private router: Router) {}

  ngOnInit() {}

  redirectToAddBond(e) {
    this.router.navigate(["admin/static-data/bonds/add-bond", { couponType: e }]);
  }
}
