import { NgModule } from "@angular/core";

import { DayCountConventionService } from "./services/day-count-convention.service";
import { PaymentFrequencyService } from "./services/payment-frequency.service";
import { BondService } from "./services/bond.service";

import { PaymentFrequencyResolver } from "./resolvers/payment-frequency.resolver";
import { DayCountConventionResolver } from "./resolvers/day-count-convention.resolver";

import { SharedModule } from "@shared/shared.module";
import { BondsRoutingRoutingModule } from "./bonds-routing.module";
import { BondsListComponent } from "./containers/bonds-list/bonds-list.component";
import { BondComponent } from "./containers/bond/bond.component";
import { AddBondComponent } from "./containers/add-bond/add-bond.component";
import {
  BondTypeRegistrationSelectorComponent
} from "./components/bond-type-registration-selector/bond-type-registration-selector.component";
import { BondFormComponent } from "./components/bond-form/bond-form.component";
import { StoreModule } from "@ngrx/store";
import { EffectsModule } from "@ngrx/effects";
import { bondsModuleEffects } from "./store/effects";
import { bondsModuleReducers } from "./store/reducers";
import { CouponScheduleComponent } from "./components/coupon-schedule/coupon-schedule.component";
import { BondCardComponent } from "./components/bond-card/bond-card.component";
import { BondRateFormComponent } from "./components/bond-rate-form/bond-rate-form.component";
import { DynamicTitleService } from "@core/services/dynamic-title.service";
import { BondPricesListComponent } from "./containers/bond-prices-list/bond-prices-list.component";

@NgModule({
  declarations: [
    BondsListComponent,
    BondComponent,
    AddBondComponent,
    BondTypeRegistrationSelectorComponent,
    BondFormComponent,
    CouponScheduleComponent,
    BondCardComponent,
    BondRateFormComponent,
    BondPricesListComponent
  ],
  imports: [
    SharedModule,
    BondsRoutingRoutingModule,
    StoreModule.forFeature("bonds", bondsModuleReducers),
    EffectsModule.forFeature(bondsModuleEffects)
  ],
  providers: [
    DayCountConventionService,
    PaymentFrequencyService,
    BondService,
    DynamicTitleService,
    PaymentFrequencyResolver,
    DayCountConventionResolver
  ]
})
export class BondsModule { }
