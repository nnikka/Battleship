import { Component, OnInit, OnDestroy } from "@angular/core";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import { Router } from "@angular/router";
import { Store, select } from "@ngrx/store";
import { IAppState } from "@core/store/app.state";
import { selectCurrencies, selectCurrencyLoadStatus } from "@core/store/currency/currency.selector";
import { selectAuthorizedIssuers, selectIssuerLoadStatus } from "@core/store/issuer/issuer.selector";
import { IIssuer } from "@core/models/catalogs/issuer.interface";
import { EBondAuthorizationStatusesColors } from "../../models/BondAuthorizationStatuses.enum";
import { ECouponTypes } from "../../models/CouponTypes.enum";
import { constructSelectItemsFromArray, constructSelectItemsFromEnum } from "src/utils/array.helper";
import { IntlService, formatDate } from "@progress/kendo-angular-intl";
import { IColumn } from "@shared/components/complex-grid/interfaces/IColumn";
// tslint:disable
import { EBondOperationAuthorizationStatuses } from "@features/operations/bond-operations/models/EBondOperationAuthorizationStatuses";
import { zip } from "rxjs";
import { map } from "rxjs/operators";
import { IOptions } from "@shared/components/complex-grid/interfaces/IOptions";
import { BondService } from "../../services/bond.service";
import { untilDestroyed } from "ngx-take-until-destroy";
import { FileDownloadService } from "@core/services/file-download.service";

@Component({
  selector: "app-bonds-list",
  templateUrl: "./bonds-list.component.html",
  styleUrls: ["./bonds-list.component.scss"]
})
export class BondsListComponent implements OnInit, OnDestroy {
  breadcrumbItems: IBreadcrumb[] = [
    { text: "Static data", to: null },
    { text: "Bonds", to: null }
  ];

  columns: IColumn[];
  options: IOptions = {
    tableKey: "BondsStaticDataList",
    columnsTooboxEnable: true,
    dblClickEnable: true,
    contextMenuEnable: true,
    detailShowEnable: true,
    items: [
      {
        text: "Add bond operation",
        customIcon: "money-check-alt",
        items: [
          {
            text: "Trade",
            path: "/admin/operations/bonds/add-bond-operation",
            icon: "plus",
            data: {
              routerParams: [
                {
                  name: "operationType",
                  value: "Trade"
                }
              ]
            }
          },
          {
            text: "Deposit",
            path: "/admin/operations/bonds/add-bond-operation",
            icon: "plus",
            data: {
              routerParams: [
                {
                  name: "operationType",
                  value: "Deposit",
                  isQuery: true
                }
              ]
            }
          },
          {
            text: "Withdrawal",
            path: "/admin/operations/bonds/add-bond-operation",
            icon: "plus",
            data: {
              routerParams: [
                {
                  name: "operationType",
                  value: "Withdrawal"
                }
              ]
            }
          },
          {
            text: "IssuerDeposit",
            path: "/admin/operations/bonds/add-bond-operation",
            icon: "plus",
            data: {
              routerParams: [
                {
                  name: "operationType",
                  value: "IssuerDeposit"
                }
              ]
            }
          }
        ]
      }
    ] as any
  };

  currencies$ = this.store.pipe(select(selectCurrencies));
  currenciesLoaded$ = this.store.pipe(select(selectCurrencyLoadStatus));
  issuers$ = this.store.pipe(select(selectAuthorizedIssuers));
  issuersLoaded$ = this.store.pipe(select(selectIssuerLoadStatus));

  issuers: IIssuer[];

  bondAuthorizationStatuses: { name: string; value: number }[];
  couponTypes: { name: string; value: number }[];

  excelIsDownloading: boolean = false;

  constructor(
    private router: Router,
    private store: Store<IAppState>,
    public intl: IntlService,
    private bondService: BondService,
    private fileDownloadService: FileDownloadService) {
    // super(router, route);
  }

  ngOnInit() {
    zip(this.issuers$, this.currencies$)
      .pipe(map(arr => ({ issuers: arr[0], currencies: arr[1] })))
      .subscribe(({ issuers, currencies }) => {
        this.columns = [
          {
            key: "id",
            name: "ID",
            type: "number",
            filterConfig: {
              filterType: "number"
            }
          },
          {
            key: "name",
            name: "Name",
            type: "string",
            filterConfig: {
              filterType: "string"
            }
          },
          {
            key: "clientName",
            name: "Client name",
            type: "string",
            filterConfig: {
              key: "clientId",
              containsDataMapping: true,
              filterData: constructSelectItemsFromArray(issuers, {
                name: "All",
                id: null,
                ticker: null,
                status: null
              }) as any,
              filterType: "dropdown",
              dropdownKeyKey: "name",
              dropdownValueKey: "id"
            }
          },
          {
            key: "isin",
            name: "ISIN",
            type: "string",
            filterConfig: {
              filterType: "string"
            }
          },
          {
            key: "couponType",
            name: "Coupon type",
            type: "string",
            filterConfig: {
              filterData: constructSelectItemsFromEnum(ECouponTypes),
              filterType: "dropdown"
            }
          },
          {
            key: "issueDate",
            name: "Issue date",
            type: "date",
            filterConfig: {
              filterType: "date"
            }
          },
          {
            key: "maturityDate",
            name: "Maturity date",
            type: "date",
            filterConfig: {
              filterType: "date"
            }
          },
          {
            key: "issueSize",
            name: "Issue size",
            type: "number",
            filterConfig: {
              filterType: "number"
            }
          },
          {
            key: "currencyId",
            name: "Currency",
            type: "string",
            filterConfig: {
              containsDataMapping: true,
              filterData: constructSelectItemsFromArray(currencies, { name: "All", id: null }),
              filterType: "dropdown",
              dropdownKeyKey: "name",
              dropdownValueKey: "id"
            }
          },
          {
            key: "hasWithholdingTax",
            name: "Has WH tax",
            type: "string",
            filterConfig: {
              containsDataMapping: true,
              filterData: [
                { name: "All", value: null },
                { name: "Yes", value: true },
                { name: "No", value: false }
              ],
              filterType: "dropdown",
              dropdownKeyKey: "name",
              dataMappingSearchKey: "value",
              dropdownValueKey: "value"
            }
          },
          {
            key: "withholdingTax",
            name: "WH tax amount (%)",
            type: "number",
            filterConfig: {
              filterType: "number"
            }
          },
          {
            key: "status",
            name: "Authorization Status",
            type: "string",
            style: {
              colorsMapping: EBondAuthorizationStatusesColors,
              conditionalColor: true,
              isCard: true
            },
            filterConfig: {
              filterData: constructSelectItemsFromEnum(EBondOperationAuthorizationStatuses),
              filterType: "dropdown"
            }
          }
        ];
      });
  }


  exportExcel() {
    this.excelIsDownloading = true;
    this.bondService
      .exportExcel()
      .pipe(untilDestroyed(this))
      .subscribe(response => {
        this.fileDownloadService.downLoadFile(
          `${formatDate(new Date(), "dd-MM-yyyy HH:mm:ss")} Bonds.xlsx`,
          response
        );
        this.excelIsDownloading = false;
      });
  }

  handleAddBond() {
    this.router.navigate(["admin/static-data/bonds/add-bond"]);
  }
  handleBondPrices() {
    this.router.navigate(["admin/static-data/bonds/prices-bond"]);
  }
  authorizationStatusColor(status: string) {
    return EBondAuthorizationStatusesColors[status];
  }

  ngOnDestroy(): void {
    // if (this.routeSubscription) {
    //   this.routeSubscription.unsubscribe();
    // }
  }
}
