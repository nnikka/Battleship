import { Component, OnInit, OnDestroy, ViewChild, ChangeDetectorRef, ChangeDetectionStrategy } from "@angular/core";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import { ActivatedRoute, Router } from "@angular/router";
import { ECouponTypes } from "../../models/CouponTypes.enum";
import { Store, select } from "@ngrx/store";
import { IAppState } from "@core/store/app.state";
import { selectCurrencies, selectCurrencyLoadStatus } from "@core/store/currency/currency.selector";
import { selectAuthorizedIssuers, selectIssuerLoadStatus } from "@core/store/issuer/issuer.selector";
import { FormGroup } from "@angular/forms";
import { MarkFormGroupTouched } from "src/utils/mark-formgroup-touched.helper";
import { PopupConfirmService } from "@components/popup-confirm/popup-confirm.service";
import { NotificationMessageService } from "@core/services/notification-message.service";
import {
  selectPaymentFrequencies,
  selectPaymentFrequencyLoadStatus
} from "../../store/paymentFrequency/payment-frequency.selector";
import {
  selectDayCountConventions,
  selectDayCountConventionLoadStatus
} from "../../store/dayCountConvention/day-count-convention.selector";
import { BondService } from "../../services/bond.service";
import { CouponScheduleParams } from "../../models/CouponScheduleParams";
import { IPaymentFrequency } from "../../models/IPaymentFrequency";
import { IHttpCouponPayment } from "../../models/IHttpCouponPayment";
import { ICurrency } from "@core/models/catalogs/currency.interface";
import {
  selectReferenceRates,
  selectReferenceRateLoadStatus
} from "@core/store/referenceRates/reference-rate.selector";
import { BondFormComponent } from "../../components/bond-form/bond-form.component";
import { ChangesDetector } from "src/app/general/abstractClasses/ChangesDetector.abstractClass";
import { untilDestroyed } from "ngx-take-until-destroy";

@Component({
  selector: "app-add-bond",
  templateUrl: "./add-bond.component.html",
  styleUrls: ["./add-bond.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AddBondComponent extends ChangesDetector implements OnInit, OnDestroy {
  get bondCurrency(): string {
    if (this.form && this.form.get("currencyId")) {
      for (const currency of this.currencies) {
        if (currency.id === this.form.get("currencyId").value) {
          return currency.name;
        }
      }
    }
    return null;
  }

  get isDiscounted(): boolean {
    return this.selectedCouponType && this.selectedCouponType !== ECouponTypes.Discounted;
  }

  constructor(
    private route: ActivatedRoute,
    private store: Store<IAppState>,
    private popupConfirmService: PopupConfirmService,
    private notificationMessageService: NotificationMessageService,
    private bondService: BondService,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {
    super();
  }

  @ViewChild(BondFormComponent, { static: true }) bondFormCh: BondFormComponent;

  breadcrumbItems: IBreadcrumb[] = [
    { text: "Static data", to: null },
    { text: "Bonds", to: "/admin/static-data/bonds" },
    { text: "Add bond", to: null }
  ];

  referenceRates$ = this.store.pipe(select(selectReferenceRates));
  referenceRatesLoaded$ = this.store.pipe(select(selectReferenceRateLoadStatus));
  currencies$ = this.store.pipe(select(selectCurrencies));
  currenciesLoaded = this.store.pipe(select(selectCurrencyLoadStatus));
  currencies: ICurrency[];
  issuers$ = this.store.pipe(select(selectAuthorizedIssuers));
  issuersLoaded$ = this.store.pipe(select(selectIssuerLoadStatus));
  paymentFrequencies$ = this.store.pipe(select(selectPaymentFrequencies));
  paymentFrequenciesLoaded$ = this.store.pipe(select(selectPaymentFrequencyLoadStatus));
  paymentFrequencies: IPaymentFrequency[] = [];
  dayCountConventions$ = this.store.pipe(select(selectDayCountConventions));
  dayCountConventionsLoaded$ = this.store.pipe(select(selectDayCountConventionLoadStatus));

  loading: boolean = false;
  selectedCouponType: number;

  form: FormGroup;

  shceduleOpened: boolean = false;
  shceduleIsLoading: boolean = true;
  shcedule: IHttpCouponPayment[] = null;
  hasUnsavedChanges(): boolean {
    if (this.form) {
      return this.form.dirty;
    }
    return false;
  }

  ngOnInit() {
    if (this.route.snapshot.paramMap.get("couponType")) {
      this.selectedCouponType = ECouponTypes[this.route.snapshot.paramMap.get("couponType")];
      if (!this.selectedCouponType) {
        this.router.navigateByUrl("/not-found", { replaceUrl: true });
      }
    }
    this.paymentFrequencies$.pipe(untilDestroyed(this)).subscribe(pqs => {
      this.paymentFrequencies = pqs;
    });
    this.currencies$.pipe(untilDestroyed(this)).subscribe(cur => {
      this.currencies = cur;
    });
  }

  handleRegister() {
    if (!this.form.valid) {
      MarkFormGroupTouched(this.form.controls);
      this.bondFormCh.trigerChangeDetection();
      this.notificationMessageService.error(
        "Form is invalid, please make sure all required fields are filled out correctly"
      );
    } else {
      this.popupConfirmService.show(null, null, () => {
        this.loading = true;
        this.cdr.detectChanges();
        this.bondService
          .create(this.form.getRawValue())
          .pipe(untilDestroyed(this))
          .subscribe(
            resp => {
              this.form.reset();
              this.form.markAsPristine();
              this.bondFormCh.trigerChangeDetection();
              this.router.navigate(["admin/static-data/bonds"]);
              this.notificationMessageService.success("Bond has been added successfully");
            },
            err => {
              this.loading = false;
              this.cdr.detectChanges();
            }
          );
      });
    }
  }

  handleGenerateCouponSchedule() {
    this.shceduleOpened = true;
    this.shceduleIsLoading = true;
    this.cdr.detectChanges();
    this.bondService
      .generateCouponSchedule(new CouponScheduleParams(this.form.getRawValue(), this.paymentFrequencies))
      .pipe(untilDestroyed(this))
      .subscribe(
        resp => {
          this.shceduleIsLoading = false;
          this.shcedule = resp;
          this.cdr.detectChanges();
        },
        err => {
          this.shceduleIsLoading = false;
          this.shcedule = null;
          this.cdr.detectChanges();
        }
      );
  }

  closeCouponSchedule() {
    this.shceduleOpened = false;
    this.shcedule = null;
    this.cdr.detectChanges();
  }

  formInitialized(form: FormGroup) {
    this.form = form;
  }

  ngOnDestroy() {
    // this.handeUnsubscribes()
  }
}
