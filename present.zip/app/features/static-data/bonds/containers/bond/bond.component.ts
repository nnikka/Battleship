import { Component, OnInit, OnDestroy, ViewChild } from "@angular/core";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import {
  EBondAuthorizationStatuses,
  EBondAuthorizationStatusesColors
} from "../../models/BondAuthorizationStatuses.enum";
import { IHttpBond } from "../../models/IHttpBond";
import { ActivatedRoute, Router } from "@angular/router";
import { Store, select } from "@ngrx/store";
import { IAppState } from "@core/store/app.state";
import { BondService } from "../../services/bond.service";
import { ICurrency } from "@core/models/catalogs/currency.interface";
import { IPaymentFrequency } from "../../models/IPaymentFrequency";
import {
  selectReferenceRates,
  selectReferenceRateLoadStatus
} from "@core/store/referenceRates/reference-rate.selector";
import { selectCurrencies, selectCurrencyLoadStatus } from "@core/store/currency/currency.selector";
import { selectAuthorizedIssuers, selectIssuerLoadStatus } from "@core/store/issuer/issuer.selector";
import {
  selectPaymentFrequencies,
  selectPaymentFrequencyLoadStatus
} from "../../store/paymentFrequency/payment-frequency.selector";
import {
  selectDayCountConventions,
  selectDayCountConventionLoadStatus
} from "../../store/dayCountConvention/day-count-convention.selector";
import { FormGroup } from "@angular/forms";
import { AuthService } from "@auth/services/auth.service";
import { BondFormValue } from "../../components/bond-form/BondFormValue";
import { ECouponTypes } from "../../models/CouponTypes.enum";
import { NotificationMessageService } from "@core/services/notification-message.service";
import { PopupConfirmService } from "@components/popup-confirm/popup-confirm.service";
import { MarkFormGroupTouched } from "src/utils/mark-formgroup-touched.helper";
import { BondFormComponent } from "../../components/bond-form/bond-form.component";
import { IHttpCouponPayment } from "../../models/IHttpCouponPayment";
import { CouponScheduleParams } from "../../models/CouponScheduleParams";
import { ChangesDetector } from "src/app/general/abstractClasses/ChangesDetector.abstractClass";
import { untilDestroyed } from "ngx-take-until-destroy";
import { IBondRateFormValue } from "../../models/IBondRateFormValue";
import { DynamicTitleService } from "@core/services/dynamic-title.service";
import { FadeInOutAnimation } from "@animations/fadeInOut.animation";
import { ICorrectCouponPaymentDateParam } from "../../models/ICorrectCouponPaymentDateParam";

@Component({
  selector: "app-bond",
  templateUrl: "./bond.component.html",
  styleUrls: ["./bond.component.scss"],
  animations: [FadeInOutAnimation]
})
export class BondComponent extends ChangesDetector implements OnInit, OnDestroy {
  get bondCurrency(): string {
    if (this.form && this.form.get("currencyId")) {
      for (const currency of this.currencies) {
        if (currency.id === this.form.get("currencyId").value) {
          return currency.name;
        }
      }
    }
    return null;
  }

  get bondAuthorizationStatus() {
    return this.bondData ? EBondAuthorizationStatuses[this.bondData.audit.status] : null;
  }

  get isBondAuthorized() {
    return this.bondData ? EBondAuthorizationStatuses.Authorized === this.bondData.audit.status : false;
  }

  get isBondUnauthorized() {
    return this.bondData ? EBondAuthorizationStatuses.Unauthorized === this.bondData.audit.status : false;
  }

  get initialFormValue(): BondFormValue {
    return new BondFormValue(this.bondData);
  }

  get isDiscounted(): boolean {
    return this.selectedCouponType && this.selectedCouponType !== ECouponTypes.Discounted;
  }

  get canAuthorize() {
    if (this.formIsUpdatedSuccessfully) {
      return false;
    }
    if (this.bondData) {
      const lastUserId = this.bondData.audit.lastModifiedUserId
        ? this.bondData.audit.lastModifiedUserId
        : this.bondData.audit.createUserId;
      if (lastUserId !== Number(this.authService.getUserId())) {
        return true;
      }
    }
    return null;
  }

  constructor(
    private route: ActivatedRoute,
    private store: Store<IAppState>,
    private bondService: BondService,
    private authService: AuthService,
    private notificationMessageService: NotificationMessageService,
    private popupConfirmService: PopupConfirmService,
    private router: Router,
    private dynamicTitleService: DynamicTitleService
  ) {
    super();
  }
  @ViewChild(BondFormComponent, { static: false }) bondFormCh: BondFormComponent;

  referenceRates$ = this.store.pipe(select(selectReferenceRates));
  referenceRatesLoaded$ = this.store.pipe(select(selectReferenceRateLoadStatus));
  currencies$ = this.store.pipe(select(selectCurrencies));
  currenciesLoaded = this.store.pipe(select(selectCurrencyLoadStatus));
  currencies: ICurrency[];
  issuers$ = this.store.pipe(select(selectAuthorizedIssuers));
  issuersLoaded$ = this.store.pipe(select(selectIssuerLoadStatus));
  paymentFrequencies$ = this.store.pipe(select(selectPaymentFrequencies));
  paymentFrequenciesLoaded$ = this.store.pipe(select(selectPaymentFrequencyLoadStatus));
  paymentFrequencies: IPaymentFrequency[] = [];
  dayCountConventions$ = this.store.pipe(select(selectDayCountConventions));
  dayCountConventionsLoaded$ = this.store.pipe(select(selectDayCountConventionLoadStatus));

  breadcrumbItems: IBreadcrumb[] = [
    { text: "Static data", to: null },
    { text: "Bonds", to: "/admin/static-data/bonds" },
    { text: "Bond", to: null }
  ];

  bondId: string;
  bondData: IHttpBond;
  bondIsLoading: boolean = true;
  form: FormGroup;
  selectedCouponType: number;
  authorizationIsDisabled: boolean = false;

  shceduleOpened: boolean = false;
  shceduleIsLoading: boolean = true;
  shcedule: IHttpCouponPayment[] = null;

  formIsUpdatedSuccessfully: boolean = false;

  hasUnsavedChanges(): boolean {
    if (this.form) {
      return this.form.dirty;
    }
    return false;
  }

  ngOnInit() {
    this.currencies$.pipe(untilDestroyed(this)).subscribe(cur => {
      this.currencies = cur;
    });
    this.paymentFrequencies$.pipe(untilDestroyed(this)).subscribe(pqs => {
      this.paymentFrequencies = pqs;
    });
    this.route.paramMap.pipe(untilDestroyed(this)).subscribe(paramsAsMap => {
      this.bondId = paramsAsMap.get("id");
      this.loadBond(this.bondId);
    });
  }

  loadBond(id) {
    this.bondIsLoading = true;
    this.bondService
      .getById(id)
      .pipe(untilDestroyed(this))
      .subscribe(
        bond => {
          this.bondData = bond;
          this.bondIsLoading = false;
          this.selectedCouponType = bond.couponType;

          this.dynamicTitleService.updateTitle(this.bondData.name);
        },
        err => {
          this.router.navigateByUrl("/not-found", { replaceUrl: true });
        }
      );
  }

  authorizationStatusColor(status: string): string {
    return status ? EBondAuthorizationStatusesColors[status] : null;
  }

  formInitialized(form: FormGroup) {
    this.form = form;
  }

  ngOnDestroy() {}

  handleChangeAuthorize(status: string, message: string) {
    if (this.form && this.form.dirty) {
      this.notificationMessageService.warn(
        "Form is changed, if you want to change authorization status please update the form first"
      );
      return;
    }
    this.popupConfirmService.show(null, null, () => {
      this.authorizationIsDisabled = true;
      this.bondIsLoading = true;
      this.bondService
        .changeAuthorizationStatus(this.bondId, EBondAuthorizationStatuses[status])
        .pipe(untilDestroyed(this))
        .subscribe(
          resp => {
            this.authorizationIsDisabled = false;
            this.bondIsLoading = false;
            this.loadBond(this.bondId);
            this.notificationMessageService.success(message);
          },
          err => {
            this.authorizationIsDisabled = false;
            this.bondIsLoading = false;
          }
        );
    });
  }

  handleUpdate() {
    if (!this.form.dirty) {
      this.notificationMessageService.info("Nothing is changed");
    } else {
      if (!this.form.valid) {
        MarkFormGroupTouched(this.form.controls);
        this.bondFormCh.trigerChangeDetection();
        this.notificationMessageService.error(
          "Form is invalid, please make sure all required fields are filled out correctly"
        );
      } else {
        this.popupConfirmService.show(null, null, () => {
          this.bondIsLoading = true;
          this.bondService
            .update(this.bondId, this.form.getRawValue())
            .pipe(untilDestroyed(this))
            .subscribe(
              resp => {
                // this.form.reset();
                this.form.markAsPristine();
                this.bondFormCh.trigerChangeDetection();
                this.formIsUpdatedSuccessfully = true;
                this.bondIsLoading = false;
                // this.router.navigate(["admin/static-data/bonds"]);
                this.notificationMessageService.success("Bond has been updated successfully");
              },
              err => {
                this.bondIsLoading = false;
              }
            );
        });
      }
    }
  }

  handleGenerateCouponSchedule() {
    this.shceduleOpened = true;
    this.shceduleIsLoading = true;
    this.bondService
      .generateCouponSchedule(new CouponScheduleParams(this.form.getRawValue(), this.paymentFrequencies), this.bondId)
      .pipe(untilDestroyed(this))
      .subscribe(
        resp => {
          this.shceduleIsLoading = false;
          this.shcedule = resp;
        },
        err => {
          this.shceduleIsLoading = false;
          this.shcedule = null;
        }
      );
  }

  closeCouponSchedule() {
    this.shceduleOpened = false;
    this.shcedule = null;
  }

  handeCorrectRate(event: IBondRateFormValue) {
    this.bondIsLoading = true;
    this.bondService.correctBondRate(this.bondId, event).subscribe(
      resp => {
        this.loadBond(this.bondId);
        this.notificationMessageService.success("Rate has been updated successfully");
      },
      err => {
        this.bondIsLoading = false;
      }
    );
  }

  handleDateChange(event: ICorrectCouponPaymentDateParam[]) {
    this.shceduleIsLoading = true;
    this.bondService.correctBondCouponDates(this.bondId, event).subscribe(
      resp => {
        this.notificationMessageService.success("Changes has been saved successfully");
        this.handleGenerateCouponSchedule();
      },
      err => {
        this.shceduleIsLoading = false;
      }
    );
  }
}
