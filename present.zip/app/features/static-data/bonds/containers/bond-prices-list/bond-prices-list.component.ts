import { Component, OnInit, OnDestroy } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { select, Store } from "@ngrx/store";
import { selectCurrencies, selectCurrencyLoadStatus } from "@core/store/currency/currency.selector";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import { PopupConfirmService } from "@components/popup-confirm/popup-confirm.service";
import { NotificationMessageService } from "@core/services/notification-message.service";
import { FileDownloadService } from "@core/services/file-download.service";
import { untilDestroyed } from "ngx-take-until-destroy";
import { BondService } from "../../services/bond.service";
import { IColumn } from "@shared/components/complex-grid/interfaces/IColumn";
import { IOptions } from "@shared/components/complex-grid/interfaces/IOptions";
import { Subject } from "rxjs";

@Component({
  selector: "app-bond-prices-list",
  templateUrl: "./bond-prices-list.component.html",
  styleUrls: ["./bond-prices-list.component.scss"]
})
export class BondPricesListComponent implements OnInit, OnDestroy {
  form: FormGroup;

  uploadExcelForm: FormGroup;

  fxAuthorizationStatuses;
  listIsLoading = true;

  updateGrid: Subject<any> = new Subject();

  columns: IColumn[];
  options: IOptions = {
    tableKey: "BondPricesStaticDataList",
    columnsTooboxEnable: true,
  };

  templateIsDownloading: boolean = false;
  pricesIsUploading: boolean = false;

  breadcrumbItems: IBreadcrumb[] = [
    { text: "Static data", to: null },
    { text: "Bonds", to: "/admin/static-data/bonds" },
    { text: "Prices", to: null }
  ];

  constructor(
    private bondsService: BondService,
    private formBuilder: FormBuilder,
    private popupConfirmService: PopupConfirmService,
    private notificationMessageService: NotificationMessageService,
    private fileDownloadService: FileDownloadService) {
    this.uploadExcelForm = this.formBuilder.group({
      file: [null, [Validators.required]]
    });
  }

  ngOnInit() {
    this.columns = [
      {
        key: "id",
        name: "ID",
        type: "number",
        filterConfig: {
          filterType: "number"
        }
      },
      {
        key: "bondName",
        name: "Bond name",
        type: "string",
        filterConfig: {
          filterType: "string"
        }
      },
      {
        key: "bondISIN",
        name: "ISIN",
        type: "string",
        filterConfig: {
          key: "isin",
          filterType: "string"
        }
      },
      {
        key: "price",
        name: "Price",
        type: "number",
        filterConfig: {
          filterType: "number"
        }
      },
      {
        key: "date",
        name: "Date",
        type: "date",
        filterConfig: {
          filterType: "date"
        }
      }
    ];
  }

  ngOnDestroy() { }

  handleUploadExcel() {
    this.popupConfirmService.show(null, null, () => {
      this.listIsLoading = true;
      const formData = new FormData();
      this.pricesIsUploading = true;
      formData.append("file", this.uploadExcelForm.get("file").value);
      this.bondsService
        .importExcel(formData)
        .pipe(untilDestroyed(this))
        .subscribe(
          () => {
            this.notificationMessageService.success("Prices has been added successfully");
            this.updateGrid.next();
            this.uploadExcelForm.get("file").setValue(null);
            this.pricesIsUploading = false;
          },
          () => {
            this.listIsLoading = false;
            this.pricesIsUploading = false;
          }
        );
    });
  }

  handleDownloadTemplate() {
    this.templateIsDownloading = true;
    this.fileDownloadService
      .download("templates/Bond Price", "BondPrices.xlsx")
      .pipe(untilDestroyed(this))
      .subscribe(
        resp => {
          this.fileDownloadService.downLoadFile("BondPrices.xlsx", resp);
          this.templateIsDownloading = false;
        },
        err => {
          this.templateIsDownloading = false;
        }
      );
  }
}
