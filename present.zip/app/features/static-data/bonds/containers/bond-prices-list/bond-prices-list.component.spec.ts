import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { BondPricesListComponent } from "./bond-prices-list.component";

describe("BondPricesListComponent", () => {
  let component: BondPricesListComponent;
  let fixture: ComponentFixture<BondPricesListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BondPricesListComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BondPricesListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
