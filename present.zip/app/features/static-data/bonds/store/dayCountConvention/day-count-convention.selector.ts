import { createSelector } from "@ngrx/store";
import { IDayCountConventionState } from "./day-count-convention.state";

const selectDayCountConventionState = (state: any) => state.bonds.dayCountConvention;

export const selectDayCountConventions = createSelector(
  selectDayCountConventionState,
  (state: IDayCountConventionState) => state.dayCountConventions
);

export const selectDayCountConventionLoadStatus = createSelector(
  selectDayCountConventionState,
  (state: IDayCountConventionState) => state.loaded
);

export const selectDayCountConventionStatuses = createSelector(
  selectDayCountConventionState,
  (state: IDayCountConventionState) => {
    return { failed: state.failed, loaded: state.loaded, lastUpdated: state.lastUpdated };
  }
);
