import { IDayCountConvention } from "../../models/IDayCountConvention";

export interface IDayCountConventionState {
  dayCountConventions: IDayCountConvention[];
  loaded: boolean;
  failed: boolean;
  lastUpdated: Date;
}

export const initialDayCountConventionState = {
  dayCountConventions: [],
  loaded: false,
  failed: false,
  lastUpdated: null
};
