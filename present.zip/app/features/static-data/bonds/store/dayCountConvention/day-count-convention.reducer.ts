import { EDayCountConventionActions, DayCountConventionActions } from "./day-count-convention.action";
import { IDayCountConventionState, initialDayCountConventionState } from "./day-count-convention.state";

export function dayCountConventionReducer(
  state = initialDayCountConventionState,
  action: DayCountConventionActions
): IDayCountConventionState {
  switch (action.type) {
    case EDayCountConventionActions.GetDayCountConventionsSuccess: {
      return {
        ...state,
        dayCountConventions: action.payload,
        lastUpdated: new Date(),
        loaded: true
      };
    }
    case EDayCountConventionActions.GetDayCountConventionsFailed: {
      return {
        ...state,
        ...initialDayCountConventionState,
        failed: true
      };
    }
    case EDayCountConventionActions.ClearDayCountConvention: {
      return {
        ...state,
        ...initialDayCountConventionState
      };
    }
    default:
      return state;
  }
}
