import { Injectable } from "@angular/core";
import { Effect, ofType, Actions } from "@ngrx/effects";
import { of } from "rxjs";
import { switchMap, map, catchError } from "rxjs/operators";

import { DayCountConventionService } from "../../services/day-count-convention.service";
import {
  EDayCountConventionActions,
  GetDayCountConventions,
  GetDayCountConventionsSuccess,
  GetDayCountConventionsFailed
} from "./day-count-convention.action";
import { IDayCountConvention } from "../../models/IDayCountConvention";

@Injectable()
export class DayCountConventionEffects {
  @Effect()
  getDayCountConventions$ = this._actions.pipe(
    ofType<GetDayCountConventions>(EDayCountConventionActions.GetDayCountConventions),
    switchMap(() => {
      return this._dayCountConventionService.get().pipe(
        map((dayCountConventions: IDayCountConvention[]) => new GetDayCountConventionsSuccess(dayCountConventions)),
        catchError(error => of(new GetDayCountConventionsFailed()))
      );
    })
  );

  constructor(private _actions: Actions, private _dayCountConventionService: DayCountConventionService) {}
}
