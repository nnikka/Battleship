import { Action } from "@ngrx/store";
import { IDayCountConvention } from "../../models/IDayCountConvention";

export enum EDayCountConventionActions {
  GetDayCountConventions = "[Bonds module, Day Count Convention] Get Day Count Conventions",
  GetDayCountConventionsSuccess = "[Bonds module, Day Count Convention] Get Day Count Conventions Success",
  GetDayCountConventionsFailed = "[Bonds module, Day Count Convention] Get Day Count Conventions Failed",
  ClearDayCountConvention = "[Bonds module, Day Count Convention] Clear Day Count Convention"
}

export class GetDayCountConventions implements Action {
  public readonly type = EDayCountConventionActions.GetDayCountConventions;
}

export class GetDayCountConventionsSuccess implements Action {
  public readonly type = EDayCountConventionActions.GetDayCountConventionsSuccess;
  constructor(public payload: IDayCountConvention[]) {}
}

export class GetDayCountConventionsFailed implements Action {
  public readonly type = EDayCountConventionActions.GetDayCountConventionsFailed;
}

export class ClearDayCountConvention implements Action {
  public readonly type = EDayCountConventionActions.ClearDayCountConvention;
}

export type DayCountConventionActions =
  | GetDayCountConventions
  | GetDayCountConventionsSuccess
  | GetDayCountConventionsFailed
  | ClearDayCountConvention;
