import { IPaymentFrequencyState, initialPaymentFrequencyState } from "./paymentFrequency/payment-frequency.state";
import {
  IDayCountConventionState,
  initialDayCountConventionState
} from "./dayCountConvention/day-count-convention.state";

export interface IBondsModuleState {
  paymentFrequency: IPaymentFrequencyState;
  dayCountConvention: IDayCountConventionState;
}

export const initialBondsModuleState = {
  paymentFrequency: initialPaymentFrequencyState,
  dayCountConvention: initialDayCountConventionState
};

export function getInitialState(): IBondsModuleState {
  return initialBondsModuleState;
}
