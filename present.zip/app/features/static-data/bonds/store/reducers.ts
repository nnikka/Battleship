import { ActionReducerMap } from "@ngrx/store";
import { IBondsModuleState } from "./state";
import { paymentFrequencyReducer } from "./paymentFrequency/payment-frequency.reducer";
import { dayCountConventionReducer } from "./dayCountConvention/day-count-convention.reducer";

export const bondsModuleReducers: ActionReducerMap<IBondsModuleState, any> = {
  paymentFrequency: paymentFrequencyReducer,
  dayCountConvention: dayCountConventionReducer
};
