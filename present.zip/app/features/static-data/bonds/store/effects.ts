import { PaymentFrequencyEffects } from "./paymentFrequency/payment-frequency.effect";
import { DayCountConventionEffects } from "./dayCountConvention/day-count-convention.effect";

export const bondsModuleEffects = [PaymentFrequencyEffects, DayCountConventionEffects];
