import { createSelector } from "@ngrx/store";

import { IPaymentFrequencyState } from "./payment-frequency.state";

const selectPaymentFrequencyState = (state: any) => state.bonds.paymentFrequency;

export const selectPaymentFrequencies = createSelector(
  selectPaymentFrequencyState,
  (state: IPaymentFrequencyState) => state.paymentFrequencies
);

export const selectPaymentFrequencyLoadStatus = createSelector(
  selectPaymentFrequencyState,
  (state: IPaymentFrequencyState) => state.loaded
);

export const selectPaymentFrequencyStatuses = createSelector(
  selectPaymentFrequencyState,
  (state: IPaymentFrequencyState) => {
    return { failed: state.failed, loaded: state.loaded, lastUpdated: state.lastUpdated };
  }
);
