import { IPaymentFrequency } from "../../models/IPaymentFrequency";

export interface IPaymentFrequencyState {
  paymentFrequencies: IPaymentFrequency[];
  loaded: boolean;
  failed: boolean;
  lastUpdated: Date;
}

export const initialPaymentFrequencyState = {
  paymentFrequencies: [],
  loaded: false,
  failed: false,
  lastUpdated: null
};
