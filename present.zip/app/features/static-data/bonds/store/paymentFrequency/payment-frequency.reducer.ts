import { EPaymentFrequencyActions, PaymentFrequencyActions } from "./payment-frequency.action";
import { IPaymentFrequencyState, initialPaymentFrequencyState } from "./payment-frequency.state";

export function paymentFrequencyReducer(
  state = initialPaymentFrequencyState,
  action: PaymentFrequencyActions
): IPaymentFrequencyState {
  switch (action.type) {
    case EPaymentFrequencyActions.GetPaymentFrequenciesSuccess: {
      return {
        ...state,
        paymentFrequencies: action.payload,
        lastUpdated: new Date(),
        loaded: true
      };
    }
    case EPaymentFrequencyActions.GetPaymentFrequenciesFailed: {
      return {
        ...state,
        ...initialPaymentFrequencyState,
        failed: true
      };
    }
    case EPaymentFrequencyActions.ClearPaymentFrequency: {
      return {
        ...state,
        ...initialPaymentFrequencyState
      };
    }
    default:
      return state;
  }
}
