import { Injectable } from "@angular/core";
import { Effect, ofType, Actions } from "@ngrx/effects";
import { of } from "rxjs";
import { switchMap, map, catchError } from "rxjs/operators";

import { PaymentFrequencyService } from "../../services/payment-frequency.service";
import {
  EPaymentFrequencyActions,
  GetPaymentFrequencies,
  GetPaymentFrequenciesSuccess,
  GetPaymentFrequenciesFailed
} from "./payment-frequency.action";
import { IPaymentFrequency } from "../../models/IPaymentFrequency";

@Injectable()
export class PaymentFrequencyEffects {
  @Effect()
  getFrequencies$ = this._actions.pipe(
    ofType<GetPaymentFrequencies>(EPaymentFrequencyActions.GetPaymentFrequencies),
    switchMap(() => {
      return this._paymentFrequencyService.get().pipe(
        map((frequemcies: IPaymentFrequency[]) => new GetPaymentFrequenciesSuccess(frequemcies)),
        catchError(error => of(new GetPaymentFrequenciesFailed()))
      );
    })
  );

  constructor(private _actions: Actions, private _paymentFrequencyService: PaymentFrequencyService) {}
}
