import { Action } from "@ngrx/store";
import { IPaymentFrequency } from "../../models/IPaymentFrequency";
export enum EPaymentFrequencyActions {
  GetPaymentFrequencies = "[Bonds module, Payment Frequency] Get Payment Frequencies",
  GetPaymentFrequenciesSuccess = "[Bonds module, Payment Frequency] Get Payment Frequencies Success",
  GetPaymentFrequenciesFailed = "[Bonds module, Payment Frequency] Get Payment Frequencies Failed",
  ClearPaymentFrequency = "[Bonds module, Payment Frequency] Clear Payment Frequency"
}

export class GetPaymentFrequencies implements Action {
  public readonly type = EPaymentFrequencyActions.GetPaymentFrequencies;
}

export class GetPaymentFrequenciesSuccess implements Action {
  public readonly type = EPaymentFrequencyActions.GetPaymentFrequenciesSuccess;
  constructor(public payload: IPaymentFrequency[]) {}
}

export class GetPaymentFrequenciesFailed implements Action {
  public readonly type = EPaymentFrequencyActions.GetPaymentFrequenciesFailed;
}

export class ClearPaymentFrequency implements Action {
  public readonly type = EPaymentFrequencyActions.ClearPaymentFrequency;
}

export type PaymentFrequencyActions =
  | GetPaymentFrequencies
  | GetPaymentFrequenciesSuccess
  | GetPaymentFrequenciesFailed
  | ClearPaymentFrequency;
