export interface IHttpCouponPayment {
  defaultPaymentDate: string;
  isPaymentDateCorrected: boolean;
  isRateCorrected: boolean;
  paymentAmount: number;
  paymentDate: string;
  rate: number;
}
