export interface IPaymentFrequency {
  id: number;
  name: string;
  frequencyValue: number;
}
