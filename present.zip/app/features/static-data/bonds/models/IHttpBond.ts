import { IAuditCommand } from "@core/models/commands/IAuditCommand";

export interface IBondScheduleItem {
  paymentDate: string;
  defaultPaymentDate: string;
  paymentAmount: number;
  rate: number;
  isRateCorrected: boolean;
  isPaymentDateCorrected: boolean;
}

export interface IHttpBond {
  id: number;
  name: string;
  audit: IAuditCommand;
  bondStatus: number;
  couponType: number;
  ticker: string;
  currency: string;
  referenceRateName: string;
  bloombergName: string;
  isin: string;
  issueDate: string;
  firstCouponDate: string;
  maturityDate: string;
  issueSize: number;
  parValue: number;
  currencyId: number;
  dayCountConventionId: number;
  paymentFrequencyId: number;
  couponRate: number;
  spread: number;
  referenceRateId: number;
  clientId: number;
  comment: string;
  minTradeAmount: number;
  couponSchedules: IBondScheduleItem[];
  hasWithholdingTax: boolean;
  withholdingTax: number;
}
