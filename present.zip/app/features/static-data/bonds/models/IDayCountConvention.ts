export interface IDayCountConvention {
  id: number;
  name: string;
}
