export interface ICorrectCouponPaymentDateParam {
  oldPaymentDate: string;
  newPaymentDate: string;
}
