export enum ECouponTypes {
  Fixed = 1,
  Floating = 2,
  Discounted = 4
}
