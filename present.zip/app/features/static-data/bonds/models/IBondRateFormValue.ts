export interface IBondRateFormValue {
  defaultPaymentDate: string;
  date: string;
  rate: number;
}
