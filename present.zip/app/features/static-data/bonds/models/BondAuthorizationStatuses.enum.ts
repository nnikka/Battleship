export enum EBondAuthorizationStatuses {
  Unauthorized = 1,
  Authorized = 2
}

export enum EBondAuthorizationStatusesColors {
  Unauthorized = "#ffc107",
  Authorized = "#00a3e0"
}
