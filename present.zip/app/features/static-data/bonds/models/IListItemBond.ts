export interface IListItemBond {
  bloombergName: string;
  bondStatus: string;
  clientId: number;
  clientName: string;
  couponRate: number;
  couponType: string;
  createUserFullName: string;
  currencyId: number;
  dayCountConventionId: number;
  firstCouponDate: string;
  id: number;
  isin: string;
  issueDate: string;
  issueSize: number;
  maturityDate: string;
  name: string;
  parValue: number;
  paymentFrequencyId: number;
  referenceRateId: number;
  spread: number;
  status: string;
}
