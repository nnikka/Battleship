import { BondFormValue } from "../components/bond-form/BondFormValue";
import { IPaymentFrequencyState } from "../store/paymentFrequency/payment-frequency.state";
import { IPaymentFrequency } from "./IPaymentFrequency";

export class CouponScheduleParams {
  issueDate: string;
  dayCountConventionId: number;
  referenceRateId: number;
  couponType: number;
  maturityDate: string;
  firstCouponDate: string;
  parValue: number;
  paymentFrequency: number;
  couponRate: number;
  spread: number;
  issueSize: number;

  constructor(init: BondFormValue, paymentFrequencies: IPaymentFrequency[]) {
    this.issueDate = init.issueDate;
    this.dayCountConventionId = init.dayCountConventionId ? init.dayCountConventionId : null;
    this.referenceRateId = init.referenceRateId;
    this.couponRate = init.couponRate;
    this.couponType = init.couponType;
    this.firstCouponDate = init.firstCouponDate;
    this.maturityDate = init.maturityDate;
    this.parValue = init.parValue;
    this.spread = init.spread;
    this.issueSize = init.issueSize;
    if (init.paymentFrequencyId) {
      paymentFrequencies.map(pq => {
        if (pq.id === init.paymentFrequencyId) { this.paymentFrequency = pq.frequencyValue; }
      });
    }
  }
}
