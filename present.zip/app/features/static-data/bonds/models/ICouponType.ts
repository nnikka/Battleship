export interface ICouponType {
  name: string;
  value: number;
}
