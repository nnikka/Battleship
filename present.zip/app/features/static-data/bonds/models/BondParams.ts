import { IAuditCommand } from "@core/models/commands/IAuditCommand";

export class BondParams {
  id: number;
  bondStatus: 1;
  ticker: string;
  currency: string;
  bloombergName: string;
  couponType: 1;
  isin: string;
  maturityDate: string;
  issueDate: string;
  firstCouponDate: string;
  issueSize: number;
  parValue: number;
  currencyId: number;
  dayCountConventionId: number;
  paymentFrequencyId: number;
  couponRate: number;
  spread: number;
  referenceRateId: number;
  clientId: number;
  auditCommand?: IAuditCommand;
}
