import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { AddBondComponent } from "./containers/add-bond/add-bond.component";
import { BondComponent } from "./containers/bond/bond.component";
import { BondsListComponent } from "./containers/bonds-list/bonds-list.component";

import { CurrencyResolver } from "@core/resolvers/catalogs/currency.resolver";
import { IssuerResolver } from "@core/resolvers/catalogs/issuer.resolver";
import { PaymentFrequencyResolver } from "./resolvers/payment-frequency.resolver";
import { DayCountConventionResolver } from "./resolvers/day-count-convention.resolver";
import { ReferenceRateResolver } from "@core/resolvers/catalogs/referenceRate.resolver";
import { ConfirmDeactivateGuard } from "@core/guards/confirm-deactivate-guard.guard";
import { BondPricesListComponent } from "./containers/bond-prices-list/bond-prices-list.component";

const routes: Routes = [
  {
    path: "",
    component: BondsListComponent,
    resolve: {
      issuer: IssuerResolver,
      currency: CurrencyResolver
    }
  },
  {
    path: "add-bond",
    component: AddBondComponent,
    resolve: {
      issuer: IssuerResolver,
      currency: CurrencyResolver,
      paymentFrequency: PaymentFrequencyResolver,
      dayCountConvention: DayCountConventionResolver,
      referenceRate: ReferenceRateResolver
    },
    canDeactivate: [ConfirmDeactivateGuard]
  },
  {
    path: "prices-bond",
    component: BondPricesListComponent
  },
  {
    path: ":id",
    component: BondComponent,
    resolve: {
      issuer: IssuerResolver,
      currency: CurrencyResolver,
      paymentFrequency: PaymentFrequencyResolver,
      dayCountConvention: DayCountConventionResolver,
      referenceRate: ReferenceRateResolver
    },
    canDeactivate: [ConfirmDeactivateGuard]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BondsRoutingRoutingModule {}
