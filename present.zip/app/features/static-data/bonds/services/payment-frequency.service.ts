import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { ConfigService } from "@env/service/config.service";
import { IPaymentFrequency } from "../models/IPaymentFrequency";

@Injectable()
export class PaymentFrequencyService {
  constructor(private http: HttpClient, private configService: ConfigService) { }

  get(): Observable<IPaymentFrequency[]> {
    return this.http.get<IPaymentFrequency[]>(`${this.configService.config.apiBaseurl}/api/PaymentFrequency`);
  }
}
