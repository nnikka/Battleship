import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { ConfigService } from "@env/service/config.service";
import { IDayCountConvention } from "../models/IDayCountConvention";

@Injectable()
export class DayCountConventionService {
  constructor(private http: HttpClient, private configService: ConfigService) {}

  get(): Observable<IDayCountConvention[]> {
    return this.http.get<IDayCountConvention[]>(`${this.configService.config.apiBaseurl}/api/DayCountConvention`);
  }
}
