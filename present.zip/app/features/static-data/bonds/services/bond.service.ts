import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { ConfigService } from "@env/service/config.service";
import { IHttpPagingQueryParams } from "@shared/models/IHttpPagingQueryParams";
import { IPagingHttpResponse } from "@shared/models/IPagingHttpResponse";
import { BondParams } from "../models/BondParams";
import { CouponScheduleParams } from "../models/CouponScheduleParams";
import { IHttpCouponPayment } from "../models/IHttpCouponPayment";
import { IListItemBond } from "../models/IListItemBond";
import { IHttpBond } from "../models/IHttpBond";
import { IBondRateFormValue } from "../models/IBondRateFormValue";
import { ICorrectCouponPaymentDateParam } from "../models/ICorrectCouponPaymentDateParam";

@Injectable()
export class BondService {
  constructor(private http: HttpClient, private configService: ConfigService) { }

  create(params: BondParams): Observable<any> {
    return this.http.post(`${this.configService.config.apiBaseurl}/api/Bonds`, params);
  }

  generateCouponSchedule(params: CouponScheduleParams, bondId?: string): Observable<IHttpCouponPayment[]> {
    let queryStr = "";
    if (bondId) {
      queryStr = `?bondId=${bondId}`;
    }
    return this.http.post<IHttpCouponPayment[]>(
      `${this.configService.config.apiBaseurl}/api/Bonds/GenerateCouponSchedule${queryStr}`,
      params
    );
  }

  getAll(queryParams: IHttpPagingQueryParams): Observable<IPagingHttpResponse<IListItemBond>> {
    const params = queryParams as any;
    return this.http.get<IPagingHttpResponse<IListItemBond>>(`${this.configService.config.apiBaseurl}/api/Bonds`, {
      params
    });
  }

  getBondPrices(queryParams: IHttpPagingQueryParams): Observable<IPagingHttpResponse<any>> {
    const params = queryParams as any;
    return this.http.get<IPagingHttpResponse<any>>(`${this.configService.config.apiBaseurl}/api/Bonds/GetBondPrices`, {
      params
    });
  }

  getById(id: string): Observable<IHttpBond> {
    return this.http.get<IHttpBond>(`${this.configService.config.apiBaseurl}/api/Bonds/${id}`);
  }

  update(id: string, params): Observable<any> {
    params.id = id;
    return this.http.put(`${this.configService.config.apiBaseurl}/api/Bonds/${id}`, params);
  }

  changeAuthorizationStatus(id: string, status: number): Observable<any> {
    return this.http.put(
      `${this.configService.config.apiBaseurl}/api/Bonds/ChangeAuthorizationStatus/${id}/${status}`,
      {}
    );
  }

  correctBondRate(bondId: number | string, data: IBondRateFormValue) {
    const date = data.date.replace(/\//g, "-");
    let defaultPaymentDate = null;
    if (data.defaultPaymentDate) {
      defaultPaymentDate = data.defaultPaymentDate.replace(/\//g, "-");
    }
    let queryStr = `?bondId=${bondId}&rate=${data.rate}&paymentDate=${date}`;
    if (defaultPaymentDate) {
      queryStr += `&defaultPaymentDate=${defaultPaymentDate}`;
    }
    return this.http.post(
      `${this.configService.config.apiBaseurl}/api/Bonds/CorrectBondCouponPaymentReferenceRate${queryStr}`,
      {}
    );
  }

  importExcel(formData): Observable<any> {
    return this.http.post(`${this.configService.config.apiBaseurl}/api/Bonds/ImportExcel`, formData);
  }

  correctBondCouponDates(bondId: string, correctedPaymentDates: ICorrectCouponPaymentDateParam[]) {
    return this.http.post(
      `${this.configService.config.apiBaseurl}/api/Bonds/CorrectBondCouponPaymentDate/${bondId}`,
      correctedPaymentDates
    );
  }


  exportExcel(): Observable<any> {
    return this.http.get(
      `${this.configService.config.apiBaseurl}/api/Bonds/ExportBonds`,
      {
        responseType: "blob"
      }
    );
  }
}
