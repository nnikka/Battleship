import { NgModule } from "@angular/core";

import { StoreModule } from "@ngrx/store";
import { EffectsModule } from "@ngrx/effects";
import { clientsModuleReducers } from "./store/reducer";

import { SharedModule } from "@shared/shared.module";
import { ClientsRoutingRoutingModule } from "./clients-routing.module";
import { ClientsListComponent } from "./containers/clients-list/clients-list.component";
import { AddIndividualComponent } from "./containers/add-individual/add-individual.component";
import { AddLegalComponent } from "./containers/add-legal/add-legal.component";
// tslint:disable-next-line: max-line-length
import { ClientTypeRegistrationSelectorComponent } from "./components/client-type-registration-selector/client-type-registration-selector.component";
import { IndividualClientFormComponent } from "./components/individual-client-form/individual-client-form.component";
import { ClientDataComponent } from "./components/individual-client-form/client-data/client-data.component";

import { ClientStatusService } from "./services/client-status.service";
import { AssetsValueInGelService } from "./services/assets-value-in-gel.service";
import { SourceOfIncomeService } from "./services/source-of-income.service";
import { ClientService } from "./services/client.service";
import { OrganizationActivityService } from "./services/organization-activity.service";
import { EstimatedAnnualTurnoverService } from "./services/estimated-annual-turnover.service";
import { LegalFormService } from "./services/legal-form.service";
import { ClientRiskLevelService } from "./services/client-risk-level.service";
import { AnnualIncomeService } from "./services/annual-income.service";

import { clientsModuleEffects } from "./store/effects";

import { ClientStatusResolver } from "./resolvers/client-status.resolver";
import { AssetsValueInGelResolver } from "./resolvers/assets-value-in-gel.resolver";
import { SourceOfIncomeResolver } from "./resolvers/source-of-income.resolver";
import { OrganizationActivityResolver } from "./resolvers/organization-activity.resolver";
import { EstimatedAnnualTurnoverResolver } from "./resolvers/estimated-annual-turnover.resolver";
import { LegalFormResolver } from "./resolvers/legal-form.resolver";
import { ClientRiskLevelResolver } from "./resolvers/client-risk-level.resolver";
import { AnnualIncomeResolver } from "./resolvers/annual-income.resolver";

import { CitizenshipsComponent } from "./components/individual-client-form/citizenships/citizenships.component";
import { AddressFormComponent } from "./components/address-form/address-form.component";
import { WorkInfoComponent } from "./components/individual-client-form/work-info/work-info.component";
import { ContactInfoFormComponent } from "./components/contact-info-form/contact-info-form.component";
// tslint:disable-next-line: max-line-length
import { IncomeAndAssetsComponent } from "./components/individual-client-form/income-and-assets/income-and-assets.component";
import { OtherInfoFormComponent } from "./components/other-info-form/other-info-form.component";
import { BankRelationshipFormComponent } from "./components/bank-relationship-form/bank-relationship-form.component";
// tslint:disable-next-line: max-line-length
import { AccountsAtCounterpartyFormComponent } from "./components/accounts-at-counterparty-form/accounts-at-counterparty-form.component";
import { DocumentsComponent } from "./components/individual-client-form/documents/documents.component";
import { LegalClientFormComponent } from "./components/legal-client-form/legal-client-form.component";
import { EmitentComponent } from "./components/legal-client-form/emitent/emitent.component";
import { CounterpartyComponent } from "./components/legal-client-form/counterparty/counterparty.component";
import { LegalEntityComponent } from "./components/legal-client-form/legal-entity/legal-entity.component";
// tslint:disable-next-line: max-line-length
import { LegalClientDataComponent } from "./components/legal-client-form/legal-entity/legal-client-data/legal-client-data.component";
// tslint:disable-next-line: max-line-length
import { LegalCompanyInfoComponent } from "./components/legal-client-form/legal-entity/legal-company-info/legal-company-info.component";
import { ClientComponent } from "./containers/client/client.component";
import { IndividualComponent } from "./containers/client/individual/individual.component";
import { IndividualInfoCardComponent } from "./components/individual-info-card/individual-info-card.component";
import { AccountsInfoCardComponent } from "./components/accounts-info-card/accounts-info-card.component";
// tslint:disable-next-line: max-line-length
import { LegalIncomeAndAssetsComponent } from "./components/legal-client-form/legal-entity/legal-income-and-assets/legal-income-and-assets.component";
// tslint:disable-next-line: max-line-length
import { LegalResidencyComponent } from "./components/legal-client-form/legal-entity/legal-residency/legal-residency.component";
// tslint:disable-next-line: max-line-length
import { LegalCompanyRepresentativeComponent } from "./components/legal-client-form/legal-entity/legal-company-representative/legal-company-representative.component";
import { LegalComponent } from "./containers/client/legal/legal.component";
import { LegalInfoCardComponent } from "./components/legal-info-card/legal-info-card.component";
import { IssuerInfoCardComponent } from "./components/legal-info-card/issuer-info-card/issuer-info-card.component";
// tslint:disable-next-line: max-line-length
import { CounterpartyInfoCardComponent } from "./components/legal-info-card/counterparty-info-card/counterparty-info-card.component";
// tslint:disable-next-line: max-line-length
import { LegalDocumentsComponent } from "./components/legal-client-form/legal-entity/legal-documents/legal-documents.component";
// tslint:disable-next-line: max-line-length
import { LegalEntityInfoCardComponent } from "./components/legal-info-card/legal-entity-info-card/legal-entity-info-card.component";
// tslint:disable-next-line: max-line-length
import { AccountsAtCounterpartyInfoCardComponent } from "./components/accounts-at-counterparty-info-card/accounts-at-counterparty-info-card.component";
import { DynamicTitleService } from "@core/services/dynamic-title.service";
import { ClientBalancesModalComponent } from "./components/client-balances-modal/client-balances-modal.component";
import {
  ClintListMailServiceManagementComponent
} from "./containers/clint-list-mail-service-management/clint-list-mail-service-management.component";
import { MailServiceService } from "./services/mail-service.service";
import { AccountStatementModalComponent } from "./components/account-statement-modal/account-statement-modal.component";

@NgModule({
  declarations: [
    ClientsListComponent,
    AddIndividualComponent,
    AddLegalComponent,
    ClientTypeRegistrationSelectorComponent,
    IndividualClientFormComponent,
    ClientDataComponent,
    CitizenshipsComponent,
    AddressFormComponent,
    WorkInfoComponent,
    ContactInfoFormComponent,
    IncomeAndAssetsComponent,
    OtherInfoFormComponent,
    BankRelationshipFormComponent,
    AccountsAtCounterpartyFormComponent,
    DocumentsComponent,
    LegalClientFormComponent,
    EmitentComponent,
    CounterpartyComponent,
    LegalEntityComponent,
    LegalClientDataComponent,
    LegalCompanyInfoComponent,
    ClientComponent,
    IndividualComponent,
    IndividualInfoCardComponent,
    AccountsInfoCardComponent,
    LegalIncomeAndAssetsComponent,
    LegalResidencyComponent,
    LegalCompanyRepresentativeComponent,
    LegalComponent,
    LegalInfoCardComponent,
    IssuerInfoCardComponent,
    CounterpartyInfoCardComponent,
    LegalDocumentsComponent,
    LegalEntityInfoCardComponent,
    AccountsAtCounterpartyInfoCardComponent,
    ClientBalancesModalComponent,
    ClintListMailServiceManagementComponent,
    AccountStatementModalComponent
  ],
  imports: [
    SharedModule,
    ClientsRoutingRoutingModule,

    StoreModule.forFeature("clients", clientsModuleReducers),
    EffectsModule.forFeature(clientsModuleEffects)
  ],
  providers: [
    ClientStatusService,
    AssetsValueInGelService,
    SourceOfIncomeService,
    ClientService,
    OrganizationActivityService,
    EstimatedAnnualTurnoverService,
    LegalFormService,
    ClientRiskLevelService,
    DynamicTitleService,
    AnnualIncomeService,

    ClientStatusResolver,
    AssetsValueInGelResolver,
    SourceOfIncomeResolver,
    OrganizationActivityResolver,
    EstimatedAnnualTurnoverResolver,
    LegalFormResolver,
    ClientRiskLevelResolver,
    AnnualIncomeResolver,
    MailServiceService
  ]
})
export class ClientsModule { }
