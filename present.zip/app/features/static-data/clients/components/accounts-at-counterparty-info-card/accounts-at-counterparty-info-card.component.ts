import { Component, OnInit, Input, ChangeDetectionStrategy } from "@angular/core";
import { IHttpAccountAtCounterpartyCommand } from "../../models/httpModels/IHttpAccountAtCounterpartyCommand";
import { ICurrency } from "@core/models/catalogs/currency.interface";
import { SortDescriptor, orderBy } from "@progress/kendo-data-query";
import { GridDataResult } from "@progress/kendo-angular-grid";
import { ICounterParty } from "@core/models/catalogs/counterParty.interface";
import { getObjectParamFromArray } from "src/utils/array.helper";

@Component({
  selector: "app-accounts-at-counterparty-info-card",
  templateUrl: "./accounts-at-counterparty-info-card.component.html",
  styleUrls: ["./accounts-at-counterparty-info-card.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AccountsAtCounterpartyInfoCardComponent implements OnInit {
  @Input() accounts: IHttpAccountAtCounterpartyCommand[];
  @Input() currencies: ICurrency[];
  @Input() counterParties: ICounterParty[];

  public sort: SortDescriptor[] = [
    {
      field: "clientCounterpartyId",
      dir: "asc"
    }
  ];

  get gridView(): GridDataResult {
    return {
      data: orderBy(this.accounts ? this.accounts : [], this.sort),
      total: this.accounts ? this.accounts.length : 0
    };
  }

  constructor() {}

  ngOnInit() {}

  getCurrencyById(id): string {
    return getObjectParamFromArray(this.currencies, id);
  }

  getCounterpartyBy(id) {
    let result = "";
    this.counterParties.map(counterparty => {
      if (counterparty.id === id) {
        result = counterparty.name;
      }
    });
    return result;
  }

  sortChange($e) {
    this.sort = $e;
  }
}
