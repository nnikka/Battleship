import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { AccountsAtCounterpartyInfoCardComponent } from "./accounts-at-counterparty-info-card.component";

describe("AccountsAtCounterpartyInfoCardComponent", () => {
  let component: AccountsAtCounterpartyInfoCardComponent;
  let fixture: ComponentFixture<AccountsAtCounterpartyInfoCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AccountsAtCounterpartyInfoCardComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountsAtCounterpartyInfoCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
