import { Component, OnInit, Input, Output, EventEmitter, OnDestroy } from "@angular/core";
import { FormGroup, FormBuilder, Validators, FormControl, FormArray } from "@angular/forms";
import { inputSlideInOutAnimation } from "src/app/general/animations/inputSlideInOut.animation";
import { ICurrency } from "@core/models/catalogs/currency.interface";
import { ICounterParty } from "@core/models/catalogs/counterParty.interface";
import { AccountsAtCounterpartyFormValue } from "./AccountsAtCounterpartyFormValue";
import { PopupConfirmService } from "@components/popup-confirm/popup-confirm.service";

@Component({
  selector: "app-accounts-at-counterparty-form",
  templateUrl: "./accounts-at-counterparty-form.component.html",
  styleUrls: ["./accounts-at-counterparty-form.component.scss"],
  animations: [inputSlideInOutAnimation]
})
export class AccountsAtCounterpartyFormComponent implements OnInit {
  @Input() initialFormValue: AccountsAtCounterpartyFormValue;
  @Input() currencies: ICurrency[];
  @Input() counterParties: ICounterParty[];

  @Output() formReady = new EventEmitter<FormGroup>();

  form: FormGroup;

  constructor(private formBuilder: FormBuilder, private popupConfirmService: PopupConfirmService) {}

  ngOnInit() {
    this.form = this.formBuilder.group({
      accounts: this.formBuilder.array([])
    });
    if (this.initialFormValue && this.initialFormValue.accounts && this.initialFormValue.accounts instanceof Array) {
      this.initialFormValue.accounts.map(account => {
        const control = this.form.controls.accounts as FormArray;
        control.push(
          this.formBuilder.group({
            clientCounterpartyId: [account.clientCounterpartyId, [Validators.required]],
            currencyId: [account.currencyId, [Validators.required]],
            clientCodeAtCounterparty: [account.clientCodeAtCounterparty, [Validators.required]]
          })
        );
      });
    }
    this.formReady.emit(this.form);
  }

  getControls(frmGrp: FormGroup, key: string) {
    return (frmGrp.controls[key] as FormArray).controls;
  }

  addAccount() {
    const control = this.form.controls.accounts as FormArray;
    control.push(
      this.formBuilder.group({
        clientCounterpartyId: [null, [Validators.required]],
        currencyId: [null, [Validators.required]],
        clientCodeAtCounterparty: [null, [Validators.required]]
      })
    );
  }

  deleteAccount(i: number) {
    this.popupConfirmService.show(null, null, () => {
      const control = this.form.controls.accounts as FormArray;
      control.removeAt(i);
    });
  }
}
