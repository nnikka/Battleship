import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { AccountsAtCounterpartyFormComponent } from "./accounts-at-counterparty-form.component";

describe("AccountsAtCounterpartyFormComponent", () => {
  let component: AccountsAtCounterpartyFormComponent;
  let fixture: ComponentFixture<AccountsAtCounterpartyFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AccountsAtCounterpartyFormComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountsAtCounterpartyFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
