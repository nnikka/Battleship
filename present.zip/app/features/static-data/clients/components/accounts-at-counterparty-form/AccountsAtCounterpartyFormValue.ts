import { IHttpClient } from "../../models/httpModels/IHttpClient";

export class AccountsAtCounterpartyFormValue {
  accounts: {
    clientCounterpartyId: number;
    currencyId: number;
    clientCodeAtCounterparty: string;
  }[];

  constructor(init?: IHttpClient) {
    this.accounts = init.accountsAtCounterpartyCommand;
  }
}
