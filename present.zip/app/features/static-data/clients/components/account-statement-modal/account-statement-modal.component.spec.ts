import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountStatementModalComponent } from './account-statement-modal.component';

describe('AccountStatementModalComponent', () => {
  let component: AccountStatementModalComponent;
  let fixture: ComponentFixture<AccountStatementModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountStatementModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountStatementModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
