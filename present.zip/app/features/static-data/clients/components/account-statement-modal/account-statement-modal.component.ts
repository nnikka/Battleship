import { Component, OnInit, Input } from "@angular/core";
import { ICurrency } from "@core/models/catalogs/currency.interface";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { MarkFormGroupTouched } from "src/utils/mark-formgroup-touched.helper";
import { ClientService } from "../../services/client.service";
import { FileDownloadService } from "@core/services/file-download.service";
import { NotificationMessageService } from "@core/services/notification-message.service";
import { MailServiceService } from "../../services/mail-service.service";

@Component({
  selector: "app-account-statement-modal",
  templateUrl: "./account-statement-modal.component.html",
  styleUrls: ["./account-statement-modal.component.scss"]
})
export class AccountStatementModalComponent implements OnInit {
  @Input() clientId: string | number = null;
  @Input() currencies: ICurrency[] = [];
  // if true trigger send mails for all clients if not download statement for current client
  @Input() sendMails = false;
  @Input() clientName: string = "";

  isOpen: boolean = false;
  loading: boolean = false;
  form: FormGroup;

  maxDate: Date;

  constructor(
    private formBuilder: FormBuilder,
    private clientService: ClientService,
    private fileDownloadService: FileDownloadService,
    private notificationMessageService: NotificationMessageService,
    private mailServiceService: MailServiceService
  ) {
    const today = new Date();
    today.setDate(today.getDate() - 1);
    this.maxDate = today;
  }

  ngOnInit() {
    this.form = this.formBuilder.group({
      fromDate: [null, [Validators.required]],
      toDate: [null, [Validators.required]],
      aggregationCurrencyId: [null, [Validators.required]],
      clientId: [this.clientId, []]
    });
  }

  openDialog() {
    this.isOpen = true;
  }

  closeDialog() {
    this.isOpen = false;
    this.form.reset();
  }

  onSubmit(isSend) {
    if (!this.form.valid) {
      MarkFormGroupTouched(this.form.controls);
    } else {
      if (this.sendMails || isSend) {
        this.loading = true;
        this.mailServiceService.sendMails(this.form.value, isSend ? this.clientId : undefined).subscribe(
          () => {
            this.notificationMessageService.success("Client Email was send successfully");
            this.loading = false;
          },
          error => {
            this.notificationMessageService.error(error);
            this.loading = false;
          }
        );
      } else {
        this.loading = true;
        this.clientService.exportAccountStatement(this.form.value).subscribe(
          resp => {
            const todate = this.form.get("toDate").value.split("/");
            const mm = todate[0].length === 1 ? "0" + todate[0] : todate[0];
            const dd = todate[1].length === 1 ? "0" + todate[1] : todate[1];
            this.fileDownloadService.downLoadFile(
              `Account Statement_${todate[2]}${mm}${dd}_${this.clientName}.pdf`,
              resp
            );
            this.loading = false;
          },
          err => {
            this.loading = false;
            const reader = new FileReader();
            reader.onload = () => {
              const errors = JSON.parse(reader.result.toString());
              this.notificationMessageService.error(errors.errors[0]);
              delete reader.onload;
            };
            reader.readAsText(err.error);
          }
        );
      }
    }
  }
}
