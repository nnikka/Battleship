import { Component, OnInit, Input, ChangeDetectionStrategy } from "@angular/core";
import { IHttpBankAccountCommand } from "../../models/httpModels/IHttpBankAccountCommand";
import { GridDataResult } from "@progress/kendo-angular-grid";
import { ICurrency } from "@core/models/catalogs/currency.interface";
import { SortDescriptor, orderBy } from "@progress/kendo-data-query";
import { getObjectParamFromArray } from "src/utils/array.helper";

@Component({
  selector: "app-accounts-info-card",
  templateUrl: "./accounts-info-card.component.html",
  styleUrls: ["./accounts-info-card.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AccountsInfoCardComponent implements OnInit {
  @Input() accounts: IHttpBankAccountCommand[];
  @Input() currencies: ICurrency[];

  public sort: SortDescriptor[] = [
    {
      field: "bankName",
      dir: "asc"
    }
  ];

  get gridView(): GridDataResult {
    return {
      data: orderBy(this.accounts ? this.accounts : [], this.sort),
      total: this.accounts ? this.accounts.length : 0
    };
  }

  constructor() {}

  ngOnInit() {}

  getCurrencyById(id): string {
    return getObjectParamFromArray(this.currencies, id);
  }

  sortChange($e) {
    this.sort = $e;
  }
}
