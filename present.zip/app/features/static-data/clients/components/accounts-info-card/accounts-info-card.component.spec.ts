import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { AccountsInfoCardComponent } from "./accounts-info-card.component";

describe("AccountsInfoCardComponent", () => {
  let component: AccountsInfoCardComponent;
  let fixture: ComponentFixture<AccountsInfoCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AccountsInfoCardComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountsInfoCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
