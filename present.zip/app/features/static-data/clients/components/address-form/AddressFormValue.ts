import { IHttpClient } from "../../models/httpModels/IHttpClient";

export class AddressFormValue {
  country: {
    id: number;
    name: string;
  };
  city: string = null;
  street: string = null;
  postalCode: string = null;

  public constructor(type?: string, init?: IHttpClient) {
    if (init.addressCommand) {
      if (type === "legal") {
        this.country = { name: "", id: init.addressCommand.legalAddressCountryId };
        this.city = init.addressCommand.legalAddressCity;
        this.street = init.addressCommand.legalAddressStreet;
        this.postalCode = init.addressCommand.legalAddressPostalCode;
      } else if (type === "actual") {
        this.country = { name: "", id: init.addressCommand.actualAddressCountryId };
        this.city = init.addressCommand.actualAddressCity;
        this.street = init.addressCommand.actualAddressStreet;
        this.postalCode = init.addressCommand.actualAddressPostalCode;
      }
    } else {
      this.country = { name: "", id: null };
    }
  }
}
