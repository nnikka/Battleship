import { Component, OnInit, Input, EventEmitter, Output } from "@angular/core";
import { ICountry } from "@core/models/catalogs/country.interface";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { AddressFormValue } from "./AddressFormValue";
import { CustomValidators } from "src/app/general/validators/custom.validator";

@Component({
  selector: "app-address-form",
  templateUrl: "./address-form.component.html",
  styleUrls: ["./address-form.component.scss"]
})
export class AddressFormComponent implements OnInit {
  @Input() initialFormValue: AddressFormValue;

  @Input() countries: ICountry[];

  @Output() formReady = new EventEmitter<FormGroup>();

  form: FormGroup;

  constructor(private formBuilder: FormBuilder) {}

  ngOnInit() {
    this.form = this.formBuilder.group({
      country: [this.initialFormValue ? this.initialFormValue.country : null, [Validators.required]],
      city: [
        this.initialFormValue ? this.initialFormValue.city : null,
        [Validators.required, CustomValidators.onlyGeoOrLatLetters()]
      ],
      street: [this.initialFormValue ? this.initialFormValue.street : null, [Validators.required]],
      postalCode: [this.initialFormValue ? this.initialFormValue.postalCode : null, [Validators.required]]
    });

    this.formReady.emit(this.form);
  }
}
