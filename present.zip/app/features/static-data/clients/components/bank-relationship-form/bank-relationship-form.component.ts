import { Component, OnInit, Input, Output, EventEmitter, OnDestroy } from "@angular/core";
import { FormGroup, FormBuilder, Validators, FormControl, FormArray } from "@angular/forms";
import { ICurrency } from "@core/models/catalogs/currency.interface";
import { AccountsArrayValidation } from "./helpers/accounts-list.helper";
import { inputSlideInOutAnimation } from "src/app/general/animations/inputSlideInOut.animation";
import { CustomValidators } from "src/app/general/validators/custom.validator";
import { BankRelationshipFormValue } from "./BankRelationshipFormValue";
import { PopupConfirmService } from "@components/popup-confirm/popup-confirm.service";
import { untilDestroyed } from "ngx-take-until-destroy";

@Component({
  selector: "app-bank-relationship-form",
  templateUrl: "./bank-relationship-form.component.html",
  styleUrls: ["./bank-relationship-form.component.scss"],
  animations: [inputSlideInOutAnimation]
})
export class BankRelationshipFormComponent implements OnInit, OnDestroy {
  @Input() initialFormValue: BankRelationshipFormValue;

  @Input() currencies: ICurrency[];

  @Output() formReady = new EventEmitter<FormGroup>();

  form: FormGroup;

  constructor(private formBuilder: FormBuilder, private popupConfirmService: PopupConfirmService) {}

  ngOnInit() {
    this.form = this.formBuilder.group(
      {
        isTBCInsider: [this.initialFormValue ? this.initialFormValue.isTBCInsider : null, [Validators.required]],
        accounts: this.formBuilder.array([])
      },
      { validator: AccountsArrayValidation("accounts") }
    );
    if (this.initialFormValue) {
      this.initialFormValue.accounts.map(account => {
        this.addAccount(account);
      });
    } else {
      // this.addAccount();
    }
    this.formReady.emit(this.form);
  }

  getControls(frmGrp: FormGroup, key: string) {
    return (frmGrp.controls[key] as FormArray).controls;
  }

  addAccount(account?) {
    const control = this.form.controls.accounts as FormArray;
    const formGroup = this.formBuilder.group({
      isTBCAccount: [account ? account.isTBCAccount : null, [Validators.required]],
      bankName: [
        { value: account ? account.bankName : null, disabled: account && account.isTBCAccount ? true : false },
        [Validators.required, CustomValidators.onlyLatLettersAndNumbers()]
      ],
      swiftCode: [
        { value: account ? account.swiftCode : null, disabled: account && account.isTBCAccount ? true : false },
        [Validators.required, CustomValidators.onlyLatLettersAndNumbers()]
      ],
      receiverName: [
        account ? account.receiverName : null,
        [Validators.required, CustomValidators.onlyLatLettersAndNumbers()]
      ],
      accountNumber: [
        account ? account.accountNumber : null,
        [Validators.required, CustomValidators.onlyLatLettersAndNumbers()]
      ],
      currencyId: [account ? account.currencyId : null, [Validators.required]],
      accountComment: [account ? account.accountComment : null, []],
      defaultCurrencyAccount: [account ? account.defaultCurrencyAccount : false, [Validators.required]]
    });

    control.push(formGroup);

    formGroup
      .get("isTBCAccount")
      .valueChanges.pipe(untilDestroyed(this))
      .subscribe((val: boolean) => {
        formGroup.get("receiverName").setValue(null);
        formGroup.get("accountNumber").setValue(null);
        formGroup.get("currencyId").setValue(null);
        formGroup.get("accountComment").setValue(null);
        formGroup.get("defaultCurrencyAccount").setValue(false);

        if (val) {
          formGroup.get("bankName").setValue("JSC TBC Bank");
          formGroup.get("swiftCode").setValue("TBCBGE22");
          formGroup.get("swiftCode").disable();
          formGroup.get("bankName").disable();
        } else {
          formGroup.get("bankName").setValue("");
          formGroup.get("swiftCode").setValue("");
          formGroup.get("swiftCode").enable();
          formGroup.get("bankName").enable();
        }
      });
  }

  deleteAccount(i: number) {
    this.popupConfirmService.show(null, null, () => {
      const control = this.form.controls.accounts as FormArray;
      control.removeAt(i);
      this.form.markAsDirty();
    });
  }

  ngOnDestroy() {}
}
