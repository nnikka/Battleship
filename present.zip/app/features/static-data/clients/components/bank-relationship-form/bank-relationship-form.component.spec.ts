import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { BankRelationshipFormComponent } from "./bank-relationship-form.component";

describe("BankRelationshipFormComponent", () => {
  let component: BankRelationshipFormComponent;
  let fixture: ComponentFixture<BankRelationshipFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BankRelationshipFormComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BankRelationshipFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
