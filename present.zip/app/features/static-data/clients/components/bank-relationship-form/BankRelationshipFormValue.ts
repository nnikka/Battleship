import { IHttpClient } from "../../models/httpModels/IHttpClient";

export class BankRelationshipFormValue {
  isTBCInsider: boolean;
  accounts: {
    isTBCAccount: boolean;
    bankName: string;
    swiftCode: string;
    receiverName: string;
    accountNumber: string;
    currencyId: number;
    accountComment: string;
    defaultCurrencyAccount: boolean;
  }[];

  public constructor(init?: IHttpClient) {
    this.isTBCInsider = init.isTBCInsider;
    this.accounts = [];
    if (init.bankAccountsCommand) {
      init.bankAccountsCommand.map(account => {
        this.accounts.push({
          isTBCAccount: account.isTBCAccount,
          bankName: account.bankName,
          swiftCode: account.swiftCode,
          receiverName: account.receiverName,
          accountNumber: account.accountNumber,
          currencyId: account.currencyId,
          accountComment: account.accountComment,
          defaultCurrencyAccount: account.defaultCurrencyAccount
        });
      });
    }
  }
}
