import { FormGroup, FormArray, FormControl } from "@angular/forms";

export function AccountsArrayValidation(accountsArrayName: string) {
  return (formGroup: FormGroup) => {
    const accountsControl = formGroup.controls[accountsArrayName] as FormArray;

    const accountsControlArray = accountsControl.controls;

    const accountsByUnicParams: string[] = [];

    const accountsByCurrency = {};

    accountsControlArray.map((accountControl: FormGroup) => {
      // Save accounts by unic params (as strings) in accountsByUnicParams
      if (
        accountControl.controls.bankName.value &&
        accountControl.controls.accountNumber.value &&
        accountControl.controls.currencyId.value
      ) {
        accountsByUnicParams.push(
          "" +
            accountControl.controls.bankName.value +
            "$" +
            accountControl.controls.accountNumber.value +
            "$" +
            accountControl.controls.currencyId.value
        );
      }

      // Save accounts by currnecyId in accountsByCurrency
      if (accountControl.controls.currencyId.value) {
        if (!accountsByCurrency[accountControl.controls.currencyId.value]) {
          accountsByCurrency[accountControl.controls.currencyId.value] = {
            defaults: [],
            notDefault: [],
            sumCount: 0
          };
        }
        if (accountControl.controls.currencyId.value) {
          accountsByCurrency[accountControl.controls.currencyId.value].defaults.push(
            accountControl.controls.currencyId
          );
          accountsByCurrency[accountControl.controls.currencyId.value].sumCount++;
        } else {
          accountsByCurrency[accountControl.controls.currencyId.value].notDefault.push(
            accountControl.controls.currencyId
          );
          accountsByCurrency[accountControl.controls.currencyId.value].sumCount++;
        }
      }
    });

    // Validation:
    // accounts with same currencyId must have 1 defaultCurrencyAccount marked as true
    // Object.keys(accountsByCurrency).map(curkey => {
    //   const cur = accountsByCurrency[curkey];
    //   if (cur.defaults.length > 1) {
    //     cur.defaults.map((control: FormControl) => {
    //       control.setErrors({ ManyDefaultAccounts: true });
    //     });
    //   } else {
    //     cur.defaults.map((control: FormControl) => {
    //       control.setErrors({ ManyDefaultAccounts: false });
    //     });
    //   }
    //   if (cur.defaults.length < 1) {
    //     cur.defaults.map((control: FormControl) => {
    //       control.setErrors({ NoDefaultAccount: true });
    //     });
    //   } else {
    //     cur.defaults.map((control: FormControl) => {
    //       control.setErrors({ NoDefaultAccount: false });
    //     });
    //   }
    //   if (cur.defaults.length === 1) {
    //     cur.defaults.map((control: FormControl) => {
    //       control.setErrors(null);
    //     });
    //     cur.defaults.map((control: FormControl) => {
    //       control.setErrors(null);
    //     });
    //   }
    // });

    // Validation:
    // accounts with same currencyId, bankName and accountName is not allowed
    const cache = {};
    const results = [];
    for (let i = 0, len = accountsByUnicParams.length; i < len; i++) {
      if (cache[accountsByUnicParams[i]] === true) {
      } else {
        cache[accountsByUnicParams[i]] = true;
      }
    }
    for (let i = 0, len = accountsByUnicParams.length; i < len; i++) {}

    accountsControlArray.map((accountControl: FormGroup) => {
      if (
        accountControl.controls.bankName.value &&
        accountControl.controls.bankName.value &&
        accountControl.controls.bankName.value &&
        results.includes(
          "" +
            accountControl.controls.bankName.value +
            "$" +
            accountControl.controls.bankName.value +
            "$" +
            accountControl.controls.bankName.value
        )
      ) {
        accountControl.setErrors({ unicBankAccount: true });
        accountControl.setErrors({ unicBankAccount: true });
        accountControl.setErrors({ unicBankAccount: true });
      } else {
        accountControl.setErrors(null);
        accountControl.setErrors(null);
        accountControl.setErrors(null);
      }
    });
  };
}
