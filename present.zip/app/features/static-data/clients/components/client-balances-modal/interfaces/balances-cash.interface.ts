export interface IBalancesCashHttp {
  amount: number;
  clientCounterpartyId: number;
  clientCounterpartyName: string;
  currencyName: string;
  id: number;
  pledgedAmount: number;
  totalAvailable?: number;
}
