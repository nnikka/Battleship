import { IBalancesBondHttp } from "./balances-bond.interface";
import { IBalancesCashHttp } from "./balances-cash.interface";
import { IBalancesStockHttp } from "./balances-stock.interface";

export interface IBalancesHttp {
  bondBalances: IBalancesBondHttp[];
  cashBalances: IBalancesCashHttp[];
  stockBalances: IBalancesStockHttp[];
}
