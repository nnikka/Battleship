export interface IBalancesStockHttp {
  clientCounterpartyName: string;
  currencyName: string;
  id: number;
  name: string;
  quantity: number;
  stockId: number;
  ticker: string;
  pledgedAmount: number;
  stockPrice: number;
  net: number;
}
