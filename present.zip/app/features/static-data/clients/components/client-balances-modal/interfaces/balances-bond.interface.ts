export interface IBalancesBondHttp {
  amount: number;
  bondId: number;
  clientName: string;
  currencyName: string;
  id: number;
  name: string;
  pledgedAmount: number;
  totalAvailable?: number;
}
