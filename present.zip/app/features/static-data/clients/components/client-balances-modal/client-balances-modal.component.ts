import { Component, OnInit, Input } from "@angular/core";
import { IBalancesHttp } from "./interfaces/balances.interface";
import { ClientService } from "../../services/client.service";
import { IBalancesCashHttp } from "./interfaces/balances-cash.interface";
import { IBalancesBondHttp } from "./interfaces/balances-bond.interface";
import { IntlService } from "@progress/kendo-angular-intl";
import { IBalancesStockHttp } from "./interfaces/balances-stock.interface";
import { combineLatest } from "rxjs";
import { CurrencyService } from "@core/services/catalogs/currency.service";
import { map } from "rxjs/operators";
import { IRatesForCurrency } from "@core/models/catalogs/currency.interface";

@Component({
  selector: "app-client-balances-modal",
  templateUrl: "./client-balances-modal.component.html",
  styleUrls: ["./client-balances-modal.component.scss"]
})
export class ClientBalancesModalComponent implements OnInit {
  opened = false;
  @Input() clientId;

  balancesData: IBalancesHttp;
  totalNetInUSD: number = 0;

  constructor(
    private clientService: ClientService,
    public intl: IntlService,
    private currencyService: CurrencyService
  ) {}

  ngOnInit() {
    if (this.clientId) {
      combineLatest([
        this.clientService.getClientBalances(this.clientId),
        this.currencyService.getRatesForSingleCurrency(2, null)
      ])
        .pipe(map(([balances, rates]) => ({ balances, rates })))
        .subscribe(resp => {
          this.balancesData = this.constructBalances(resp.balances, resp.rates);
        });
    }
  }

  constructBalances(balances: IBalancesHttp, rates: IRatesForCurrency): IBalancesHttp {
    let totalNetInUSD = 0;
    const constructedRates = {};

    for (const rate of rates.rates) {
      constructedRates[rate.fromCurrency.name] = rate.rate;
    }

    const result: IBalancesHttp = {
      cashBalances: [],
      stockBalances: [],
      bondBalances: []
    };

    // construce cash balances
    if (balances.cashBalances) {
      const sortedCashBalances: IBalancesCashHttp[] = balances.cashBalances.sort((a, b) =>
        a.currencyName > b.currencyName ? 1 : a.currencyName === b.currencyName ? (a.amount > b.amount ? 1 : -1) : -1
      );
      let curCurrency = null;
      let curSum = 0;
      let curPledged = 0;
      let curAva = 0;
      for (const bal of sortedCashBalances) {
        if (curCurrency === bal.currencyName) {
          curSum += bal.amount;
          curAva = curAva + bal.amount + bal.pledgedAmount;
          curPledged += bal.pledgedAmount;
          result.cashBalances.push(bal);
        } else {
          if (curCurrency) {
            result.cashBalances.push({
              id: -1,
              amount: curSum,
              clientCounterpartyId: null,
              clientCounterpartyName: null,
              currencyName: curCurrency,
              pledgedAmount: curPledged,
              totalAvailable: curAva
            });
            if (curCurrency === "USD") {
              totalNetInUSD += curAva;
            } else {
              totalNetInUSD += constructedRates[curCurrency] ? constructedRates[curCurrency] * curAva : 0;
            }
          }
          curCurrency = bal.currencyName;
          curSum = bal.amount;
          curAva = bal.amount + bal.pledgedAmount;
          curPledged = bal.pledgedAmount;
          result.cashBalances.push(bal);
        }
      }
      result.cashBalances.push({
        id: -1,
        amount: curSum,
        clientCounterpartyId: null,
        clientCounterpartyName: null,
        currencyName: curCurrency,
        pledgedAmount: curPledged,
        totalAvailable: curAva
      });
      if (curCurrency === "USD") {
        totalNetInUSD += curAva;
      } else {
        totalNetInUSD += constructedRates[curCurrency] ? constructedRates[curCurrency] * curAva : 0;
      }
    }

    // construct bond balances
    if (balances.bondBalances) {
      const sortedBondBalances: IBalancesBondHttp[] = balances.bondBalances.sort((a, b) =>
        a.currencyName > b.currencyName ? 1 : a.currencyName === b.currencyName ? (a.amount > b.amount ? 1 : -1) : -1
      );
      let curCurrency = null;
      let curSum = 0;
      let curPledged = 0;
      let curAva = 0;
      for (const bal of sortedBondBalances) {
        if (curCurrency === bal.currencyName) {
          curSum += bal.amount;
          curAva = curAva + bal.amount + bal.pledgedAmount;
          curPledged += bal.pledgedAmount;
          result.bondBalances.push(bal);
        } else {
          if (curCurrency) {
            result.bondBalances.push({
              id: -1,
              bondId: null,
              name: null,
              amount: curSum,
              currencyName: curCurrency,
              clientName: null,
              pledgedAmount: curPledged,
              totalAvailable: curAva
            });
            if (curCurrency === "USD") {
              totalNetInUSD += curAva;
            } else {
              totalNetInUSD += constructedRates[curCurrency] ? constructedRates[curCurrency] * curAva : 0;
            }
          }
          curCurrency = bal.currencyName;
          curSum = bal.amount;
          curAva = bal.amount + bal.pledgedAmount;
          curPledged = bal.pledgedAmount;
          result.bondBalances.push(bal);
        }
      }
      result.bondBalances.push({
        id: -1,
        bondId: null,
        name: null,
        amount: curSum,
        currencyName: curCurrency,
        clientName: null,
        pledgedAmount: curPledged,
        totalAvailable: curAva
      });
      if (curCurrency === "USD") {
        totalNetInUSD += curAva;
      } else {
        totalNetInUSD += constructedRates[curCurrency] ? constructedRates[curCurrency] * curAva : 0;
      }
    }

    // construnct stock balances
    if (balances.stockBalances) {
      const sortedStockBalances: IBalancesStockHttp[] = balances.stockBalances.sort((a, b) =>
        a.currencyName > b.currencyName
          ? 1
          : a.currencyName === b.currencyName
          ? a.quantity > b.quantity
            ? 1
            : -1
          : -1
      );
      let curCurrency = null;
      let net = null;
      for (const bal of sortedStockBalances) {
        if (curCurrency === bal.currencyName) {
          net = net + (bal.quantity + bal.pledgedAmount) * bal.stockPrice;
          result.stockBalances.push(bal);
        } else {
          if (curCurrency) {
            result.stockBalances.push({
              clientCounterpartyName: null,
              currencyName: curCurrency,
              id: -1,
              name: null,
              quantity: null,
              stockId: null,
              ticker: null,
              pledgedAmount: null,
              stockPrice: null,
              net
            });
            if (curCurrency === "USD") {
              totalNetInUSD += net;
            } else {
              totalNetInUSD += constructedRates[curCurrency] ? constructedRates[curCurrency] * net : 0;
            }
          }
          curCurrency = bal.currencyName;
          net = (bal.quantity + bal.pledgedAmount) * bal.stockPrice;
          result.stockBalances.push(bal);
        }
      }
      result.stockBalances.push({
        clientCounterpartyName: null,
        currencyName: curCurrency,
        id: -1,
        name: null,
        quantity: null,
        stockId: null,
        ticker: null,
        pledgedAmount: null,
        stockPrice: null,
        net
      });
      if (curCurrency === "USD") {
        totalNetInUSD += net;
      } else {
        totalNetInUSD += constructedRates[curCurrency] ? constructedRates[curCurrency] * net : 0;
      }
    }

    this.totalNetInUSD = totalNetInUSD;

    return result;
  }

  public close() {
    this.opened = false;
  }

  public open() {
    this.opened = true;
  }
}
