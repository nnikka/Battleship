import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { ClientBalancesModalComponent } from "./client-balances-modal.component";

describe("ClientBalancesModalComponent", () => {
  let component: ClientBalancesModalComponent;
  let fixture: ComponentFixture<ClientBalancesModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ClientBalancesModalComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientBalancesModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
