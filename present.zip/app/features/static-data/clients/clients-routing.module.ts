import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { ClientsListComponent } from "./containers/clients-list/clients-list.component";
import { AddIndividualComponent } from "./containers/add-individual/add-individual.component";
import { AddLegalComponent } from "./containers/add-legal/add-legal.component";
import { ClientComponent } from "./containers/client/client.component";

import { ClientStatusResolver } from "./resolvers/client-status.resolver";
import { AssetsValueInGelResolver } from "./resolvers/assets-value-in-gel.resolver";
import { SourceOfIncomeResolver } from "./resolvers/source-of-income.resolver";
import { CounterPartyResolver } from "@core/resolvers/catalogs/counterParty.resolver";
import { OrganizationActivityResolver } from "./resolvers/organization-activity.resolver";
import { EstimatedAnnualTurnoverResolver } from "./resolvers/estimated-annual-turnover.resolver";
import { LegalFormResolver } from "./resolvers/legal-form.resolver";
import { ClientRiskLevelResolver } from "./resolvers/client-risk-level.resolver";
import { AnnualIncomeResolver } from "./resolvers/annual-income.resolver";

import { ConfirmDeactivateGuard } from "@core/guards/confirm-deactivate-guard.guard";
import {
  ClintListMailServiceManagementComponent
} from "./containers/clint-list-mail-service-management/clint-list-mail-service-management.component";

const routes: Routes = [
  {
    path: "",
    component: ClientsListComponent,
    resolve: {
      clientStatuse: ClientStatusResolver
    }
  },
  {
    path: "add-individual",
    component: AddIndividualComponent,
    resolve: {
      clientStatuse: ClientStatusResolver,
      assetsValueInGel: AssetsValueInGelResolver,
      sourceOfIncome: SourceOfIncomeResolver,
      counterParty: CounterPartyResolver,
      clientRiskLevel: ClientRiskLevelResolver,
      annualIncome: AnnualIncomeResolver
    },
    canDeactivate: [ConfirmDeactivateGuard]
  },
  {
    path: "add-legal",
    component: AddLegalComponent,
    resolve: {
      clientStatuse: ClientStatusResolver,
      assetsValueInGel: AssetsValueInGelResolver,
      sourceOfIncome: SourceOfIncomeResolver,
      counterParty: CounterPartyResolver,
      organizationActivity: OrganizationActivityResolver,
      estimatedAnnualTurnover: EstimatedAnnualTurnoverResolver,
      legalForm: LegalFormResolver,
      clientRiskLevel: ClientRiskLevelResolver,
      annualIncome: AnnualIncomeResolver
    },
    canDeactivate: [ConfirmDeactivateGuard]
  },
  {
    path: "client-mail-service",
    component: ClintListMailServiceManagementComponent
  },
  {
    path: ":id",
    component: ClientComponent,
    resolve: {
      clientStatuse: ClientStatusResolver,
      assetsValueInGel: AssetsValueInGelResolver,
      sourceOfIncome: SourceOfIncomeResolver,
      counterParty: CounterPartyResolver,
      organizationActivity: OrganizationActivityResolver,
      estimatedAnnualTurnover: EstimatedAnnualTurnoverResolver,
      legalForm: LegalFormResolver,
      clientRiskLevel: ClientRiskLevelResolver,
      annualIncome: AnnualIncomeResolver
    },
    canDeactivate: [ConfirmDeactivateGuard]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ClientsRoutingRoutingModule { }
