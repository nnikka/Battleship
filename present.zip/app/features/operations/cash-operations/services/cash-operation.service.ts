import { Injectable } from "@angular/core";
import { ConfigService } from "@env/service/config.service";
import { Observable } from "rxjs";
import { IPagingHttpResponse } from "@shared/models/IPagingHttpResponse";
import { ICashOperationHttpInterface } from "../interfaces/cash-operation-http.interface";
import { HttpClient } from "@angular/common/http";

@Injectable()
export class CashOperationService {
  constructor(private http: HttpClient, private configService: ConfigService) {}

  getClientBankAccounts(clientId, currencyId) {
    return this.http.get(
      `${this.configService.config.apiBaseurl}/api/CashOperations/GetClientBankAccounts/${clientId}/${currencyId}`
    );
  }

  getAll(queryParams): Observable<IPagingHttpResponse<ICashOperationHttpInterface>> {
    return this.http.get<IPagingHttpResponse<ICashOperationHttpInterface>>(
      `${this.configService.config.apiBaseurl}/api/CashOperations`,
      {
        params: queryParams
      }
    );
  }

  create(formData: ICashOperationHttpInterface) {
    return this.http.post(`${this.configService.config.apiBaseurl}/api/CashOperations`, formData);
  }

  getById(id: string): Observable<ICashOperationHttpInterface> {
    return this.http.get<ICashOperationHttpInterface>(
      `${this.configService.config.apiBaseurl}/api/CashOperations/${id}`
    );
  }

  update(id: string, params): Observable<any> {
    params.id = id;
    return this.http.put(`${this.configService.config.apiBaseurl}/api/CashOperations/${id}`, params);
  }

  changeAuthorizationStatus(id: string, status: number): Observable<any> {
    return this.http.put(
      `${this.configService.config.apiBaseurl}/api/CashOperations/ChangeAuthorizationStatus/${id}/${status}`,
      {}
    );
  }

  exportExcel(): Observable<any> {
    return this.http.get(
      `${this.configService.config.apiBaseurl}/api/CashOperations/ExportCashOperationsWithTransaction`,
      {
        responseType: "blob"
      }
    );
  }

  transferFromCounterPartyWithdraw(operationId: string): Observable<any> {
    return this.http.post(
      `${this.configService.config.apiBaseurl}/api/CashOperations/CreateWithdrawalOperation`,
      {},
      { params: { operationId } }
    );
  }
}
