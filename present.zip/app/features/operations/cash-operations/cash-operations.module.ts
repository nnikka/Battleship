import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { CashOperationsRoutingModule } from "./cash-operations-routing.module";
import { CashOperationsListComponent } from "./containers/cash-operations-list/cash-operations-list.component";
import { CashOperationAddComponent } from "./containers/cash-operation-add/cash-operation-add.component";
import { CashOperationComponent } from "./containers/cash-operation/cash-operation.component";
import { SharedModule } from "@shared/shared.module";
// tslint:disable-next-line: max-line-length
import { CashOperationTypeSelectorComponent } from "./components/cash-operation-type-selector/cash-operation-type-selector.component";
import { CashOperationFormComponent } from "./components/cash-operation-form/cash-operation-form.component";
// tslint:disable-next-line: max-line-length
import { CashOperationParticipantsFormComponent } from "./components/cash-operation-participants-form/cash-operation-participants-form.component";
import {
  CashOperationParticipantFormComponent
  // tslint:disable-next-line: max-line-length
} from "./components/cash-operation-participants-form/cash-operation-participant-form/cash-operation-participant-form.component";
import { CashOperationCardComponent } from "./components/cash-operation-card/cash-operation-card.component";
import { CashOperationService } from "./services/cash-operation.service";

@NgModule({
  declarations: [
    CashOperationsListComponent,
    CashOperationAddComponent,
    CashOperationComponent,
    CashOperationTypeSelectorComponent,
    CashOperationFormComponent,
    CashOperationParticipantsFormComponent,
    CashOperationParticipantFormComponent,
    CashOperationCardComponent
  ],
  imports: [CommonModule, SharedModule, CashOperationsRoutingModule],
  providers: [CashOperationService]
})
export class CashOperationsModule {}
