export enum ECashOperationAuthorizationStatuses {
  Unauthorized = 1,
  Authorized = 2
}

export enum ECashOperationAuthorizationStatusesColors {
  Unauthorized = "#ffc107",
  Authorized = "#00a3e0"
}
