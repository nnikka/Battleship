export enum ECashOperationTypes {
  TransferFromCounterparty = 1,
  TransferToCounterparty = 2,
  Withdrawal = 4,
  Deposit = 8,
  BrokerInterestPaid = 16,
  BrokerInterestReceived = 32,
  InactivityFee = 64,
  MonthlyFee = 128,
  WithdrawalFee = 256
}
