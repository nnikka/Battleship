import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { CashOperationsListComponent } from "./containers/cash-operations-list/cash-operations-list.component";
import { ConfirmDeactivateGuard } from "@core/guards/confirm-deactivate-guard.guard";
import { CashOperationAddComponent } from "./containers/cash-operation-add/cash-operation-add.component";
import { CashOperationComponent } from "./containers/cash-operation/cash-operation.component";

const routes: Routes = [
  {
    path: "",
    component: CashOperationsListComponent
  },
  {
    path: "add-cash-operation",
    component: CashOperationAddComponent,
    canDeactivate: [ConfirmDeactivateGuard]
  },
  {
    path: ":id",
    component: CashOperationComponent,
    canDeactivate: [ConfirmDeactivateGuard]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CashOperationsRoutingModule {}
