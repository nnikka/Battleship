export interface ICashOperationParticipantsFormInterface {
  cashOperationClients: IParticipantCommandInterface[];
}
export interface IParticipantCommandInterface {
  clientId: number;
  amount: number;
  feeAmount: number;
  bankAccountId?: string;
  surcharge: boolean;
  amountToReceive: number;
  balance: number;
}
