import {
  ICashOperationParticipantsFormInterface,
  IParticipantCommandInterface
} from "./cash-operation-participants-form.interface";
import { IAuditCommand } from "@core/models/commands/IAuditCommand";
import { IParticipantHttpCommandInterface } from "./cash-operation-participants-http.interface";
import { IOperationTransaction } from "@core/models/IOperationTransaction";

export interface ICashOperationHttpInterface {
  audit?: IAuditCommand;
  operationDate: string;
  operationTransactions: IOperationTransaction[];
  operationStatus: number;
  settlementDate: string;
  operationType: number;
  operationTypeName: string;
  clientCounterpartyId: string;
  clientCounterpartyName: string;
  currencyId: string;
  currencyName: string;
  amount: number;
  netAmount: number;
  feeAmount: number;
  feeCurrencyId: number;
  feeCurrencyName: string;
  cashOperationClients: IParticipantHttpCommandInterface[];
  comment: string;
  withrawalOperationId: number;
}
