export interface ICashOperationParticipantsFormInterface {
  cashOperationClients: IParticipantHttpCommandInterface[];
}
export interface IParticipantHttpCommandInterface {
  clientId: number;
  clientName: string;
  amount: number;
  feeAmount: number;
  bankAccountId?: string;
  bankAccountNumber: string;
  surcharge: boolean;
  amountToReceive: number;
  balance: number;
}
