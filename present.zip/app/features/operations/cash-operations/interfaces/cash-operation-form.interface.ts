import {
  ICashOperationParticipantsFormInterface,
  IParticipantCommandInterface
} from "./cash-operation-participants-form.interface";

export interface ICashOperationFormInterface {
  operationDate: string;
  settlementDate: string;
  operationType: number;
  clientCounterpartyId: string;
  currencyId: string;
  amount: number;
  netAmount: number;
  feeAmount: number;
  feeCurrencyId: number;
  cashOperationClients: IParticipantCommandInterface[];
  comment: string;
}
