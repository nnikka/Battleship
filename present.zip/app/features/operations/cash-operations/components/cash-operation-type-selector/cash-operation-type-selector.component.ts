import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";

@Component({
  selector: "app-cash-operation-type-selector",
  templateUrl: "./cash-operation-type-selector.component.html",
  styleUrls: ["./cash-operation-type-selector.component.scss"]
})
export class CashOperationTypeSelectorComponent implements OnInit {

  cashOperationTypes: string[] = [
    "Transfer to counterparty",
    "Transfer from counterparty",
    "Withdrawal",
    "Deposit",
    "Broker interest paid",
    "Broker interest received",
    "Inactivity fee",
    "Monthly fee"
    // "Withdrawal fee"
  ];
  selectedType: string = null;

  constructor(private router: Router) { }

  ngOnInit() { }

  redirectToAddCashOperation(e: string) {
    this.router.navigate(["admin/operations/cash/add-cash-operation", {
      // convert to upper case
      operationType: e.replace(/\s+(\w)?/gi, (match, letter) => {
        return letter.toUpperCase();
      })
    }]);
  }
}
