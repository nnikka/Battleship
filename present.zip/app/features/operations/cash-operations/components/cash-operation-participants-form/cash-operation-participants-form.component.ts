import { Component, OnInit, Input, ChangeDetectorRef } from "@angular/core";
import {
  Controls,
  NgxFormWithArrayControls,
  ArrayPropertyKey,
  NgxSubFormRemapComponent,
  ArrayPropertyValue,
  subformComponentProviders,
  FormUpdate
} from "ngx-sub-form";
import {
  ICashOperationParticipantsFormInterface,
  IParticipantCommandInterface
} from "../../interfaces/cash-operation-participants-form.interface";
import { FormControl, FormArray, Validators } from "@angular/forms";
import { ECashOperationTypes } from "../../enums/operation.enum";
import { PopupConfirmService } from "@components/popup-confirm/popup-confirm.service";
import { untilDestroyed } from "ngx-take-until-destroy";

@Component({
  selector: "app-cash-operation-participants-form",
  templateUrl: "./cash-operation-participants-form.component.html",
  styleUrls: ["./cash-operation-participants-form.component.scss"],
  providers: subformComponentProviders(CashOperationParticipantsFormComponent)
})
export class CashOperationParticipantsFormComponent
  extends NgxSubFormRemapComponent<IParticipantCommandInterface[], ICashOperationParticipantsFormInterface>
  implements NgxFormWithArrayControls<ICashOperationParticipantsFormInterface>, OnInit {
  protected emitInitialValueOnInit = false;

  @Input() operationType;
  @Input() currencyId;

  get isIbanVisible() {
    return this.operationType === ECashOperationTypes.Withdrawal;
  }
  get isFeeVisible() {
    return this.operationType !== ECashOperationTypes.Deposit
      && this.operationType !== ECashOperationTypes.BrokerInterestReceived;
  }
  get isFeeOrInterestPaid() {
    return this.operationType === ECashOperationTypes.BrokerInterestPaid
      || this.operationType === ECashOperationTypes.InactivityFee
      || this.operationType === ECashOperationTypes.MonthlyFee;
  }

  get isInterestReceived() {
    return this.operationType === ECashOperationTypes.BrokerInterestReceived;
  }

  constructor(private popupConfirmService: PopupConfirmService, private ref: ChangeDetectorRef) {
    super();
  }

  ngOnInit(): void {
    super.validate();
  }
  // TODO(giorgi): implement this metod for simple hook value changes
  onFormUpdate(val: FormUpdate<ICashOperationParticipantsFormInterface>) { }

  addParticipant(): void {
    this.formGroupControls.cashOperationClients.push(
      this.createFormArrayControl("cashOperationClients", {
        clientId: null,
        amount: null,
        feeAmount: 0,
        bankAccountId: null,
        surcharge: false,
        amountToReceive: null,
        balance: 0
      })
    );
    // FIXME(giorgi): check add logic on update first add throws error
    this.ref.detectChanges();
  }
  public deleteAccount(index: number): void {
    this.popupConfirmService.show(null, null, () => {
      this.formGroupControls.cashOperationClients.removeAt(index);
    });
  }

  protected transformToFormGroup(obj: IParticipantCommandInterface[]): ICashOperationParticipantsFormInterface {
    return {
      cashOperationClients: obj ? obj : []
    };
  }
  protected transformFromFormGroup(
    formValue: ICashOperationParticipantsFormInterface
  ): IParticipantCommandInterface[] | null {
    if (this.isFeeOrInterestPaid) {
      for (const vl of formValue.cashOperationClients) {
        vl.amount = 0;
        vl.surcharge = false;
      }
    }
    return formValue.cashOperationClients;
  }

  protected getFormControls(): Controls<ICashOperationParticipantsFormInterface> {
    return {
      cashOperationClients: new FormArray([])
    };
  }

  /**
   * can add validations based on some parameters optional
   * @param key key parameter to form typesafe
   * @param value value for the control shape of the each form instance in formarray
   */
  createFormArrayControl(
    key: ArrayPropertyKey<ICashOperationParticipantsFormInterface> | undefined,
    value: ArrayPropertyValue<ICashOperationParticipantsFormInterface>
  ): FormControl {
    return new FormControl(value);
  }
}
