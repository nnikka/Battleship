import { Component, OnInit, Input, ChangeDetectorRef, AfterViewInit } from "@angular/core";
import {
  IParticipantCommandInterface
} from "@features/operations/cash-operations/interfaces/cash-operation-participants-form.interface";

import { untilDestroyed } from "ngx-take-until-destroy";

import { NgxSubFormComponent, Controls, subformComponentProviders, FormUpdate } from "ngx-sub-form";
import { FormControl, Validators } from "@angular/forms";
import { EClientStatuses } from "@features/static-data/clients/models/ClientStatuses.enum";
import { CashOperationService } from "@features/operations/cash-operations/services/cash-operation.service";
import { BehaviorSubject } from "rxjs";
import { NotificationMessageService } from "@core/services/notification-message.service";
import { distinctUntilChanged } from "rxjs/operators";
import { IntlService } from "@progress/kendo-angular-intl";

@Component({
  // tslint:disable-next-line: component-selector
  selector: "[app-cash-operation-participant-form]",
  templateUrl: "./cash-operation-participant-form.component.html",
  styleUrls: ["./cash-operation-participant-form.component.scss"],
  providers: subformComponentProviders(CashOperationParticipantFormComponent)
})
export class CashOperationParticipantFormComponent extends NgxSubFormComponent<IParticipantCommandInterface>
  implements OnInit {
  // TODO(giorgi): newer ever forget this value
  // it will make form with input data pristine
  protected emitInitialValueOnInit = false;
  authorizedCounterPartyRequiredHttpParams: any = {
    "filterItem.status": EClientStatuses.Authorized,
    SortBy: "clientNameEng",
    SortDirection: 0
  };

  initialRun = true;

  @Input() index;
  @Input() isIbanVisible;
  @Input() isFeeVisible;
  @Input() isFeeOrInterestPaid;
  @Input() isInterestReceived;
  @Input() currencyId: BehaviorSubject<number>;
  selectedCurency;
  clientIsDisabled = false;
  accounts;

  constructor(
    public intl: IntlService,
    private cashOperationService: CashOperationService,
    private notificationMessageService: NotificationMessageService
  ) {
    super();
  }

  initBankAccounts() {
    const clientId = this.formGroupControls.clientId.value;
    const currencyId = this.selectedCurency;

    if (currencyId && clientId) {
      this.cashOperationService
        .getClientBankAccounts(clientId, currencyId)
        .pipe(untilDestroyed(this))
        .subscribe(response => {
          this.accounts = response;
          if (!this.initialRun) {
            this.formGroupControls.bankAccountId.setValue(null, { emitEvent: false });
          }
          this.initialRun = false;
        });
    } else {
      this.notificationMessageService.info("Select currency and client");
    }
  }

  ngOnInit(): void {
    this.formGroupControls.amount.valueChanges.pipe(untilDestroyed(this)).subscribe(() => {
      this.calculateNetRecivable();
    });

    this.formGroupControls.feeAmount.valueChanges.pipe(untilDestroyed(this)).subscribe(() => {
      this.calculateNetRecivable();
    });
    this.formGroupControls.surcharge.valueChanges.pipe(untilDestroyed(this)).subscribe(() => {
      this.calculateNetRecivable();
    });

    if (!this.isIbanVisible) {
      this.formGroupControls.bankAccountId.disable();
    }
    if (this.isFeeOrInterestPaid) {
      this.formGroupControls.bankAccountId.disable();
      this.formGroupControls.amount.disable();
      this.formGroupControls.surcharge.disable();
      this.formGroupControls.amountToReceive.disable();
    }
    // if (!this.isFeeVisible) {
    //   this.formGroupControls.feeAmount.disable();
    // }
    if (this.isIbanVisible) {
      this.currencyId.pipe(distinctUntilChanged()).subscribe(val => {
        if (val) {
          this.selectedCurency = val;
          this.initBankAccounts();
        }
      });
      this.formGroupControls.clientId.valueChanges.pipe(untilDestroyed(this), untilDestroyed(this)).subscribe(() => {
        this.initBankAccounts();
      });
    }
  }
  onFormUpdate(val: FormUpdate<IParticipantCommandInterface>) { }

  calculateNetRecivable() {
    if (this.formGroupControls.surcharge.value === true) {
      this.formGroupControls.amountToReceive.setValue(
        this.formGroupControls.amount.value - this.formGroupControls.feeAmount.value
      );
    } else {
      this.formGroupControls.amountToReceive.setValue(this.formGroupControls.amount.value);
    }
  }

  protected getFormControls(): Controls<IParticipantCommandInterface> {
    return {
      clientId: new FormControl(null, [Validators.required]),
      amount: new FormControl(null, [Validators.required]),
      feeAmount: new FormControl(0),
      bankAccountId: new FormControl(null, [Validators.required]),
      surcharge: new FormControl(false),
      amountToReceive: new FormControl(null),
      balance: new FormControl(null)
    };
  }
}
