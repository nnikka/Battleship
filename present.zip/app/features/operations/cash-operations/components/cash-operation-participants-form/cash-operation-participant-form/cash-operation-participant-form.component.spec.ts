import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { CashOperationParticipantFormComponent } from "./cash-operation-participant-form.component";

describe("CashOperationParticipantFormComponent", () => {
  let component: CashOperationParticipantFormComponent;
  let fixture: ComponentFixture<CashOperationParticipantFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CashOperationParticipantFormComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CashOperationParticipantFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
