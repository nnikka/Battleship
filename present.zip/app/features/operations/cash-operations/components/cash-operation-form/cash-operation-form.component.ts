import { Component, OnInit, Output, EventEmitter, Input } from "@angular/core";
import { ComplexFormRoot } from "src/app/general/abstractClasses/ComplexFormRoot.abstractClass";
import { ICashOperationFormInterface } from "../../interfaces/cash-operation-form.interface";
import { Controls, DataInput, FormUpdate } from "ngx-sub-form";

import { untilDestroyed } from "ngx-take-until-destroy";

import { FormControl, Validators } from "@angular/forms";
import { EClientTypes } from "@features/static-data/clients/models/ClientTypes.enum";
import { EClientStatuses } from "@features/static-data/clients/models/ClientStatuses.enum";
import { ICurrency } from "@core/models/catalogs/currency.interface";
import { ECashOperationTypes } from "../../enums/operation.enum";
import { IParticipantCommandInterface } from "../../interfaces/cash-operation-participants-form.interface";
import { constructSelectItemsFromEnum } from "src/utils/array.helper";
import { CashOperationService } from "../../services/cash-operation.service";
import { BehaviorSubject } from "rxjs";
import { CustomDateValidators } from "src/app/general/validators/date.validator";

@Component({
  selector: "app-cash-operation-form",
  templateUrl: "./cash-operation-form.component.html",
  styleUrls: ["./cash-operation-form.component.scss"]
})
export class CashOperationFormComponent extends ComplexFormRoot<ICashOperationFormInterface> implements OnInit {
  // tslint:disable-next-line: no-input-rename
  @DataInput()
  @Input("cashForm")
  dataInput: Required<ICashOperationFormInterface> | null;

  @Input() operationType: ECashOperationTypes;

  authorizedCounterPartyRequiredHttpParams: any = {
    "filterItem.clientTypes": EClientTypes.Counterparty,
    "filterItem.status": EClientStatuses.Authorized,
    SortBy: "clientNameEng",
    SortDirection: 0
  };
  clientIsDisabled = false;
  clientBankAccounts;

  @Input() currencies: ICurrency[];
  currencyId: BehaviorSubject<number> = new BehaviorSubject(null);

  operationTypes;

  get isFeevisible() {
    return (
      this.operationType !== ECashOperationTypes.Deposit &&
      this.operationType !== ECashOperationTypes.BrokerInterestReceived
    );
  }

  get isFeeOrInterestPaid() {
    return (
      this.operationType === ECashOperationTypes.BrokerInterestPaid ||
      this.operationType === ECashOperationTypes.InactivityFee ||
      this.operationType === ECashOperationTypes.MonthlyFee
    );
  }

  get isInterestReceived() {
    return this.operationType === ECashOperationTypes.BrokerInterestReceived;
  }

  constructor(private cashOperationService: CashOperationService) {
    super();
  }

  ngOnInit() {
    super.ngOnInit();
    this.operationTypes = constructSelectItemsFromEnum(ECashOperationTypes, false, "name", "id");
    this.formGroup.valueChanges.pipe(untilDestroyed(this)).subscribe(val => {
      this.calculatenetAmount(val);
      this.calculateAmount(val);
    });
    if (this.operationType === ECashOperationTypes.Deposit || this.operationType === ECashOperationTypes.Withdrawal) {
      this.formGroup.removeControl(this.formControlNames.settlementDate);
      this.formGroup.removeControl(this.formControlNames.clientCounterpartyId);
      this.formGroupControls.operationDate.setValidators([
        Validators.required,
        CustomDateValidators.minimumDateByDays(60)
      ]);
    }
    if (this.isFeeOrInterestPaid || this.isInterestReceived) {
      this.formGroup.removeControl(this.formControlNames.settlementDate);
      this.formGroup.removeControl(this.formControlNames.feeAmount);
      this.formGroup.removeControl(this.formControlNames.feeCurrencyId);
    }
    if (!this.isFeevisible) {
      this.formGroup.removeControl(this.formControlNames.feeAmount);
      this.formGroup.removeControl(this.formControlNames.feeCurrencyId);
    }

    this.formGroupControls.operationType.setValue(this.operationType);

    this.formGroupControls.currencyId.valueChanges.pipe(untilDestroyed(this)).subscribe(val => {
      this.currencyId.next(val);
    });
  }

  // TODO(giorgi): implement this metod for simple hook value changes
  onFormUpdate(val: FormUpdate<ICashOperationFormInterface>) {
    if (val.operationType) {
      this.currencyId.next(this.formGroupControls.currencyId.value);
    }
  }

  calculatenetAmount(val) {
    const cashOperationClients = val.cashOperationClients as IParticipantCommandInterface[];
    let amount = 0;
    if (cashOperationClients) {
      for (const participantInfo of cashOperationClients) {
        amount += participantInfo.amount;
      }
      this.formGroupControls.netAmount.setValue(amount, { emitEvent: false, onlySelf: true });
    }
  }
  calculateAmount(val) {
    const cashOperationClients = val.cashOperationClients as IParticipantCommandInterface[];
    let amount = 0;
    if (cashOperationClients) {
      for (const participantInfo of cashOperationClients) {
        amount += participantInfo.amountToReceive;
      }
      this.formGroupControls.amount.setValue(amount, { emitEvent: false, onlySelf: true });
    }
  }

  protected getFormControls(): Controls<ICashOperationFormInterface> {
    return {
      operationDate: new FormControl(null, [Validators.required]),
      settlementDate: new FormControl(null, [Validators.required, CustomDateValidators.minimumDateByDays(60)]),
      operationType: new FormControl({ value: null, disabled: true }),
      clientCounterpartyId: new FormControl(null, [Validators.required]),
      currencyId: new FormControl(null, [Validators.required]),
      amount: new FormControl({ value: null, disabled: true }),
      netAmount: new FormControl({ value: null, disabled: true }),
      feeAmount: new FormControl(null, [Validators.required]),
      feeCurrencyId: new FormControl(null, [Validators.required]),
      // TODO(giorgi): make errors to be displayed
      cashOperationClients: new FormControl(null, [Validators.required]),
      comment: new FormControl(null)
    };
  }
}
