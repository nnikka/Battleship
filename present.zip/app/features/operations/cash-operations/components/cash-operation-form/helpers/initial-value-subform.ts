import {
  ICashOperationHttpInterface
} from "@features/operations/cash-operations/interfaces/cash-operation-http.interface";
import {
  IParticipantCommandInterface
} from "@features/operations/cash-operations/interfaces/cash-operation-participants-form.interface";
import {
  IParticipantHttpCommandInterface
} from "@features/operations/cash-operations/interfaces/cash-operation-participants-http.interface";

export class CashOperationParticipantInitialValue implements IParticipantHttpCommandInterface {
  clientName: string;
  bankAccountNumber: string;
  clientId: number;
  amount: number;
  feeAmount: number;
  bankAccountId?: string;
  surcharge: boolean;
  amountToReceive: number;
  balance: number;
  constructor(cashParticipant: IParticipantHttpCommandInterface) {
    this.clientId = cashParticipant.clientId;
    this.amount = cashParticipant.amount;
    this.feeAmount = cashParticipant.feeAmount;
    this.bankAccountId = cashParticipant.bankAccountId;
    this.surcharge = cashParticipant.surcharge;
    this.amountToReceive = cashParticipant.amountToReceive;
    this.balance = cashParticipant.balance;
  }
}
