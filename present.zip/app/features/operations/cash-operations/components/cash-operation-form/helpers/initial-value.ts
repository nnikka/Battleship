// tslint:disable
import { ICashOperationHttpInterface } from "@features/operations/cash-operations/interfaces/cash-operation-http.interface";
import { CashOperationParticipantInitialValue } from "./initial-value-subform";
import { IAuditCommand } from "@core/models/commands/IAuditCommand";
// tslint:disable
import { IParticipantHttpCommandInterface } from "@features/operations/cash-operations/interfaces/cash-operation-participants-http.interface";
import { IOperationTransaction } from "@core/models/IOperationTransaction";
import { convertToDMY } from "src/utils/date-converter.helper";

export class CashOperationInitialValue implements ICashOperationHttpInterface {
  operationTransactions: IOperationTransaction[];
  operationStatus: number;
  operationTypeName: string;
  audit?: IAuditCommand;
  clientCounterpartyName: string;
  currencyName: string;
  feeCurrencyName: string;
  operationDate: string;
  settlementDate: string;
  operationType: number;
  clientCounterpartyId: string;
  currencyId: string;
  amount: number;
  netAmount: number;
  feeAmount: number;
  feeCurrencyId: number;
  cashOperationClients: IParticipantHttpCommandInterface[] = [];
  withrawalOperationId: number;
  comment: string;

  constructor(cashOperationHttpForm: ICashOperationHttpInterface) {
    if (cashOperationHttpForm.operationDate) {
      this.operationDate = convertToDMY(cashOperationHttpForm.operationDate).toLocaleDateString();
    }
    if (cashOperationHttpForm.settlementDate) {
      this.settlementDate = convertToDMY(cashOperationHttpForm.settlementDate).toLocaleDateString();
    }
    this.operationType = cashOperationHttpForm.operationType;
    this.clientCounterpartyId = cashOperationHttpForm.clientCounterpartyId;
    this.currencyId = cashOperationHttpForm.currencyId;
    this.feeAmount = cashOperationHttpForm.feeAmount;
    this.feeCurrencyId = cashOperationHttpForm.feeCurrencyId;

    for (const item of cashOperationHttpForm.cashOperationClients) {
      this.cashOperationClients.push(new CashOperationParticipantInitialValue(item));
    }
    this.comment = cashOperationHttpForm.comment;

    this.calcAmountNetAmount();
  }

  calcAmountNetAmount() {
    let amount = 0;
    let netAmount = 0;

    if (this.cashOperationClients && this.cashOperationClients.length > 0) {
      for (const item of this.cashOperationClients) {
        amount += item.amount;
        netAmount += item.amountToReceive;
      }
      this.amount = amount;
      this.netAmount = netAmount;
    }
  }
}
