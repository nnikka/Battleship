import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { CashOperationFormComponent } from "./cash-operation-form.component";

describe("CashOperationFormComponent", () => {
  let component: CashOperationFormComponent;
  let fixture: ComponentFixture<CashOperationFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CashOperationFormComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CashOperationFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
