import { Component, OnInit, Input } from "@angular/core";
import { ICashOperationHttpInterface } from "../../interfaces/cash-operation-http.interface";
import { ECashOperationTypes } from "../../enums/operation.enum";
import { IntlService } from "@progress/kendo-angular-intl";

@Component({
  selector: "app-cash-operation-card",
  templateUrl: "./cash-operation-card.component.html",
  styleUrls: ["./cash-operation-card.component.scss"]
})
export class CashOperationCardComponent implements OnInit {
  @Input() cashOperationInitialData: ICashOperationHttpInterface;

  get isIbanVisible() {
    return this.cashOperationInitialData.operationType === ECashOperationTypes.Withdrawal;
  }
  get isFeeVisible() {
    return this.cashOperationInitialData.operationType !== ECashOperationTypes.Deposit
      && this.cashOperationInitialData.operationType !== ECashOperationTypes.BrokerInterestReceived
      && !this.isFeeOrInterestPaid;
  }
  get isFeeOrInterestPaid() {
    return this.cashOperationInitialData.operationType === ECashOperationTypes.BrokerInterestPaid
      || this.cashOperationInitialData.operationType === ECashOperationTypes.InactivityFee
      || this.cashOperationInitialData.operationType === ECashOperationTypes.MonthlyFee;
  }

  get isInterestReceived() {
    return this.cashOperationInitialData.operationType === ECashOperationTypes.BrokerInterestReceived;
  }
  get isCounterPartVisible() {
    return (
      this.cashOperationInitialData.operationType !== ECashOperationTypes.Deposit &&
      this.cashOperationInitialData.operationType !== ECashOperationTypes.Withdrawal
    );
  }

  amount = 0;
  netAmount = 0;

  constructor(public intl: IntlService) { }

  ngOnInit() {
    if (this.cashOperationInitialData.cashOperationClients.length > 0) {
      for (const participant of this.cashOperationInitialData.cashOperationClients) {
        this.amount += participant.amount;
        this.netAmount += participant.amountToReceive;
      }
    }
  }

  addSpaces(str: string): string {
    return str.replace(/([A-Z])/g, " $1").trim();
  }
}
