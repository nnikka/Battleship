import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { CashOperationCardComponent } from "./cash-operation-card.component";

describe("CashOperationCardComponent", () => {
  let component: CashOperationCardComponent;
  let fixture: ComponentFixture<CashOperationCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CashOperationCardComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CashOperationCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
