import { Component, OnInit, EventEmitter } from "@angular/core";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import { ActivatedRoute, Router } from "@angular/router";
import { ECashOperationTypes } from "../../enums/operation.enum";
import { FormGroup } from "@angular/forms";
import { Store, select } from "@ngrx/store";
import { IAppState } from "@core/store/app.state";
import { selectCurrencies, selectCurrencyLoadStatus } from "@core/store/currency/currency.selector";
import { MarkFormGroupTouched } from "src/utils/mark-formgroup-touched.helper";
import { PopupConfirmService } from "@components/popup-confirm/popup-confirm.service";
import { NotificationMessageService } from "@core/services/notification-message.service";
import { CashOperationService } from "../../services/cash-operation.service";
import { ChangesDetector } from "src/app/general/abstractClasses/ChangesDetector.abstractClass";

@Component({
  selector: "app-cash-operation-add",
  templateUrl: "./cash-operation-add.component.html",
  styleUrls: ["./cash-operation-add.component.scss"]
})
export class CashOperationAddComponent extends ChangesDetector implements OnInit {
  breadcrumbItems: IBreadcrumb[] = [
    { text: "Operations", to: null },
    { text: "Cash", to: "/admin/operations/cash" },
    { text: "Cash operation add", to: null }
  ];
  loading = false;

  operationType: ECashOperationTypes;

  formReady: EventEmitter<any> = new EventEmitter();

  form: FormGroup;

  currencies$ = this.store.pipe(select(selectCurrencies));
  currenciesLoaded = this.store.pipe(select(selectCurrencyLoadStatus));

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private store: Store<IAppState>,
    private popupConfirmService: PopupConfirmService,
    private notificationMessageService: NotificationMessageService,
    private cashOperationService: CashOperationService
  ) {
    super();
  }

  ngOnInit() {
    this.formReady.subscribe(form => {
      this.form = form;
    });

    if (this.route.snapshot.paramMap.get("operationType")) {
      this.operationType = ECashOperationTypes[this.route.snapshot.paramMap.get("operationType")];
      if (!this.operationType) {
        this.router.navigateByUrl("/not-found", { replaceUrl: true });
      }
    }
  }

  hasUnsavedChanges(): boolean {
    if (this.form) {
      return this.form.dirty;
    }
    return false;
  }

  handleRegister() {
    if (this.form && this.form.valid) {
      this.popupConfirmService.show(null, null, () => {
        this.loading = true;
        this.cashOperationService.create(this.form.getRawValue()).subscribe(
          resp => {
            this.form.reset();
            this.form.markAsPristine();
            this.router.navigate(["admin/operations/cash"]);
            this.notificationMessageService.success("Cash Operation has been added successfully");
          },
          err => {
            this.loading = false;
          }
        );
        this.loading = false;
      });
    } else {
      this.notificationMessageService.error(
        "Form is invalid, please make sure all required fields are filled out correctly"
      );
      MarkFormGroupTouched(this.form.controls);
      this.form.markAllAsTouched();
    }
  }
}
