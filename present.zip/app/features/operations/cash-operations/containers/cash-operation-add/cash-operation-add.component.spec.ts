import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { CashOperationAddComponent } from "./cash-operation-add.component";

describe("CashOperationsAddComponent", () => {
  let component: CashOperationAddComponent;
  let fixture: ComponentFixture<CashOperationAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CashOperationAddComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CashOperationAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
