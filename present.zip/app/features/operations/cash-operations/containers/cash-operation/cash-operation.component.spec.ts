import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { CashOperationComponent } from "./cash-operation.component";

describe("CashOperationComponent", () => {
  let component: CashOperationComponent;
  let fixture: ComponentFixture<CashOperationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CashOperationComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CashOperationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
