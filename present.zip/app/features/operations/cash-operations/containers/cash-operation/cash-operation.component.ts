import { Component, OnInit, EventEmitter, OnDestroy, ChangeDetectorRef } from "@angular/core";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import { select, Store } from "@ngrx/store";
import { selectCurrencies, selectCurrencyLoadStatus } from "@core/store/currency/currency.selector";
import { IAppState } from "@core/store/app.state";
import { FormGroup } from "@angular/forms";
import { PopupConfirmService } from "@components/popup-confirm/popup-confirm.service";
import { NotificationMessageService } from "@core/services/notification-message.service";
import { MarkFormGroupTouched } from "src/utils/mark-formgroup-touched.helper";
import { ActivatedRoute, Router } from "@angular/router";
import { CashOperationService } from "../../services/cash-operation.service";
import { untilDestroyed } from "ngx-take-until-destroy";
import { CashOperationInitialValue } from "../../components/cash-operation-form/helpers/initial-value";
import { ICashOperationHttpInterface } from "../../interfaces/cash-operation-http.interface";
import {
  ECashOperationAuthorizationStatuses,
  ECashOperationAuthorizationStatusesColors
} from "../../enums/authorization.enum";
import { AuthService } from "@auth/services/auth.service";
import { EOperationStatus, EOperationStatusColor } from "@core/models/enums/EOperationStatus";
import { OperationService, EOperationType } from "@core/services/operation.service";
import { ChangesDetector } from "src/app/general/abstractClasses/ChangesDetector.abstractClass";
import { ECashOperationTypes } from "../../enums/operation.enum";

@Component({
  selector: "app-cash-operation",
  templateUrl: "./cash-operation.component.html",
  styleUrls: ["./cash-operation.component.scss"]
})
export class CashOperationComponent extends ChangesDetector implements OnInit, OnDestroy {
  breadcrumbItems: IBreadcrumb[] = [
    { text: "Operations", to: null },
    { text: "Cash", to: "/admin/operations/cash" },
    { text: "Cash operation", to: null }
  ];

  formReady: EventEmitter<any> = new EventEmitter();

  currencies$ = this.store.pipe(select(selectCurrencies));
  currenciesLoaded = this.store.pipe(select(selectCurrencyLoadStatus));

  loading = false;
  cashOperationId;
  cashOperationLoading = false;
  authorizationIsDisabled = false;
  formIsUpdatedSuccessfully = false;

  cashOperationFormData;
  cashOperationFullData: ICashOperationHttpInterface;

  operationType;
  form: FormGroup;

  get canAuthorize() {
    if (this.formIsUpdatedSuccessfully) {
      return false;
    }
    if (this.cashOperationFullData) {
      const lastUserId = this.cashOperationFullData.audit.lastModifiedUserId
        ? this.cashOperationFullData.audit.lastModifiedUserId
        : this.cashOperationFullData.audit.createUserId;
      if (lastUserId !== Number(this.authService.getUserId())) {
        return true;
      }
    }
    return null;
  }

  get cashAuthorizationStatus() {
    return this.cashOperationFullData
      ? ECashOperationAuthorizationStatuses[this.cashOperationFullData.audit.status]
      : null;
  }

  get isCashUnauthorized() {
    return this.cashOperationFullData
      ? ECashOperationAuthorizationStatuses.Unauthorized === this.cashOperationFullData.audit.status
      : false;
  }
  get isCashauthorized() {
    return this.cashOperationFullData
      ? ECashOperationAuthorizationStatuses.Authorized === this.cashOperationFullData.audit.status
      : false;
  }

  get operationStatus(): string {
    if (this.cashOperationFullData) {
      return EOperationStatus[this.cashOperationFullData.operationStatus];
    }
    return null;
  }

  get isExecutionOfTransactionsAvailable(): boolean {
    if (
      this.cashOperationFullData &&
      (this.cashOperationFullData.operationStatus === EOperationStatus.Pending ||
        this.cashOperationFullData.operationStatus === EOperationStatus.Fail)
    ) {
      const pattern = /(\d{2})\.(\d{2})\.(\d{4})/;
      const settlementDate = new Date(this.cashOperationFullData.settlementDate.replace(pattern, "$3-$2-$1")).getTime();
      if (settlementDate < Date.now()) {
        return true;
      }
    }
    return false;
  }

  get isPaid(): boolean {
    return this.cashOperationFullData && this.cashOperationFullData.operationStatus === EOperationStatus.Success;
  }

  get canDeauthorize(): boolean {
    if (this.cashOperationFullData && this.cashOperationFullData.operationStatus === EOperationStatus.Success) {
      return false;
    }
    return true;
  }

  get isOperationSucceed(): boolean {
    if (this.cashOperationFullData) {
      return this.cashOperationFullData.operationStatus === EOperationStatus.Success;
    }
    return false;
  }

  get isOperationCanceled(): boolean {
    if (this.cashOperationFullData) {
      return this.cashOperationFullData.operationStatus === EOperationStatus.Canceled;
    }
    return false;
  }

  get isWithdrawalAllowed(): boolean {
    if (
      this.cashOperationFullData &&
      this.cashOperationFullData.operationType === ECashOperationTypes.TransferFromCounterparty &&
      this.cashOperationFullData.withrawalOperationId === null &&
      this.cashOperationFullData.operationTransactions.length > 0 &&
      this.cashOperationFullData.operationStatus === EOperationStatus.Success
    ) {
      return true;
    }
    return false;
  }

  constructor(
    private store: Store<IAppState>,
    private popupConfirmService: PopupConfirmService,
    private notificationMessageService: NotificationMessageService,
    private route: ActivatedRoute,
    private cashOperationService: CashOperationService,
    private router: Router,
    private authService: AuthService,
    private operationService: OperationService,
    private ref: ChangeDetectorRef
  ) {
    super();
  }

  ngOnInit() {
    this.route.paramMap.subscribe(paramsAsMap => {
      this.cashOperationId = paramsAsMap.get("id");
      this.loadCashData(this.cashOperationId);
    });

    this.formReady.subscribe(form => {
      this.form = form;
    });
  }

  operationStatusColor(status: string): string {
    return status ? EOperationStatusColor[status] : null;
  }

  hasUnsavedChanges(): boolean {
    if (this.form) {
      return this.form.dirty;
    }
    return false;
  }

  ngOnDestroy(): void {}

  loadCashData(id) {
    this.cashOperationLoading = true;
    this.cashOperationService
      .getById(id)
      .pipe(untilDestroyed(this))
      .subscribe(
        (cashOperationDataHttp: ICashOperationHttpInterface) => {
          this.cashOperationFormData = new CashOperationInitialValue(cashOperationDataHttp);

          this.cashOperationFullData = { ...cashOperationDataHttp };
          this.operationType = this.cashOperationFullData.operationType;
          // this.updateFxInstrument(this.cashOperationFullData.fxInstrumentId);
          // if (this.isFXauthorized) {
          //   this.loadInitialBalances();
          // }

          this.cashOperationLoading = false;
        },
        err => {
          this.router.navigateByUrl("/not-found", { replaceUrl: true });
        }
      );
  }

  handleUpdate() {
    if (!this.form.dirty) {
      this.notificationMessageService.info("Nothing is changed");
    } else if (this.form && this.form.valid) {
      this.popupConfirmService.show(null, null, () => {
        this.loading = true;
        this.cashOperationService
          .update(this.cashOperationId, this.form.getRawValue())
          .pipe(untilDestroyed(this))
          .subscribe(
            resp => {
              // this.form.reset();
              this.form.markAsPristine();
              this.formIsUpdatedSuccessfully = true;
              this.loading = false;
              // this.router.navigate(["admin/operations/cash"]);
              this.notificationMessageService.success("cash Operation has been added successfully");
            },
            err => {
              this.loading = false;
            }
          );
        this.loading = false;
      });
    } else {
      this.notificationMessageService.error(
        "Form is invalid, please make sure all required fields are filled out correctly"
      );
      MarkFormGroupTouched(this.form.controls);
    }
  }

  handleChangeAuthorize(status: string, message: string) {
    if (this.form && this.form.dirty) {
      this.notificationMessageService.warn(
        "Form is changed, if you want to change authorization status please update the form first"
      );
      return;
    }
    this.popupConfirmService.show(null, null, () => {
      this.cashOperationLoading = true;
      this.authorizationIsDisabled = true;
      this.cashOperationService
        .changeAuthorizationStatus(this.cashOperationId, ECashOperationAuthorizationStatuses[status])
        .pipe(untilDestroyed(this))
        .subscribe(
          response => {
            this.cashOperationLoading = false;
            this.loadCashData(this.cashOperationId);
            this.notificationMessageService.success(message);
            this.authorizationIsDisabled = false;
          },
          error => {
            this.cashOperationLoading = false;
            this.authorizationIsDisabled = false;
          }
        );
    });
  }

  handleExecuteTransactions() {
    this.popupConfirmService.show(null, null, () => {
      this.cashOperationLoading = true;
      this.operationService
        .makeOperationTransactions(this.cashOperationId, EOperationType.cash)
        .pipe(untilDestroyed(this))
        .subscribe(
          resp => {
            this.loadCashData(this.cashOperationId);
            this.cashOperationLoading = false;
          },
          err => {
            this.loadCashData(this.cashOperationId);
            this.cashOperationLoading = false;
          }
        );
    });
  }

  handleWithdraw() {
    this.popupConfirmService.show(null, null, () => {
      this.cashOperationLoading = true;
      this.cashOperationService.transferFromCounterPartyWithdraw(this.cashOperationId).subscribe(
        resp => {
          this.notificationMessageService.success("Operation has been created successfully");
          this.router.navigateByUrl("/admin/operations/cash/" + resp);
        },
        err => {
          this.cashOperationLoading = false;
          this.notificationMessageService.error("Something went wrong");
        }
      );
    });
  }

  goToWithdrawalOperation() {
    this.router.navigateByUrl("/admin/operations/cash/" + this.cashOperationFullData.withrawalOperationId);
  }

  authorizationStatusColor(status: string): string {
    return ECashOperationAuthorizationStatusesColors[status];
  }
}
