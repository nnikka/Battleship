import { Component, OnInit, OnDestroy } from "@angular/core";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import { Router, ActivatedRoute } from "@angular/router";
import { FormGroup } from "@angular/forms";
import { EOperationStatusColor, EOperationStatus } from "@core/models/enums/EOperationStatus";
import {
  ECashOperationAuthorizationStatusesColors,
  ECashOperationAuthorizationStatuses
} from "../../enums/authorization.enum";
import { CashOperationService } from "../../services/cash-operation.service";
import { constructSelectItemsFromEnum, constructSelectItemsFromArray } from "src/utils/array.helper";
import { untilDestroyed } from "ngx-take-until-destroy";
import { select, Store } from "@ngrx/store";
import { selectCurrencies, selectCurrencyLoadStatus } from "@core/store/currency/currency.selector";
import { IAppState } from "@core/store/app.state";
import { ECashOperationTypes } from "../../enums/operation.enum";
import { FileDownloadService } from "@core/services/file-download.service";
import { formatDate } from "@telerik/kendo-intl";
import { IColumn } from "@shared/components/complex-grid/interfaces/IColumn";
import { IOptions } from "@shared/components/complex-grid/interfaces/IOptions";

@Component({
  selector: "app-cash-operations-list",
  templateUrl: "./cash-operations-list.component.html",
  styleUrls: ["./cash-operations-list.component.scss"]
})
export class CashOperationsListComponent implements OnInit, OnDestroy {
  breadcrumbItems: IBreadcrumb[] = [
    { text: "Operations", to: null },
    { text: "Cash", to: "/admin/operations/cash" }
  ];

  form: FormGroup;
  columns: IColumn[];
  options: IOptions = {
    tableKey: "CashOperationsList",
    columnsTooboxEnable: true,
    dblClickEnable: true,
    detailShowEnable: true
  };

  listIsLoading = true;

  cashOperationAuthorizationStatuses;
  cashOperationStatuses;
  currencies;
  cashOperationTypes;

  currencies$ = this.store.pipe(select(selectCurrencies));
  currenciesLoaded = this.store.pipe(select(selectCurrencyLoadStatus));

  excelIsDownloading: boolean = false;

  constructor(
    private cashOperationService: CashOperationService,
    private store: Store<IAppState>,
    private fileDownloadService: FileDownloadService
  ) { }

  ngOnInit() {
    this.cashOperationAuthorizationStatuses = constructSelectItemsFromEnum(ECashOperationAuthorizationStatuses);
    this.cashOperationStatuses = constructSelectItemsFromEnum(EOperationStatus);

    this.cashOperationTypes = constructSelectItemsFromEnum(ECashOperationTypes, true);

    this.currencies$.pipe(untilDestroyed(this)).subscribe(currencies => {
      this.currencies = constructSelectItemsFromArray(currencies, { name: "All", id: null });
      this.columns = [
        {
          key: "id",
          name: "ID",
          type: "number",
          filterConfig: {
            filterType: "number"
          }
        },
        {
          key: "operationStatus",
          name: "Operation status",
          type: "string",
          style: {
            colorsMapping: EOperationStatusColor,
            conditionalColor: true
          },
          filterConfig: {
            filterData: this.cashOperationStatuses,
            filterType: "dropdown"
          }
        },
        {
          // addSpaces(dataItem.operationType)
          key: "operationType",
          name: "Operation type",
          type: "string",
          filterConfig: {
            filterData: this.cashOperationTypes,
            filterType: "dropdown"
          }
        },
        {
          // addSpaces(dataItem.operationType)
          key: "dividendPayoutOperationId",
          name: "Dividend payout id",
          type: "number",
          filterConfig: {
            filterType: "number"
          }
        },
        {
          key: "operationDate",
          name: "Operation Date",
          type: "date",
          filterConfig: {
            filterType: "date"
          }
        },

        {
          key: "clientCounterpartyName",
          name: "Counterparty",
          type: "string",
          filterConfig: {
            filterType: "string"
          }
        },
        {
          key: "currencyName",
          name: "Currency",
          type: "string",
          filterConfig: {
            key: "currencyId",
            containsDataMapping: true,
            filterData: this.currencies,
            dataMappingSearchKey: "name",
            filterType: "dropdown",
            dropdownKeyKey: "name",
            dropdownValueKey: "id"
          }
        },
        {
          key: "feeAmount",
          name: "Fee amount",
          type: "number",
          format: "##,#.##########",
          filterConfig: {
            filterType: "number"
          }
        },
        // we are getting name not id
        {
          key: "feeCurrencyName",
          name: "Fee currency",
          type: "string",
          filterConfig: {
            key: "feeCurrencyId",
            containsDataMapping: true,
            filterData: this.currencies,
            filterType: "dropdown",
            dataMappingSearchKey: "name",
            dropdownKeyKey: "name",
            dropdownValueKey: "id"
          }
        },
        {
          key: "status",
          name: "Authorization status",
          type: "string",
          style: {
            colorsMapping: ECashOperationAuthorizationStatusesColors,
            conditionalColor: true,
            isCard: true
          },
          filterConfig: {
            filterData: this.cashOperationAuthorizationStatuses,
            filterType: "dropdown"
          }
        }
      ];
    });
  }

  ngOnDestroy(): void { }

  handleAddCashOperation() { }

  addSpaces(str: string): string {
    return str.replace(/([A-Z])/g, " $1").trim();
  }

  exportExcel() {
    this.excelIsDownloading = true;
    this.cashOperationService.exportExcel().subscribe(response => {
      this.fileDownloadService.downLoadFile(`${formatDate(new Date(), "MM/dd/yyyy")} cash-operations.xlsx`, response);
      this.excelIsDownloading = false;
    });
  }

  authorizationStatusColor(status: string): string {
    return ECashOperationAuthorizationStatusesColors[status];
  }

  operationStatusColor(status: string): string {
    return status ? EOperationStatusColor[status] : null;
  }
}
