import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { CashOperationsListComponent } from "./cash-operations-list.component";

describe("CashOperationsListComponent", () => {
  let component: CashOperationsListComponent;
  let fixture: ComponentFixture<CashOperationsListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CashOperationsListComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CashOperationsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
