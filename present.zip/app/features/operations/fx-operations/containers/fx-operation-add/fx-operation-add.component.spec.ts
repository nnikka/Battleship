import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { FxOperationAddComponent } from "./fx-operation-add.component";

describe("FxOperationAddComponent", () => {
  let component: FxOperationAddComponent;
  let fixture: ComponentFixture<FxOperationAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FxOperationAddComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FxOperationAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
