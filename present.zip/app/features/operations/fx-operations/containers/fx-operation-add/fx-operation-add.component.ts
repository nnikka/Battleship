import { Component, OnInit, EventEmitter, OnDestroy } from "@angular/core";
import { ChangesDetector } from "src/app/general/abstractClasses/ChangesDetector.abstractClass";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import { IFXOperationInterface } from "../../interfaces/fx-operations-form.interface";
import { Subject } from "rxjs";
import { IAppState } from "@core/store/app.state";
import { Store, select } from "@ngrx/store";
import { selectCurrencies, selectCurrencyLoadStatus } from "@core/store/currency/currency.selector";
import { TypedFormGroup } from "ngx-sub-form";
import { untilDestroyed } from "ngx-take-until-destroy";
import { IFXModuleState } from "../../store/state";
import { FXOperationService } from "../../services/fx-operation.service";
import { PopupConfirmService } from "@components/popup-confirm/popup-confirm.service";
import { NotificationMessageService } from "@core/services/notification-message.service";
import { Router } from "@angular/router";
import { MarkFormGroupTouched } from "src/utils/mark-formgroup-touched.helper";
import { FXInstrumentService } from "../../services/fx-instrument.service";
import {
  selectAuthorizedFXInstruments,
  selectFXInstrumentLoadStatus
} from "../../store/fx-instruments/fx-instrument.select";

@Component({
  selector: "app-fx-operation-add",
  templateUrl: "./fx-operation-add.component.html",
  styleUrls: ["./fx-operation-add.component.scss"]
})
export class FxOperationAddComponent extends ChangesDetector implements OnInit, OnDestroy {
  breadcrumbItems: IBreadcrumb[] = [
    { text: "Operations", to: null },
    { text: "FX", to: "/admin/operations/fx" },
    { text: "Add operation", to: null }
  ];
  form: TypedFormGroup<IFXOperationInterface>;

  formReady: EventEmitter<TypedFormGroup<IFXOperationInterface> | null> = new EventEmitter<TypedFormGroup<
    IFXOperationInterface
  > | null>();

  fxDataFromRoute;

  loading = false;

  cashDataLoading = false;
  fxInstrumentDataLoading = false;

  currencies$ = this.store.pipe(select(selectCurrencies));
  currenciesLoaded = this.store.pipe(select(selectCurrencyLoadStatus));
  fxInstruments$ = this.store.pipe(select(selectAuthorizedFXInstruments));
  fxInstrumentsLoaded = this.store.pipe(select(selectFXInstrumentLoadStatus));
  cashData: Subject<any> = new Subject();

  fxInstrumentData: Subject<any> = new Subject();

  constructor(
    private store: Store<IFXModuleState | IAppState>,
    private fxOperationService: FXOperationService,
    private popupConfirmService: PopupConfirmService,
    private notificationMessageService: NotificationMessageService,
    private router: Router,
    private fxInstrumentService: FXInstrumentService
  ) {
    super();
    if (this.router.getCurrentNavigation() && this.router.getCurrentNavigation().extras.state) {
      this.fxDataFromRoute = this.router.getCurrentNavigation().extras.state.data;
    }
  }

  ngOnInit() {
    this.formReady.pipe(untilDestroyed(this)).subscribe(form => {
      if (form) {
        this.form = form;
        this.form
          .get("clientId")
          .valueChanges.pipe(untilDestroyed(this))
          .subscribe(async (clientId: number) => {
            this.updateCashData();
          });
        this.form
          .get("clientCounterpartyId")
          .valueChanges.pipe(untilDestroyed(this))
          .subscribe(async (clientCounterpartyId: number) => {
            this.updateCashData();
          });
        this.form
          .get("fxInstrumentId")
          .valueChanges.pipe(untilDestroyed(this))
          .subscribe((fxInstrumentId: number) => {
            this.updateFxInstrument(fxInstrumentId);
          });

        if (this.fxDataFromRoute) {
          this.form.get("fxInstrumentId").setValue(this.fxDataFromRoute.id);
          this.form.get("fxInstrumentId").markAsDirty();
        }
      }
    });
  }

  updateFxInstrument(fxInstrumentId) {
    this.fxInstrumentDataLoading = true;
    if (fxInstrumentId == null) {
      return;
    }
    this.fxInstrumentService.getById(fxInstrumentId).subscribe(data => {
      this.fxInstrumentDataLoading = false;
      this.fxInstrumentData.next(data);
    });
  }

  async updateCashData() {
    const clientIdT = this.form.get("clientId").value;
    const clientCounterpartyIdT = this.form.get("clientCounterpartyId").value;
    if (clientIdT && clientCounterpartyIdT) {
      this.cashDataLoading = true;
      const data = (await this.fxOperationService
        .getClientBalanceOnCounterparty(clientIdT, clientCounterpartyIdT)
        .toPromise()) as any;
      this.cashDataLoading = false;
      this.cashData.next({
        clientBalances: data.clientBalances,
        selectedIDs: { clientIdT, clientCounterpartyIdT }
      });
    }
  }

  ngOnDestroy(): void { }

  // TODO(giorgi): think about better solution for form handling
  // for example we must move logic about form submit or form changedetector into from root in form component
  // but for this we must change  route logic for has hasUnsavedChanges becouse guard is connected to this component
  hasUnsavedChanges(): boolean {
    if (this.form) {
      return this.form.dirty;
    }
    return false;
  }

  handleRegister() {
    if (this.form && this.form.valid) {
      this.popupConfirmService.show(null, null, () => {
        this.loading = true;
        this.fxOperationService
          .create(this.form.getRawValue())
          .pipe(untilDestroyed(this))
          .subscribe(
            resp => {
              this.form.reset();
              this.form.markAsPristine();
              this.router.navigate(["admin/operations/fx"]);
              this.notificationMessageService.success("FX Operation has been added successfully");
            },
            err => {
              this.loading = false;
            }
          );
      });
    } else {
      this.notificationMessageService.error(
        "Form is invalid, please make sure all required fields are filled out correctly"
      );
      MarkFormGroupTouched(this.form.controls);
    }
  }
}
