import { Component, OnInit, OnDestroy } from "@angular/core";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import { Router } from "@angular/router";
import { FormGroup } from "@angular/forms";
import { untilDestroyed } from "ngx-take-until-destroy";
import { IFXModuleState } from "../../store/state";
import { IAppState } from "@core/store/app.state";
import { Store, select } from "@ngrx/store";
import { selectCurrencies, selectCurrencyLoadStatus } from "@core/store/currency/currency.selector";
import { constructSelectItemsFromArray, constructSelectItemsFromEnum } from "src/utils/array.helper";
import {
  EFXOperationAuthorizationStatuses,
  EFXOperationAuthorizationStatusesColors
} from "../../eunms/authorization.enum";
import { EOperationStatus, EOperationStatusColor } from "@core/models/enums/EOperationStatus";
import { IntlService, formatDate } from "@progress/kendo-angular-intl";
import { IColumn } from "@shared/components/complex-grid/interfaces/IColumn";
import { IOptions } from "@shared/components/complex-grid/interfaces/IOptions";
import { FXOperationService } from "../../services/fx-operation.service";
import { FileDownloadService } from "@core/services/file-download.service";

@Component({
  selector: "app-fx-operations-list",
  templateUrl: "./fx-operations-list.component.html",
  styleUrls: ["./fx-operations-list.component.scss"]
})
export class FxOperationsListComponent implements OnInit, OnDestroy {
  breadcrumbItems: IBreadcrumb[] = [
    { text: "Operations", to: null },
    { text: "FX", to: "/admin/operations/fx" }
  ];
  form: FormGroup;

  listIsLoading = true;

  currencies$ = this.store.pipe(select(selectCurrencies));
  currenciesLoaded = this.store.pipe(select(selectCurrencyLoadStatus));
  currencies;
  fxOperationAuthorizationStatuses;
  fxOperationStatuses: { name: string; value: number }[];

  columns: IColumn[];
  options: IOptions = {
    tableKey: "FXOperationsList",
    columnsTooboxEnable: true,
    dblClickEnable: true,
    detailShowEnable: true
  };

  excelIsDownloading: boolean = false;

  constructor(
    private router: Router,
    private store: Store<IFXModuleState | IAppState>,
    public intl: IntlService,
    private fxOperationService: FXOperationService,
    private fileDownloadService: FileDownloadService) { }

  ngOnInit() {
    this.listIsLoading = false;

    this.fxOperationAuthorizationStatuses = constructSelectItemsFromEnum(EFXOperationAuthorizationStatuses);
    this.fxOperationStatuses = constructSelectItemsFromEnum(EOperationStatus);

    this.currencies$.pipe(untilDestroyed(this)).subscribe(currencies => {
      this.currencies = constructSelectItemsFromArray(currencies, { name: "All", id: null });
      this.columns = [
        {
          key: "id",
          name: "ID",
          type: "number",
          filterConfig: {
            filterType: "number"
          }
        },
        {
          key: "operationStatus",
          name: "Operation status",
          type: "string",
          style: {
            colorsMapping: EOperationStatusColor,
            conditionalColor: true
          },
          filterConfig: {
            filterData: constructSelectItemsFromEnum(EOperationStatus),
            filterType: "dropdown"
          }
        },
        {
          key: "clientName",
          name: "Client",
          type: "string",
          filterConfig: {
            filterType: "string"
          }
        },
        {
          key: "clientCounterpartyName",
          name: "Counterparty",
          type: "string",
          filterConfig: {
            filterType: "string"
          }
        },
        {
          key: "amount",
          name: "From amount",
          type: "number",
          format: "##,#.##########",
          filterConfig: {
            filterType: "number"
          }
        },
        {
          key: "fromCurrencyId",
          name: "From currency",
          type: "string",
          filterConfig: {
            containsDataMapping: true,
            filterData: this.currencies,
            filterType: "dropdown",
            dropdownKeyKey: "name",
            dropdownValueKey: "id"
          }
        },
        {
          key: "toCurrencyId",
          name: "To currency",
          type: "string",
          filterConfig: {
            containsDataMapping: true,
            filterData: this.currencies,
            filterType: "dropdown",
            dropdownKeyKey: "name",
            dropdownValueKey: "id"
          }
        },
        {
          key: "settlementDate",
          name: "Operation date",
          type: "date",
          filterConfig: {
            filterType: "date"
          }
        },
        {
          key: "status",
          name: "Authorization status",
          type: "string",
          style: {
            colorsMapping: EFXOperationAuthorizationStatusesColors,
            conditionalColor: true,
            isCard: true
          },
          filterConfig: {
            filterData: this.fxOperationAuthorizationStatuses,
            filterType: "dropdown"
          }
        }
      ];
    });
  }

  exportExcel() {
    this.excelIsDownloading = true;
    this.fxOperationService
      .exportExcel()
      .pipe(untilDestroyed(this))
      .subscribe(response => {
        this.fileDownloadService.downLoadFile(
          `${formatDate(new Date(), "dd-MM-yyyy HH:mm:ss")} FX Operations.xlsx`,
          response
        );
        this.excelIsDownloading = false;
      });
  }
  ngOnDestroy() { }

  handleAddFXOperation() {
    this.router.navigate(["admin/operations/fx/add-fx-operation"]);
  }

  authorizationStatusColor(status: string): string {
    return EFXOperationAuthorizationStatusesColors[status];
  }

  operationStatusColor(status: string): string {
    return status ? EOperationStatusColor[status] : null;
  }
}
