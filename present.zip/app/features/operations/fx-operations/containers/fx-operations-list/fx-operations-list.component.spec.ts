import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { FxOperationsListComponent } from "./fx-operations-list.component";

describe("FxOperationsListComponent", () => {
  let component: FxOperationsListComponent;
  let fixture: ComponentFixture<FxOperationsListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FxOperationsListComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FxOperationsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
