import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { FxOperationComponent } from "./fx-operation.component";

describe("FxOperationComponent", () => {
  let component: FxOperationComponent;
  let fixture: ComponentFixture<FxOperationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FxOperationComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FxOperationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
