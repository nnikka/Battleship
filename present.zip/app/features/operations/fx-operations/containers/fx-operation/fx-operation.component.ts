import { Component, OnInit, OnDestroy, EventEmitter } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { PopupConfirmService } from "@components/popup-confirm/popup-confirm.service";
import { AuthService } from "@auth/services/auth.service";
import { NotificationMessageService } from "@core/services/notification-message.service";
import { untilDestroyed } from "ngx-take-until-destroy";
import { FXOperationService } from "../../services/fx-operation.service";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import {
  EFXAuthorizationStatusesColors,
  EFXAuthorizationStatuses
} from "@features/static-data/fx-instruments/models/fxAuthorizationStatuses.enum";
import { Store, select } from "@ngrx/store";
import { IFXModuleState } from "../../store/state";
import { IAppState } from "@core/store/app.state";
import { selectCurrencies, selectCurrencyLoadStatus } from "@core/store/currency/currency.selector";
import { IFXOperationInterface } from "../../interfaces/fx-operations-form.interface";
import { TypedFormGroup } from "ngx-sub-form";
import { Subject } from "rxjs";
import { IFXOperationHttpInterface } from "../../interfaces/fx-operations-http.interface";
import { FXOperationInitialValue } from "../../components/fx-operation-form/helpers/initial-value.class";
import { EOperationStatus, EOperationStatusColor } from "@core/models/enums/EOperationStatus";
import { EOperationType, OperationService } from "@core/services/operation.service";
import { FXInstrumentService } from "../../services/fx-instrument.service";
import { convertToDMY } from "src/utils/date-converter.helper";
import {
  selectAuthorizedFXInstruments,
  selectFXInstrumentLoadStatus
} from "../../store/fx-instruments/fx-instrument.select";

@Component({
  selector: "app-fx-operation",
  templateUrl: "./fx-operation.component.html",
  styleUrls: ["./fx-operation.component.scss"]
})
export class FxOperationComponent implements OnInit, OnDestroy {
  breadcrumbItems: IBreadcrumb[] = [
    { text: "Operations", to: null },
    { text: "FX", to: "/admin/operations/fx" },
    { text: "FX operation", to: null }
  ];

  fxOperationId;
  // form must have 1 on 1 data
  fxOperationFormData;

  // card can have extra
  fxOperationFullData: IFXOperationHttpInterface;

  fxOperationDataLoading = false;

  form: TypedFormGroup<IFXOperationInterface>;

  formReady: EventEmitter<TypedFormGroup<IFXOperationInterface> | null> = new EventEmitter<TypedFormGroup<
    IFXOperationInterface
  > | null>();

  cashData: Subject<any> = new Subject();

  fxInstrumentData: Subject<any> = new Subject();

  currencies$ = this.store.pipe(select(selectCurrencies));
  currenciesLoaded = this.store.pipe(select(selectCurrencyLoadStatus));
  fxInstruments$ = this.store.pipe(select(selectAuthorizedFXInstruments));
  fxInstrumentsLoaded = this.store.pipe(select(selectFXInstrumentLoadStatus));

  authorizationIsDisabled = false;

  cashDataLoading = false;
  fxInstrumentDataLoading = false;

  formIsUpdatedSuccessfully = false;

  get canAuthorize() {
    if (this.formIsUpdatedSuccessfully) {
      return false;
    }
    if (this.fxOperationFullData) {
      const lastUserId = this.fxOperationFullData.audit.lastModifiedUserId
        ? this.fxOperationFullData.audit.lastModifiedUserId
        : this.fxOperationFullData.audit.createUserId;
      if (lastUserId !== Number(this.authService.getUserId())) {
        return true;
      }
    }
    return null;
  }

  get canDeauthorize(): boolean {
    if (this.fxOperationFullData && this.fxOperationFullData.operationStatus === EOperationStatus.Success) {
      return false;
    }
    return true;
  }

  get operationStatus(): string {
    if (this.fxOperationFullData) {
      return EOperationStatus[this.fxOperationFullData.operationStatus];
    }
    return null;
  }

  get fxAuthorizationStatus() {
    return this.fxOperationFullData ? EFXAuthorizationStatuses[this.fxOperationFullData.audit.status] : null;
  }

  get isFXUnauthorized() {
    return this.fxOperationFullData
      ? EFXAuthorizationStatuses.Unauthorized === this.fxOperationFullData.audit.status
      : false;
  }
  get isFXauthorized() {
    return this.fxOperationFullData
      ? EFXAuthorizationStatuses.Authorized === this.fxOperationFullData.audit.status
      : false;
  }

  get isOperationSucceed(): boolean {
    if (this.fxOperationFullData) {
      return this.fxOperationFullData.operationStatus === EOperationStatus.Success;
    }
    return false;
  }

  get isOperationCanceled(): boolean {
    if (this.fxOperationFullData) {
      return this.fxOperationFullData.operationStatus === EOperationStatus.Canceled;
    }
    return false;
  }

  get isExecutionOfTransactionsAvailable(): boolean {
    if (
      this.fxOperationFullData &&
      (this.fxOperationFullData.operationStatus === EOperationStatus.Pending ||
        this.fxOperationFullData.operationStatus === EOperationStatus.Fail)
    ) {
      const settlementDate = convertToDMY(this.fxOperationFullData.settlementDate).getTime();
      if (settlementDate < Date.now()) {
        return true;
      }
    }
    return false;
  }

  constructor(
    private route: ActivatedRoute,
    private popupConfirmService: PopupConfirmService,
    private authService: AuthService,
    private fxOperationService: FXOperationService,
    private notificationMessageService: NotificationMessageService,
    private router: Router,
    private store: Store<IFXModuleState | IAppState>,
    private operationService: OperationService,
    private fxInstrumentService: FXInstrumentService
  ) {}

  ngOnInit() {
    this.route.paramMap.pipe(untilDestroyed(this)).subscribe(paramsAsMap => {
      this.fxOperationId = paramsAsMap.get("id");
      this.lodaFx(this.fxOperationId);
    });

    this.formReady.pipe(untilDestroyed(this)).subscribe(async form => {
      if (form) {
        this.form = form;
        this.addListenersForValueChange();
        await this.loadInitialBalances();
      }
    });
  }
  async loadInitialBalances() {
    await this.updateCashData();
  }
  // TODO(giorgi): implement correct solution
  addListenersForValueChange() {
    this.form
      .get("clientId")
      .valueChanges.pipe(untilDestroyed(this))
      .subscribe(async (clientId: number) => {
        await this.updateCashData();
      });
    this.form
      .get("clientCounterpartyId")
      .valueChanges.pipe(untilDestroyed(this))
      .subscribe(async (clientCounterpartyId: number) => {
        await this.updateCashData();
      });
    this.form
      .get("fxInstrumentId")
      .valueChanges.pipe(untilDestroyed(this))
      .subscribe((fxInstrumentId: number) => {
        if (fxInstrumentId) {
          this.updateFxInstrument(fxInstrumentId);
        }
      });
  }

  async updateCashData() {
    if (this.isFXUnauthorized) {
      const clientIdT = this.form.get("clientId").value;
      const clientCounterpartyIdT = this.form.get("clientCounterpartyId").value;
      if (clientIdT && clientCounterpartyIdT) {
        this.cashDataLoading = true;
        const data = (await this.fxOperationService
          .getClientBalanceOnCounterparty(clientIdT, clientCounterpartyIdT)
          .toPromise()) as any;
        this.cashDataLoading = false;
        const selectedBalanceClient = this.form.get("fromCurrencyId").value;
        const selectedBalanceCounterparty = this.form.get("toCurrencyId").value;
        this.cashData.next({
          clientBalances: data.clientBalances,
          selectedIDs: { selectedBalanceClient, selectedBalanceCounterparty }
        });
      }
    } else if (this.isFXauthorized) {
      this.cashDataLoading = true;
      const data = (await this.fxOperationService
        .getClientBalanceOnCounterparty(
          this.fxOperationFullData.clientId,
          this.fxOperationFullData.clientCounterpartyId
        )
        .toPromise()) as any;
      this.cashDataLoading = false;
      const selectedBalanceClient = this.fxOperationFullData.fromCurrencyId;
      const selectedBalanceCounterparty = this.fxOperationFullData.toCurrencyId;
      this.cashData.next({
        clientBalances: data.clientBalances,
        selectedIDs: { selectedBalanceClient, selectedBalanceCounterparty }
      });
    }
  }

  updateFxInstrument(fxInstrumentId) {
    this.fxInstrumentDataLoading = true;
    this.fxInstrumentService.getById(fxInstrumentId).subscribe(data => {
      this.fxInstrumentDataLoading = false;
      this.fxInstrumentData.next(data);
    });
  }

  lodaFx(id) {
    this.fxOperationDataLoading = true;
    this.fxOperationService
      .getById(id)
      .pipe(untilDestroyed(this))
      .subscribe(
        (fxOperationDataHttp: IFXOperationHttpInterface) => {
          this.fxOperationFormData = new FXOperationInitialValue(fxOperationDataHttp);

          this.fxOperationFullData = { ...fxOperationDataHttp };

          this.updateFxInstrument(this.fxOperationFullData.fxInstrumentId);
          if (this.isFXauthorized) {
            this.loadInitialBalances();
          }

          this.fxOperationDataLoading = false;
        },
        err => {
          this.router.navigateByUrl("/not-found", { replaceUrl: true });
        }
      );
  }

  ngOnDestroy() {}

  public handleUpdate(form: IFXOperationInterface): void {
    if (!this.form.dirty) {
      this.notificationMessageService.info("Nothing is changed");
    } else if (this.form && this.form.valid) {
      this.popupConfirmService.show(null, null, () => {
        this.fxOperationDataLoading = true;
        this.fxOperationService
          .update(this.fxOperationId, this.form.getRawValue())
          .pipe(untilDestroyed(this))
          .subscribe(
            resp => {
              // this.form.reset();
              this.form.markAsPristine();
              this.formIsUpdatedSuccessfully = true;
              this.fxOperationDataLoading = false;
              // this.router.navigate(["admin/operations/fx"]);
              this.notificationMessageService.success("FX Operation has been Updated successfully");
            },
            err => {
              this.fxOperationDataLoading = false;
            }
          );
      });
    } else {
      this.notificationMessageService.error(
        "Form is invalid, please make sure all required fields are filled out correctly"
      );
      // MarkFormGroupTouched(this.form.controls);
      // this.fxForm.ma
    }
  }

  handleChangeAuthorize(status: string, message: string) {
    if (this.form && this.form.dirty) {
      this.notificationMessageService.warn(
        "Form is changed, if you want to change authorization status please update the form first"
      );
      return;
    }
    this.popupConfirmService.show(null, null, () => {
      this.fxOperationDataLoading = true;
      this.authorizationIsDisabled = true;
      this.fxOperationService
        .changeAuthorizationStatus(this.fxOperationId, EFXAuthorizationStatuses[status])
        .pipe(untilDestroyed(this))
        .subscribe(
          response => {
            this.fxOperationDataLoading = false;
            this.lodaFx(this.fxOperationId);
            this.notificationMessageService.success(message);
            this.authorizationIsDisabled = false;
          },
          error => {
            this.fxOperationDataLoading = false;
            this.authorizationIsDisabled = false;
          }
        );
    });
  }

  authorizationStatusColor(status) {
    return EFXAuthorizationStatusesColors[status];
  }

  operationStatusColor(status: string): string {
    return status ? EOperationStatusColor[status] : null;
  }

  handleExecuteTransactions() {
    this.popupConfirmService.show(null, null, () => {
      this.fxOperationDataLoading = true;
      this.operationService.makeOperationTransactions(this.fxOperationId, EOperationType.FX).subscribe(
        resp => {
          this.lodaFx(this.fxOperationId);
          this.fxOperationDataLoading = false;
        },
        err => {
          this.lodaFx(this.fxOperationId);
          this.fxOperationDataLoading = false;
        }
      );
    });
  }
}
