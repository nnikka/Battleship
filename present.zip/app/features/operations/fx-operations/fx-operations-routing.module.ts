import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { FxOperationsListComponent } from "./containers/fx-operations-list/fx-operations-list.component";
import { ConfirmDeactivateGuard } from "@core/guards/confirm-deactivate-guard.guard";
import { FxOperationAddComponent } from "./containers/fx-operation-add/fx-operation-add.component";
import { FXInstrumentsResolver } from "./resolvers/fx-instrument.resolver";
import { FxOperationComponent } from "./containers/fx-operation/fx-operation.component";

const routes: Routes = [
  {
    path: "",
    component: FxOperationsListComponent
  },
  {
    path: "add-fx-operation",
    component: FxOperationAddComponent,
    resolve: {
      fxInstruments: FXInstrumentsResolver
    },
    canDeactivate: [ConfirmDeactivateGuard]
  },
  {
    path: ":id",
    component: FxOperationComponent,
    resolve: {
      fxInstruments: FXInstrumentsResolver
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FxOperationsRoutingModule {}
