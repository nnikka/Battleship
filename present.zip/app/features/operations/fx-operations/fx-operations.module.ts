import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { FxOperationsRoutingModule } from "./fx-operations-routing.module";
import { FxOperationsListComponent } from "./containers/fx-operations-list/fx-operations-list.component";
import { SharedModule } from "@shared/shared.module";
import { FxOperationAddComponent } from "./containers/fx-operation-add/fx-operation-add.component";
import { FxOperationFormComponent } from "./components/fx-operation-form/fx-operation-form.component";
import { FxOperationCardComponent } from "./components/fx-operation-card/fx-operation-card.component";
import { FxOperationComponent } from "./containers/fx-operation/fx-operation.component";
import {
  FxOperationCurrencyCardComponent
} from "./components/fx-operation-currency-card/fx-operation-currency-card.component";
import { StoreModule } from "@ngrx/store";
import { EffectsModule } from "@ngrx/effects";
import { fxModuleEffects } from "./store/effects";
import { FXInstrumentService } from "./services/fx-instrument.service";
import { FXOperationService } from "./services/fx-operation.service";
import { FXInstrumentsResolver } from "./resolvers/fx-instrument.resolver";
import { FXInstrumentsReducer } from "./store/fx-instruments/fx-instrument.reducer";

@NgModule({
  declarations: [
    FxOperationsListComponent,
    FxOperationAddComponent,
    FxOperationFormComponent,
    FxOperationCardComponent,
    FxOperationComponent,
    FxOperationCurrencyCardComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    FxOperationsRoutingModule,
    StoreModule.forFeature("fxInstruments", FXInstrumentsReducer),
    EffectsModule.forFeature(fxModuleEffects)
  ],
  providers: [FXInstrumentService, FXOperationService, FXInstrumentsResolver]
})
export class FxOperationsModule { }
