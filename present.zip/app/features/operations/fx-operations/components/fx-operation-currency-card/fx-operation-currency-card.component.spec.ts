import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { FxOperationCurrencyCardComponent } from "./fx-operation-currency-card.component";

describe("FxOperationCurrencyCardComponent", () => {
  let component: FxOperationCurrencyCardComponent;
  let fixture: ComponentFixture<FxOperationCurrencyCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FxOperationCurrencyCardComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FxOperationCurrencyCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
