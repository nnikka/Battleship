import { Component, OnInit, Input } from "@angular/core";
import { Subject } from "rxjs";

@Component({
  selector: "app-fx-operation-currency-card",
  templateUrl: "./fx-operation-currency-card.component.html",
  styleUrls: ["./fx-operation-currency-card.component.scss"]
})
export class FxOperationCurrencyCardComponent implements OnInit {
  @Input() cashData: Subject<any>;

  clientBalances;

  selectedBalanceClient;
  selectedBalanceCounterparty;

  constructor() {}

  ngOnInit() {
    this.cashData.subscribe(data => {
      if (data) {
        this.clientBalances = data.clientBalances;
        this.selectedBalanceClient = data.selectedIDs.selectedBalanceClient;
        this.selectedBalanceCounterparty = data.selectedIDs.selectedBalanceCounterparty;
      }
    });
  }
}
