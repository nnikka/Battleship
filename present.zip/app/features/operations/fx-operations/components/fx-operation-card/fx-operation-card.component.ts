import { Component, OnInit, Input } from "@angular/core";
import { IFXOperationHttpInterface } from "../../interfaces/fx-operations-http.interface";
import { IntlService } from "@progress/kendo-angular-intl";

@Component({
  selector: "app-fx-operation-card",
  templateUrl: "./fx-operation-card.component.html",
  styleUrls: ["./fx-operation-card.component.scss"]
})
export class FxOperationCardComponent implements OnInit {
  @Input() fxOperationInitialData: IFXOperationHttpInterface;

  constructor(public intl: IntlService) {}

  ngOnInit() {}
}
