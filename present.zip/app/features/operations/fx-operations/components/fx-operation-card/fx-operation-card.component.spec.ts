import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { FxOperationCardComponent } from "./fx-operation-card.component";

describe("FxOperationCardComponent", () => {
  let component: FxOperationCardComponent;
  let fixture: ComponentFixture<FxOperationCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FxOperationCardComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FxOperationCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
