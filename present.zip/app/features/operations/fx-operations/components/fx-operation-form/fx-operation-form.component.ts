import { Component, OnInit, Input, OnDestroy } from "@angular/core";
import { Controls, DataInput, FormGroupOptions } from "ngx-sub-form";

import { untilDestroyed } from "ngx-take-until-destroy";

import { IFXOperationInterface } from "../../interfaces/fx-operations-form.interface";
import { FormControl, Validators, AbstractControl } from "@angular/forms";
import { EClientStatuses } from "@features/static-data/clients/models/ClientStatuses.enum";
import { ComplexFormRoot } from "src/app/general/abstractClasses/ComplexFormRoot.abstractClass";
import { FxOperationFormValidator } from "./helpers/custom-validators";
import { ICurrency } from "@core/models/catalogs/currency.interface";
import { NotificationMessageService } from "@core/services/notification-message.service";
import { CurrencyRateService } from "../../services/currency-rates.service";
import { ICurrencyRate } from "../../interfaces/currency-rate.interface";
import { getObjectParamFromArray } from "src/utils/array.helper";
import { IFXOperationHttpInterface } from "../../interfaces/fx-operations-http.interface";
import { EClientTypes } from "@features/static-data/clients/models/ClientTypes.enum";
import { IFXInstrumentsInterface } from "../../interfaces/fx-instruments.interface";
import { CustomDateValidators } from "src/app/general/validators/date.validator";

@Component({
  selector: "app-fx-operation-form",
  templateUrl: "./fx-operation-form.component.html",
  styleUrls: ["./fx-operation-form.component.scss"]
})
export class FxOperationFormComponent extends ComplexFormRoot<IFXOperationInterface> implements OnInit, OnDestroy {
  // tslint:disable-next-line: no-input-rename
  @DataInput() @Input("fxForm") public dataInput: Required<IFXOperationInterface>;

  listItems = [
    { name: "Small", value: 1 },
    { name: "Medium", value: 2 },
    { name: "Large", value: 3 }
  ];

  authorizedClientRequiredHttpParams: any = {
    "filterItem.status": EClientStatuses.Authorized,
    SortBy: "clientName",
    SortDirection: 0
  };
  authorizedCounterPartyRequiredHttpParams: any = {
    "filterItem.clientTypes": EClientTypes.Counterparty,
    "filterItem.status": EClientStatuses.Authorized,
    SortBy: "clientName",
    SortDirection: 0
  };
  clientIsDisabled = false;
  currentRateFromBack;

  currencyIsLoading: boolean = false;

  @Input() reasonabilityCheck = 1;

  @Input() currencies: ICurrency[];
  @Input() fxInstruments: IFXOperationHttpInterface[];

  constructor(
    private notificationMessageService: NotificationMessageService,
    private currencyRateService: CurrencyRateService
  ) {
    super();
  }

  changeCurrency() {
    const fromCurrencyId = this.formGroup.controls.fromCurrencyId.value;
    const toCurrencyId = this.formGroup.controls.toCurrencyId.value;

    if (fromCurrencyId && toCurrencyId) {
      this.formGroup.controls.fromCurrencyId.setValue(toCurrencyId, { emitEvent: false });
      this.formGroup.controls.fromCurrencyId.markAsDirty();
      this.formGroup.controls.toCurrencyId.setValue(fromCurrencyId, { emitEvent: false });
      this.formGroup.controls.toCurrencyId.markAsDirty();

      // DONE(giorgi): implement rate change after currency is changed

      this.getRate();
    }
  }

  ngOnInit() {
    // HACK(giorgi): this is call to the subform lib base class
    super.ngOnInit();
    this.addListenersForDynamicFormParts();

    // if (this.formGroupControls.toCurrencyId.value
    // || this.formGroupControls.toCurrencyId.value
    // || this.formGroupControls.tradeDate.value) {
    //   this.getRate();
    // }
  }

  addListenersForDynamicFormParts() {
    //
    this.formGroupControls.amount.valueChanges.pipe(untilDestroyed(this)).subscribe((val: number) => {
      if (this.formGroupControls.amount.enabled && this.formGroupControls.amountTo.disabled) {
        this.calculateamountToFor(this.formGroupControls.amountTo, val, "multiplication");
      }
    });
    this.formGroupControls.amountTo.valueChanges.pipe(untilDestroyed(this)).subscribe((val: number) => {
      if (this.formGroupControls.amountTo.enabled && this.formGroupControls.amount.disabled) {
        this.calculateamountToFor(this.formGroupControls.amount, val, "division");
      }
    });

    this.formGroupControls.rate.valueChanges.pipe(untilDestroyed(this)).subscribe((val: number) => {
      this.formGroup.updateValueAndValidity();
      if (val) {
        this.checkRateReasonability(val);
      }

      if (this.formGroupControls.amountTo.enabled && this.formGroupControls.amount.disabled) {
        this.calculateamountToFor(this.formGroupControls.amount, this.formGroupControls.amountTo.value, "division");
      } else if (this.formGroupControls.amountTo.disabled && this.formGroupControls.amount.enabled) {
        this.calculateamountToFor(
          this.formGroupControls.amountTo,
          this.formGroupControls.amount.value,
          "multiplication"
        );
      }
    });

    // DONE(giorgi): fix from currency error sends request
    this.formGroupControls.fromCurrencyId.valueChanges.pipe(untilDestroyed(this)).subscribe((val: number) => {
      if (
        this.formGroupControls.tradeDate.value !== null &&
        this.formGroupControls.toCurrencyId.value !== null &&
        this.formGroupControls.fromCurrencyId.errors === null
      ) {
        this.getRate();
      }
    });
    this.formGroupControls.tradeDate.valueChanges.pipe(untilDestroyed(this)).subscribe((fxId: number) => {
      if (
        this.formGroupControls.fromCurrencyId.value !== null &&
        this.formGroupControls.toCurrencyId.value !== null &&
        this.formGroupControls.fromCurrencyId.errors === null
      ) {
        this.getRate();
      }
      this.calcSettlementDate();
    });
    this.formGroupControls.toCurrencyId.valueChanges.pipe(untilDestroyed(this)).subscribe((val: number) => {
      // HACK(giorgi): force form to recalculate validations before checking errors
      this.formGroup.updateValueAndValidity();
      if (
        this.formGroupControls.fromCurrencyId.value !== null &&
        this.formGroupControls.tradeDate.value !== null &&
        this.formGroupControls.fromCurrencyId.errors === null
      ) {
        this.getRate();
      }
    });

    this.formGroupControls.fxInstrumentId.valueChanges.pipe(untilDestroyed(this)).subscribe((fxId: number) => {
      if (fxId) {
        this.calcSettlementDate();
        this.checkRateReasonability(this.formGroupControls.rate.value);
      }
    });
  }

  checkRateReasonability(val) {
    const fxId = this.formGroupControls.fxInstrumentId.value;
    this.reasonabilityCheck = (getObjectParamFromArray(
      this.fxInstruments,
      fxId,
      "id",
      "",
      true
    ) as IFXInstrumentsInterface).reasonabilityCheck;
    if (val && val !== this.currentRateFromBack && this.reasonabilityCheck !== 0) {
      const percentOfCurrentValue = parseFloat(((this.currentRateFromBack / 100) * this.reasonabilityCheck).toFixed(4));
      if (
        val > parseFloat((this.currentRateFromBack + percentOfCurrentValue).toFixed(4)) ||
        val < parseFloat((this.currentRateFromBack - percentOfCurrentValue).toFixed(4))
      ) {
        this.formGroupControls.rate.setErrors({ reasonabilityCheck: true });
      } else {
        this.formGroupControls.rate.setErrors(null);
      }
    } else {
      this.formGroupControls.rate.setErrors(null);
    }
  }

  calcSettlementDate() {
    const tradeDate = this.formGroupControls.tradeDate.value;
    const fxId = this.formGroupControls.fxInstrumentId.value;
    const fxInstrument = getObjectParamFromArray(this.fxInstruments, fxId, "id", "", true) as IFXOperationHttpInterface;
    if (tradeDate !== null && tradeDate !== "" && fxId) {
      // month index starts from 0
      const settlementDate = new Date(tradeDate);
      settlementDate.setDate(settlementDate.getDate() + fxInstrument.latencyDay);
      const settlementDateString =
        settlementDate.getMonth() + 1 + "/" + settlementDate.getDate() + "/" + settlementDate.getFullYear();

      this.formGroupControls.settlementDate.setValue(settlementDateString);
    }
  }

  getRate() {
    // http observable is unsubscribed automatically
    this.currencyIsLoading = true;
    this.currencyRateService
      .getrateByCurrencies({
        date: this.formGroupControls.tradeDate.value,
        rate: 0,
        fromCurrencyId: this.formGroupControls.fromCurrencyId.value,
        toCurrencyId: this.formGroupControls.toCurrencyId.value
      })
      .pipe(untilDestroyed(this))
      .subscribe(
        (response: ICurrencyRate) => {
          this.currentRateFromBack = response.rate;
          this.formGroupControls.rate.setValue(response.rate);
          this.currencyIsLoading = false;
        },
        () => {
          this.formGroupControls.rate.setValue(null);
          this.notificationMessageService.info("Can't retrieve currency rate, please check date");
          this.notificationMessageService.info("Operation will take place without reasonability check");
          this.currencyIsLoading = false;
        }
      );
  }

  ngOnDestroy() {}

  // implement
  calculateamountToFor(controlToSet: AbstractControl, val, action: "division" | "multiplication") {
    const rate = this.formGroupControls.rate.value;
    if (action === "division") {
      controlToSet.setValue(val / rate);
    } else if (action === "multiplication") {
      controlToSet.setValue(val * rate);
    }
  }

  // change amountTo input
  enableInput(type: "nominal" | "currency") {
    if (type === "nominal") {
      if (!this.formGroupControls.amount.enabled) {
        this.formGroupControls.amount.enable();
        this.formGroupControls.amountTo.disable();
        this.calculateamountToFor(
          this.formGroupControls.amountTo,
          this.formGroupControls.amount.value,
          this.formGroupControls.rate.value
        );
      }
    } else if (type === "currency") {
      if (!this.formGroupControls.amountTo.enabled) {
        this.formGroupControls.amountTo.enable();
        this.formGroupControls.amount.disable();
        this.calculateamountToFor(
          this.formGroupControls.amount,
          this.formGroupControls.amountTo.value,
          this.formGroupControls.rate.value
        );
      }
    }
  }

  protected getFormControls(): Controls<IFXOperationInterface> {
    // disable some values from interface
    return {
      fxInstrumentId: new FormControl(null, [Validators.required]),
      tradeDate: new FormControl(null, [Validators.required]),
      settlementDate: new FormControl(null, [Validators.required, CustomDateValidators.minimumDateByDays(60)]),
      clientId: new FormControl(null, [Validators.required]),
      clientCounterpartyId: new FormControl(null, [Validators.required]),
      fromCurrencyId: new FormControl(null, [Validators.required]),
      toCurrencyId: new FormControl({ value: null, disabled: false }, [Validators.required]),
      rate: new FormControl(null, [Validators.required]),
      amount: new FormControl({ value: null, disabled: false }, [Validators.required]),
      amountTo: new FormControl({ value: null, disabled: true }, [Validators.required]),
      commissionAmount: new FormControl(null),
      commissionCurrencyId: new FormControl(null),
      counterpartyCommission: new FormControl(null),
      counterpartyCommissionCurrencyId: new FormControl(null),
      comment: new FormControl()
    };
  }
  public getFormGroupControlOptions(): FormGroupOptions<IFXOperationInterface> {
    return {
      validators: [FxOperationFormValidator()]
    };
  }
}
