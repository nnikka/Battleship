import { FormGroup, ValidatorFn, AbstractControl, ValidationErrors, FormControl } from "@angular/forms";
import { TypedFormGroup, TypedValidatorFn } from "ngx-sub-form";
import { IFXOperationInterface } from "@features/operations/fx-operations/interfaces/fx-operations-form.interface";

// full form validation
export function FxOperationFormValidator(): TypedValidatorFn<IFXOperationInterface> {
  return (formGroup: TypedFormGroup<IFXOperationInterface>): ValidationErrors | null => {
    // Dates validation
    const tradeDateControl = formGroup.controls.tradeDate;
    const settlementDateControl = formGroup.controls.settlementDate;
    validateSettementDateAndTradeDate(tradeDateControl, settlementDateControl);

    const client = formGroup.controls.clientId;
    const counterpart = formGroup.controls.clientCounterpartyId;
    validateCounterpatAndClient(client, counterpart);

    const fromCurrencyId = formGroup.controls.fromCurrencyId;
    const toCurrencyId = formGroup.controls.toCurrencyId;
    validateClientAndCounterpartCurrency(fromCurrencyId, toCurrencyId);

    // need names word

    // const amountNominal = formGroup.controls.clientCurrency;
    // const counterpartCurrency = formGroup.controls.counterpartCurrency;
    // validateClientAndCounterpartCurrency(clientCurrency, counterpartCurrency);

    // return null default for form error we set individual control errors above
    return null;
  };
}

export function validateSettementDateAndTradeDate(tradeDateControl, settlementDateControl) {
  let tradeTime = null;
  let settlementTime = null;

  if (tradeDateControl.value) {
    tradeTime = new Date(tradeDateControl.value).getTime();
  }
  if (settlementDateControl.value) {
    settlementTime = new Date(settlementDateControl.value).getTime();
  }

  if (tradeTime && settlementTime && tradeTime > settlementTime) {
    settlementDateControl.setErrors({ settlementDateMustBeMoreOrEqualThenTradeDate: true });
    // return { settlementDateMustBeMoreOrEqualThenTradeDate: true };
  } else if (tradeTime && settlementTime && !(tradeTime > settlementTime)) {
    settlementDateControl.setErrors(null);
    // return null;
  }
}

export function validateCounterpatAndClient(client: AbstractControl, counterpart: AbstractControl) {
  const clientName = client.value;
  const counterpartName = counterpart.value;
  if (clientName === counterpartName && (clientName || counterpartName)) {
    client.setErrors({ clientNameMustBeDifferentFromCounterpartName: true });
  } else {
    // TODO(giorgi): think about new solution for this part we dont want to lost other errors
    let required;
    if (client.errors) {
      required = client.errors.required;
      if (required) {
        client.setErrors({ required });
      } else {
        client.setErrors(null);
      }
    }
  }
}

export function validateClientAndCounterpartCurrency(fromCurrencyId: AbstractControl, toCurrencyId: AbstractControl) {
  const fromCurrencyIdValue = fromCurrencyId.value;
  const toCurrencyIdValue = toCurrencyId.value;
  if (fromCurrencyIdValue === toCurrencyIdValue && (fromCurrencyIdValue || toCurrencyIdValue)) {
    fromCurrencyId.setErrors({ fromCurrencyIdMustBeDifferentThenToCurrencyId: true });
  } else {
    // TODO(giorgi): think about new solution for this part we dont want to lost other errors
    let required;
    if (fromCurrencyId.errors) {
      required = fromCurrencyId.errors.required;
      if (required) {
        fromCurrencyId.setErrors({ required });
      } else {
        fromCurrencyId.setErrors(null);
      }
    } else {
      fromCurrencyId.setErrors(null);
    }
  }
}

export function stockOperationSharesValidator(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: boolean } | null => {
    return null;
  };
}
