import { IFXOperationHttpInterface } from "@features/operations/fx-operations/interfaces/fx-operations-http.interface";
import { convertToDMY } from "src/utils/date-converter.helper";

export class FXOperationInitialValue {
  // exact form values
  fxInstrumentId;
  tradeDate;
  settlementDate;
  clientId;
  clientCounterpartyId;
  fromCurrencyId;
  toCurrencyId;
  rate;
  amount;
  amountTo;
  commissionAmount;
  commissionCurrencyId;
  counterpartyCommission;
  counterpartyCommissionCurrencyId;
  comment;

  constructor(fxOperationHttpForm: IFXOperationHttpInterface) {
    let amountFrom;
    if (fxOperationHttpForm.amount) {
      amountFrom = fxOperationHttpForm.amount * fxOperationHttpForm.rate;
    }
    this.fxInstrumentId = fxOperationHttpForm.fxInstrumentId;
    if (fxOperationHttpForm.tradeDate) {
      this.tradeDate = convertToDMY(fxOperationHttpForm.tradeDate).toLocaleDateString();
    }
    if (fxOperationHttpForm.settlementDate) {
      this.settlementDate = convertToDMY(fxOperationHttpForm.settlementDate).toLocaleDateString();
    }
    this.clientId = fxOperationHttpForm.clientId;
    this.clientCounterpartyId = fxOperationHttpForm.clientCounterpartyId;
    this.fromCurrencyId = fxOperationHttpForm.fromCurrencyId;
    this.toCurrencyId = fxOperationHttpForm.toCurrencyId;
    this.rate = fxOperationHttpForm.rate;
    this.amount = fxOperationHttpForm.amount;
    this.amountTo = amountFrom;
    this.commissionAmount = fxOperationHttpForm.commissionAmount;
    this.commissionCurrencyId = fxOperationHttpForm.commissionCurrencyId;
    this.counterpartyCommission = fxOperationHttpForm.counterpartyCommission;
    this.counterpartyCommissionCurrencyId = fxOperationHttpForm.counterpartyCommissionCurrencyId;
    this.comment = fxOperationHttpForm.comment;
  }
}
