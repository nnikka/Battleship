import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { FxOperationFormComponent } from "./fx-operation-form.component";

describe("FxOperationFormComponent", () => {
  let component: FxOperationFormComponent;
  let fixture: ComponentFixture<FxOperationFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FxOperationFormComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FxOperationFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
