import { IFXInstrumentState, initialFXInstrumentState } from "./fx-instruments/fx-instrument.state";

export interface IFXModuleState {
  fxInstruments: IFXInstrumentState;
}

export const initialFXModuleState = {
  fxInstruments: initialFXInstrumentState
};

export function getInitialState(): IFXModuleState {
  return initialFXModuleState;
}
