import { Injectable } from "@angular/core";
import { Effect, ofType, Actions } from "@ngrx/effects";
import { of } from "rxjs";
import { switchMap, map, catchError } from "rxjs/operators";

import {
  EFXInstrumentActions,
  GetFXInstruments,
  GetFXInstrumentsFailed,
  GetFXInstrumentsSuccess,
  ClearFXInstruments
} from "./fx-instrument.action";
import { FXInstrumentService } from "../../services/fx-instrument.service";
import { IFXInstrumentsInterface } from "../../interfaces/fx-instruments.interface";

@Injectable()
export class FXInstrumentEffects {
  @Effect()
  getAdditionalCommissions$ = this.actions.pipe(
    ofType<GetFXInstruments>(EFXInstrumentActions.GetFXInstruments),
    switchMap(() => {
      return this.fxInstrumentService.getFXInstruments().pipe(
        map((commissions: IFXInstrumentsInterface[]) => new GetFXInstrumentsSuccess(commissions)),
        catchError(error => of(new GetFXInstrumentsFailed()))
      );
    })
  );

  constructor(private actions: Actions, private fxInstrumentService: FXInstrumentService) {}
}
