import { Action } from "@ngrx/store";
import { IFXInstrumentsInterface } from "../../interfaces/fx-instruments.interface";
export enum EFXInstrumentActions {
  GetFXInstruments = "[FX Insruments] Get FX Insruments",
  GetFXInstrumentsSuccess = "[FX Insruments] Get FX Insruments Success",
  GetFXInstrumentsFailed = "[FX Insruments] Get FX Insruments Failed",
  ClearFXInstruments = "[FX Insruments] Get FX Insruments Failed"
}

export class GetFXInstruments implements Action {
  public readonly type = EFXInstrumentActions.GetFXInstruments;
}

export class GetFXInstrumentsSuccess implements Action {
  public readonly type = EFXInstrumentActions.GetFXInstrumentsSuccess;
  constructor(public payload: IFXInstrumentsInterface[]) {}
}

export class GetFXInstrumentsFailed implements Action {
  public readonly type = EFXInstrumentActions.GetFXInstrumentsFailed;
}

export class ClearFXInstruments implements Action {
  public readonly type = EFXInstrumentActions.ClearFXInstruments;
}

export type FXInstrumentActions =
  | GetFXInstruments
  | GetFXInstrumentsSuccess
  | GetFXInstrumentsFailed
  | ClearFXInstruments;
