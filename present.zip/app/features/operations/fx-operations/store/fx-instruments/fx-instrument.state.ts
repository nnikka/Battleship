import { IFXInstrumentsInterface } from "../../interfaces/fx-instruments.interface";

export interface IFXInstrumentState {
  fxInstruments: IFXInstrumentsInterface[];
  loaded: boolean;
  failed: boolean;
  lastUpdated: Date;
}

export const initialFXInstrumentState = {
  fxInstruments: [],
  loaded: false,
  failed: false,
  lastUpdated: null
};
