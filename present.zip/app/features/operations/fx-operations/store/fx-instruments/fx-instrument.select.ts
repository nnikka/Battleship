import { createSelector } from "@ngrx/store";

import { IFXModuleState } from "../state";
import { EFXAuthorizationStatuses } from "@features/static-data/fx-instruments/models/fxAuthorizationStatuses.enum";
import { IFXInstrumentState } from "./fx-instrument.state";

const selectFXInstrumentState = (state: IFXModuleState) => state.fxInstruments;

export const selectFXInstruments = createSelector(
  selectFXInstrumentState,
  (state: IFXInstrumentState) => state.fxInstruments
);

export const selectAuthorizedFXInstruments = createSelector(selectFXInstrumentState, (state: IFXInstrumentState) => {
  return state.fxInstruments.filter(iss => iss.status === EFXAuthorizationStatuses.Authorized);
});

export const selectFXInstrumentLoadStatus = createSelector(
  selectFXInstrumentState,
  (state: IFXInstrumentState) => state.loaded
);

export const selectFXInstrumentStatuses = createSelector(selectFXInstrumentState, (state: IFXInstrumentState) => {
  return { failed: state.failed, loaded: state.loaded, lastUpdated: state.lastUpdated };
});
