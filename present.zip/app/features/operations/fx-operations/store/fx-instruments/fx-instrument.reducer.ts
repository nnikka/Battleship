import { EFXInstrumentActions, FXInstrumentActions, GetFXInstruments } from "../fx-instruments/fx-instrument.action";
import { initialFXInstrumentState, IFXInstrumentState } from "./fx-instrument.state";

export function FXInstrumentsReducer(
  state = initialFXInstrumentState,
  action: FXInstrumentActions
): IFXInstrumentState {
  switch (action.type) {
    case EFXInstrumentActions.GetFXInstrumentsSuccess: {
      return {
        ...state,
        fxInstruments: action.payload,
        lastUpdated: new Date(),
        loaded: true
      };
    }
    case EFXInstrumentActions.GetFXInstrumentsFailed: {
      return {
        ...state,
        ...initialFXInstrumentState,
        failed: true
      };
    }
    case EFXInstrumentActions.ClearFXInstruments: {
      return {
        ...state,
        ...initialFXInstrumentState
      };
    }
    default:
      return state;
  }
}
