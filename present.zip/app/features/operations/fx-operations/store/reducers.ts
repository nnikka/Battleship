import { ActionReducerMap } from "@ngrx/store";
import { IFXModuleState } from "./state";
import { FXInstrumentsReducer } from "./fx-instruments/fx-instrument.reducer";

export const bondsModuleReducers: ActionReducerMap<IFXModuleState, any> = {
  fxInstruments: FXInstrumentsReducer
};
