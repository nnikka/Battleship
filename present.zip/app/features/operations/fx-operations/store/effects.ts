import { FXInstrumentEffects } from "./fx-instruments/fx-instrument.effect";

export const fxModuleEffects = [FXInstrumentEffects];
