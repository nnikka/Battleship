import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { ConfigService } from "@env/service/config.service";
import { ICurrencyRate } from "../interfaces/currency-rate.interface";
import { IHttpFX } from "@features/static-data/fx-instruments/models/IHttpFX";

@Injectable()
export class FXInstrumentService {
  constructor(private http: HttpClient, private configService: ConfigService) {}
  getFXInstruments(): Observable<any> {
    return this.http.get(`${this.configService.config.apiBaseurl}/api/FXInstruments/GetFXInstruments`);
  }

  getById(id: string): Observable<IHttpFX> {
    return this.http.get<IHttpFX>(`${this.configService.config.apiBaseurl}/api/FXInstruments/${id}`);
  }
}
