import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { ConfigService } from "@env/service/config.service";
import { IPagingHttpResponse } from "@shared/models/IPagingHttpResponse";
import { IFXOperationHttpInterface } from "../interfaces/fx-operations-http.interface";

@Injectable()
export class FXOperationService {
  constructor(private http: HttpClient, private configService: ConfigService) { }

  getClientBalanceOnCounterparty(clientID, counterpartID) {
    return this.http.get(
      `${
      this
        .configService
        .config
        .apiBaseurl
      }/api/FXOperations/GetClientCashBalancesOnCounterparty/${clientID}/${counterpartID}`
    );
  }

  getAll(queryParams): Observable<IPagingHttpResponse<IFXOperationHttpInterface>> {
    return this.http.get<IPagingHttpResponse<IFXOperationHttpInterface>>(
      `${this.configService.config.apiBaseurl}/api/FXOperations`,
      {
        params: queryParams
      }
    );
  }

  create(formData: IFXOperationHttpInterface) {
    return this.http.post(`${this.configService.config.apiBaseurl}/api/FXOperations`, formData);
  }

  getById(id: string): Observable<IFXOperationHttpInterface> {
    return this.http.get<IFXOperationHttpInterface>(`${this.configService.config.apiBaseurl}/api/FXOperations/${id}`);
  }

  update(id: string, params): Observable<any> {
    params.id = id;
    return this.http.put(`${this.configService.config.apiBaseurl}/api/FXOperations/${id}`, params);
  }

  changeAuthorizationStatus(id: string, status: number): Observable<any> {
    return this.http.put(
      `${this.configService.config.apiBaseurl}/api/FXOperations/ChangeAuthorizationStatus/${id}/${status}`,
      {}
    );
  }

  exportExcel(): Observable<any> {
    return this.http.get(
      `${this.configService.config.apiBaseurl}/api/FXOperations/ExportFXOperationsWithTransaction`,
      {
        responseType: "blob"
      }
    );
  }
}
