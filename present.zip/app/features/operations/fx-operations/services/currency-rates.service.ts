import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { ConfigService } from "@env/service/config.service";
import { ICurrencyRate } from "../interfaces/currency-rate.interface";

@Injectable({
  providedIn: "root"
})
export class CurrencyRateService {
  constructor(private http: HttpClient, private configService: ConfigService) {}

  getrateByCurrencies(params: ICurrencyRate): Observable<any> {
    return this.http.post(`${this.configService.config.apiBaseurl}/api/CurrencyRates/GetCurrencyRate`, params);
  }
}
