export interface IFXOperationHttpInterface {
  id?: string;

  audit?: any;

  clientName: string;

  clientCounterpartyName: string;

  fxInstrumentId: string;

  latencyDay?: number;

  tradeDate: string;

  settlementDate: string;

  clientId: string;

  clientCounterpartyId: string;

  fromCurrencyId: string;
  fromCurrencyName: string;

  toCurrencyId: string;
  toCurrencyName: string;

  rate: number;

  amount: number;

  amountFrom?: number;

  commissionAmount: number;

  commissionCurrencyId: string;

  commissionCurrencyName: string;

  counterpartyCommission: number;

  counterpartyCommissionCurrencyName: string;

  counterpartyCommissionCurrencyId: string;

  fxInstrumentName: string;

  operationStatus?: number;

  operationTransactions?: any;

  comment?: string;
}
