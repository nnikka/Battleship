export interface ICurrencyRate {
  date: string;
  rate: number;
  fromCurrencyId: number;
  toCurrencyId: number;
}
