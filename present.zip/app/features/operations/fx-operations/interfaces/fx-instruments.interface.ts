export interface IFXInstrumentsInterface {
  createDate: string;
  createUser: string;
  createUserId: number;
  id: number;
  instrumentName: string;
  lastModifiedDate: string;
  lastModifiedUser: string;
  lastModifiedUserId: string;
  latencyDay: number;
  reasonabilityCheck: number;
  status: number;
}
