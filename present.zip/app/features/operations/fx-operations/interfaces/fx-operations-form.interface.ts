export interface IFXOperationInterface {
  fxInstrumentId: string;

  tradeDate: string;

  settlementDate: string;

  clientId: string;

  clientCounterpartyId: string;

  fromCurrencyId: string;

  toCurrencyId: string;

  rate: string;

  amount: string;

  amountTo: string;

  commissionAmount: string;

  commissionCurrencyId: string;

  counterpartyCommission: number;
  counterpartyCommissionCurrencyId: string;

  comment: string;
}
