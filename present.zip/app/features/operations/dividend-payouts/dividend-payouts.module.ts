import { NgModule } from "@angular/core";
import { DividendPayoutsRoutingRoutingModule } from "./dividend-payouts-routing.module";
import { DividendPayoutsListComponent } from "./containers/dividend-payouts-list/dividend-payouts-list.component";
import { DividendPayoutComponent } from "./containers/dividend-payout/dividend-payout.component";
import { AddDividendPayoutComponent } from "./containers/add-dividend-payout/add-dividend-payout.component";
import { SharedModule } from "@shared/shared.module";
import { DividendPayoutFormComponent } from "./components/dividend-payout-form/dividend-payout-form.component";

import { DividendPayoutService } from "./services/dividend-payout.service";
import { DividendPayoutCardComponent } from "./components/dividend-payout-card/dividend-payout-card.component";
import {
  DividendTransactionsListComponent
} from "./components/dividend-transactions-list/dividend-transactions-list.component";

@NgModule({
  declarations: [
    DividendPayoutsListComponent,
    DividendPayoutComponent,
    AddDividendPayoutComponent,
    DividendPayoutFormComponent,
    DividendPayoutCardComponent,
    DividendTransactionsListComponent
  ],
  imports: [SharedModule, DividendPayoutsRoutingRoutingModule],
  providers: [DividendPayoutService]
})
export class DividendPayoutsModule { }
