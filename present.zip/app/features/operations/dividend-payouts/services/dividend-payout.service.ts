import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { ConfigService } from "@env/service/config.service";
import { IHttpPagingQueryParams } from "@shared/models/IHttpPagingQueryParams";
import { IPagingHttpResponse } from "@shared/models/IPagingHttpResponse";
import { IHttpStock } from "@features/static-data/stocks/models/IHttpStock";
import { DividendPayoutParams } from "../models/DividendPayoutParams";
import { IListItemDividendPayout } from "../models/IListItemDividendPayout";
import { IHttpDividendPayout } from "../models/IHttpDividendPayout";

@Injectable()
export class DividendPayoutService {
  constructor(private http: HttpClient, private configService: ConfigService) {}

  getStockById(id: string): Observable<IHttpStock> {
    return this.http.get<IHttpStock>(`${this.configService.config.apiBaseurl}/api/Stocks/${id}`);
  }

  create(params: DividendPayoutParams): Observable<any> {
    return this.http.post(`${this.configService.config.apiBaseurl}/api/DividendPayouts`, params);
  }

  getAll(queryParams: IHttpPagingQueryParams): Observable<IPagingHttpResponse<IListItemDividendPayout>> {
    const params = queryParams as any;
    return this.http.get<IPagingHttpResponse<IListItemDividendPayout>>(
      `${this.configService.config.apiBaseurl}/api/DividendPayouts`,
      {
        params
      }
    );
  }

  getById(id: string): Observable<IHttpDividendPayout> {
    return this.http.get<IHttpDividendPayout>(`${this.configService.config.apiBaseurl}/api/DividendPayouts/${id}`);
  }

  update(id: string, params): Observable<any> {
    params.id = id;
    return this.http.put(`${this.configService.config.apiBaseurl}/api/DividendPayouts/${id}`, params);
  }

  changeAuthorizationStatus(id: string, status: number): Observable<any> {
    return this.http.put(
      `${this.configService.config.apiBaseurl}/api/DividendPayouts/ChangeAuthorizationStatus/${id}/${status}`,
      {}
    );
  }

  updateDividendTransaction(id: number, params: any): Observable<any> {
    return this.http.put(
      `${this.configService.config.apiBaseurl}/api/DividendPayouts/EditDividendPayoutTransaction/${id}`,
      params
    );
  }

  changeAuthorizationStatusToDividendPayoutTransaction(id: number, arr: number[]): Observable<any> {
    return this.http.put(
      // tslint:disable-next-line: max-line-length
      `${this.configService.config.apiBaseurl}/api/DividendPayouts/ChangeAuthorizationStatusToDividendPayoutTransaction/${id}`,
      arr
    );
  }

  executeTransactions(id: string | number): Observable<any> {
    return this.http.put(
      `${this.configService.config.apiBaseurl}/api/DividendPayouts/MakeDividendPayoutTransactions/${id}`,
      {}
    );
  }

  transferFromCounterParty(dividendPayoutOperationId: string): Observable<any> {
    return this.http.post(
      `${this.configService.config.apiBaseurl}/api/DividendPayouts/CreateCashTransferFromCounterpartyOperations`,
      {},
      { params: { dividendPayoutOperationId } }
    );
  }
}
