import { Component, OnInit, OnDestroy } from "@angular/core";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import { FormGroup } from "@angular/forms";
import { ChangesDetector } from "src/app/general/abstractClasses/ChangesDetector.abstractClass";
import { DividendPayoutService } from "../../services/dividend-payout.service";
import { IHttpDividendPayout } from "../../models/IHttpDividendPayout";
import { ActivatedRoute, Router } from "@angular/router";
import {
  EDividendPayoutAuthorizationStatuses,
  EDividendPayoutAuthorizationStatusesColors
} from "../../models/EDividendPayoutAuthorizationStatuses";
import { DividendPayoutFormValue } from "../../components/dividend-payout-form/DividendPayoutFormValue";
import { AuthService } from "@auth/services/auth.service";
import { NotificationMessageService } from "@core/services/notification-message.service";
import { PopupConfirmService } from "@components/popup-confirm/popup-confirm.service";
import { MarkFormGroupTouched } from "src/utils/mark-formgroup-touched.helper";
import { IHttpStock } from "@features/static-data/stocks/models/IHttpStock";
import { select, Store } from "@ngrx/store";
import { selectCurrencies, selectCurrencyLoadStatus } from "@core/store/currency/currency.selector";
import { selectAuthorizedIssuers, selectIssuerLoadStatus } from "@core/store/issuer/issuer.selector";
import { IAppState } from "@core/store/app.state";
import { FadeInOutAnimation } from "src/app/general/animations/fadeInOut.animation";
import { DividendPayoutTransaction } from "../../models/DividendPayoutTransaction";
import { ETransactionStatus } from "@core/models/enums/ETransactionStatus";
import { untilDestroyed } from "ngx-take-until-destroy";
import { DividendPayoutTransationStatus } from "../../models/DividendPayoutTransationStatus";
import { faThumbsDown } from "@fortawesome/free-solid-svg-icons";

@Component({
  selector: "app-dividend-payout",
  templateUrl: "./dividend-payout.component.html",
  styleUrls: ["./dividend-payout.component.scss"],
  animations: [FadeInOutAnimation]
})
export class DividendPayoutComponent extends ChangesDetector implements OnInit, OnDestroy {
  get dividendPayoutAuthorizationStatus() {
    return this.dividendPayoutData ? EDividendPayoutAuthorizationStatuses[this.dividendPayoutData.audit.status] : null;
  }

  get isdividendPayoutAuthorized() {
    return this.dividendPayoutData
      ? EDividendPayoutAuthorizationStatuses.Authorized === this.dividendPayoutData.audit.status
      : false;
  }

  get isdividendPayoutUnauthorized() {
    return this.dividendPayoutData
      ? EDividendPayoutAuthorizationStatuses.Unauthorized === this.dividendPayoutData.audit.status
      : false;
  }

  get initialFormValue(): DividendPayoutFormValue {
    return new DividendPayoutFormValue(this.dividendPayoutData);
  }

  get canAuthorize() {
    if (this.formIsUpdatedSuccessfully) {
      return false;
    }
    if (this.dividendPayoutData) {
      const lastUserId = this.dividendPayoutData.audit.lastModifiedUserId
        ? this.dividendPayoutData.audit.lastModifiedUserId
        : this.dividendPayoutData.audit.createUserId;
      if (lastUserId !== Number(this.authService.getUserId())) {
        return true;
      }
    }
    return null;
  }

  get deauthorizationIsNotAllowed(): boolean {
    if (
      this.dividendPayoutData &&
      this.dividendPayoutData.dividendPayoutTransactions &&
      this.dividendPayoutData.dividendPayoutTransactions instanceof Array &&
      this.dividendPayoutData.dividendPayoutTransactions.length > 0
    ) {
      this.dividendPayoutData.dividendPayoutTransactions.map(tr => {
        if (
          ETransactionStatus[tr.transactionStatus] === ETransactionStatus.Success ||
          ETransactionStatus[tr.transactionStatus] === ETransactionStatus.Fail
        ) {
          return true;
        }
      });
    }
    return false;
  }

  get dividentPayoutTransactions(): DividendPayoutTransaction[] {
    return this.dividendPayoutData ? this.dividendPayoutData.dividendPayoutTransactions : [];
  }

  get operationHasPaidTransaction(): boolean {
    for (const tr of this.dividentPayoutTransactions) {
      if (tr.transactionStatus === DividendPayoutTransationStatus.Paid) {
        return true;
      }
    }
    return false;
  }

  get operationHasCanceledTransaction(): boolean {
    for (const tr of this.dividentPayoutTransactions) {
      if (tr.transactionStatus === DividendPayoutTransationStatus.Canceled) {
        return true;
      }
    }
    return false;
  }

  get transferIsAllowed(): boolean {
    if (this.isdividendPayoutAuthorized && this.dividentPayoutTransactions.length > 0) {
      for (const tr of this.dividentPayoutTransactions) {
        if (tr.transactionStatus !== DividendPayoutTransationStatus.Paid) {
          return false;
        }
      }
      return true;
    }
    return false;
  }

  get isOperationSucceed(): boolean {
    if (this.dividendPayoutData) {
      for (const tr of this.dividendPayoutData.dividendPayoutTransactions) {
        if (tr.transactionStatus === DividendPayoutTransationStatus.Paid) {
          return true;
        }
      }
    }
    return false;
  }

  constructor(
    private store: Store<IAppState>,
    private dividendPayoutService: DividendPayoutService,
    private route: ActivatedRoute,
    private authService: AuthService,
    private notificationMessageService: NotificationMessageService,
    private popupConfirmService: PopupConfirmService,
    private router: Router
  ) {
    super();
  }

  currencies$ = this.store.pipe(select(selectCurrencies));
  currenciesLoaded = this.store.pipe(select(selectCurrencyLoadStatus));
  issuers$ = this.store.pipe(select(selectAuthorizedIssuers));
  issuersLoaded$ = this.store.pipe(select(selectIssuerLoadStatus));

  breadcrumbItems: IBreadcrumb[] = [
    { text: "Operations", to: null },
    { text: "Dividend payouts", to: "/admin/operations/dividend-payouts" },
    { text: "Payout", to: null }
  ];

  form: FormGroup;
  dividendPayoutId: string;
  dividendPayoutIsLoading: boolean = true;
  authorizationIsDisabled: boolean = false;
  dividendPayoutData: IHttpDividendPayout;

  stockIsLoading: boolean = false;
  stockData: IHttpStock = null;

  formIsUpdatedSuccessfully = false;

  hasUnsavedChanges(): boolean {
    if (this.form) {
      return this.form.dirty;
    }
    return false;
  }

  ngOnInit() {
    this.route.paramMap.pipe(untilDestroyed(this)).subscribe(paramsAsMap => {
      this.dividendPayoutId = paramsAsMap.get("id");
      this.loadDividendPayout(this.dividendPayoutId);
    });
  }

  formInitialized(form: FormGroup) {
    this.form = form;
    if (this.form.get("stockId") && this.form.get("stockId").value) {
      this.stockIsLoading = false;
      this.dividendPayoutService
        .getStockById(this.form.get("stockId").value)
        .pipe(untilDestroyed(this))
        .subscribe(stockData => {
          this.stockData = stockData;
          this.stockIsLoading = false;
        });
    }
    this.form
      .get("stockId")
      .valueChanges.pipe(untilDestroyed(this))
      .subscribe(stockId => {
        if (stockId) {
          this.stockIsLoading = true;
          this.loadStock(stockId);
        } else {
          this.stockIsLoading = false;
          this.stockData = null;
        }
      });
  }

  loadStock(stockId) {
    this.dividendPayoutService
      .getStockById(stockId)
      .pipe(untilDestroyed(this))
      .subscribe(stockData => {
        this.stockData = stockData;
        this.stockIsLoading = false;
      });
  }

  loadDividendPayout(id) {
    this.dividendPayoutIsLoading = true;
    this.dividendPayoutService
      .getById(id)
      .pipe(untilDestroyed(this))
      .subscribe(
        data => {
          this.dividendPayoutData = data;
          if (this.isdividendPayoutAuthorized) {
            this.loadStock(this.dividendPayoutData.stockId);
          }
          this.dividendPayoutIsLoading = false;
        },
        err => {
          this.router.navigateByUrl("/not-found", { replaceUrl: true });
        }
      );
  }

  handleUpdate() {
    if (!this.form.dirty) {
      this.notificationMessageService.info("Nothing is changed");
    } else {
      if (!this.form.valid) {
        MarkFormGroupTouched(this.form.controls);
        this.notificationMessageService.error(
          "Form is invalid, please make sure all required fields are filled out correctly"
        );
      } else {
        this.popupConfirmService.show(null, null, () => {
          this.dividendPayoutIsLoading = true;
          this.dividendPayoutService
            .update(this.dividendPayoutId, this.form.getRawValue())
            .pipe(untilDestroyed(this))
            .subscribe(
              () => {
                // this.form.reset();
                this.form.markAsPristine();
                this.formIsUpdatedSuccessfully = true;
                this.dividendPayoutIsLoading = false;
                // this.router.navigate(["admin/operations/dividend-payouts"]);
                this.notificationMessageService.success("Bond operation has been updated successfully");
              },
              () => {
                this.dividendPayoutIsLoading = false;
              }
            );
        });
      }
    }
  }

  handleChangeAuthorize(status: string, message: string) {
    if (this.form && this.form.dirty) {
      this.notificationMessageService.warn(
        "Form is changed, if you want to change authorization status please update the form first"
      );
      return;
    }
    this.popupConfirmService.show(null, null, () => {
      this.authorizationIsDisabled = true;
      this.dividendPayoutIsLoading = true;
      this.dividendPayoutService
        .changeAuthorizationStatus(this.dividendPayoutId, EDividendPayoutAuthorizationStatuses[status])
        .pipe(untilDestroyed(this))
        .subscribe(
          () => {
            this.authorizationIsDisabled = false;
            this.dividendPayoutIsLoading = false;
            this.loadDividendPayout(this.dividendPayoutId);
            this.notificationMessageService.success(message);
          },
          () => {
            this.authorizationIsDisabled = false;
            this.dividendPayoutIsLoading = false;
          }
        );
    });
  }

  handleTransferFromCounterparty() {
    this.popupConfirmService.show(null, null, () => {
      this.authorizationIsDisabled = true;
      this.dividendPayoutIsLoading = true;
      this.dividendPayoutService.transferFromCounterParty(this.dividendPayoutId).subscribe(
        resp => {
          this.notificationMessageService.success("Transfer operations have been created successfully");
          this.goToTransferOperations();
        },
        err => {
          this.authorizationIsDisabled = false;
          this.dividendPayoutIsLoading = false;
          this.notificationMessageService.error("Something went wrong");
        }
      );
    });
  }

  goToTransferOperations() {
    this.router.navigateByUrl(
      "/admin/operations/cash?pageIndex=0&pageSize=15&filterItem.dividendPayoutOperationId=" + this.dividendPayoutId
    );
  }

  onReloadData(e) {
    if (e) {
      this.loadDividendPayout(this.dividendPayoutId);
    }
  }

  ngOnDestroy() {}

  authorizationStatusColor(status: string): string {
    return status ? EDividendPayoutAuthorizationStatusesColors[status] : null;
  }
}
