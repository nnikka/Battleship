import { Component, OnInit, OnDestroy } from "@angular/core";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import { constructSelectItemsFromEnum } from "src/utils/array.helper";
import {
  EDividendPayoutAuthorizationStatuses,
  EDividendPayoutAuthorizationStatusesColors
} from "../../models/EDividendPayoutAuthorizationStatuses";
import { IntlService } from "@progress/kendo-angular-intl";
import { IColumn } from "@shared/components/complex-grid/interfaces/IColumn";
import { IOptions } from "@shared/components/complex-grid/interfaces/IOptions";

@Component({
  selector: "app-dividend-payouts-list",
  templateUrl: "./dividend-payouts-list.component.html",
  styleUrls: ["./dividend-payouts-list.component.scss"]
})
export class DividendPayoutsListComponent implements OnInit, OnDestroy {
  breadcrumbItems: IBreadcrumb[] = [
    { text: "Operations", to: null },
    { text: "Dividend payouts", to: null }
  ];
  dividendPayoutAuthorizationStatuses: { key: string; value: number }[];
  columns: IColumn[];
  options: IOptions = {
    tableKey: "DividendPayoutsList",
    columnsTooboxEnable: true,
    dblClickEnable: true,
    detailShowEnable: true
  };

  constructor(public intl: IntlService) { }

  ngOnInit() {
    this.dividendPayoutAuthorizationStatuses = constructSelectItemsFromEnum(EDividendPayoutAuthorizationStatuses);
    this.columns = [
      {
        key: "id",
        name: "ID",
        type: "number",
        filterConfig: {
          filterType: "number"
        }
      },
      {
        key: "dividendPayoutBloombergName",
        name: "Bloomberg name",
        type: "string",
        filterConfig: {
          filterType: "string"
        }
      },
      {
        key: "dividendPayoutTicker",
        name: "Ticker",
        type: "string",
        filterConfig: {
          filterType: "string"
        }
      },
      {
        key: "paymentDate",
        name: "Payment date",
        type: "date",
        filterConfig: {
          filterType: "date"
        }
      },
      {
        key: "exDividendDate",
        name: "Ex-dividend date",
        type: "date",
        filterConfig: {
          filterType: "date"
        }
      },
      {
        key: "dividendPerShare",
        name: "Dividend per share",
        type: "number",
        filterConfig: {
          filterType: "number"
        }
      },
      {
        key: "taxPerShare",
        name: "Tax per share",
        type: "number",
        filterConfig: {
          filterType: "number"
        }
      },
      {
        key: "createUserFullName",
        name: "Created by",
        type: "string",
        filterConfig: {
          filterType: "string"
        }
      },
      {
        key: "status",
        name: "Authorization status",
        type: "string",
        style: {
          colorsMapping: EDividendPayoutAuthorizationStatusesColors,
          conditionalColor: true,
          isCard: true
        },
        filterConfig: {
          filterData: this.dividendPayoutAuthorizationStatuses,
          filterType: "dropdown"
        }
      }
    ];
  }

  authorizationStatusColor(status: string) {
    return EDividendPayoutAuthorizationStatusesColors[status];
  }

  ngOnDestroy() { }
}
