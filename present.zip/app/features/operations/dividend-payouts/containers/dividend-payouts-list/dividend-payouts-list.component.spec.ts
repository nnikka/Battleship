import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { DividendPayoutsListComponent } from "./dividend-payouts-list.component";

describe("DividendPayoutsListComponent", () => {
  let component: DividendPayoutsListComponent;
  let fixture: ComponentFixture<DividendPayoutsListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DividendPayoutsListComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DividendPayoutsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
