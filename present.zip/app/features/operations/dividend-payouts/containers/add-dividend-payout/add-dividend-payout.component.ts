import { Component, OnInit, OnDestroy } from "@angular/core";
import { ChangesDetector } from "src/app/general/abstractClasses/ChangesDetector.abstractClass";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import { FormGroup } from "@angular/forms";
import { IHttpStock } from "@features/static-data/stocks/models/IHttpStock";
import { DividendPayoutService } from "../../services/dividend-payout.service";
import { Store, select } from "@ngrx/store";
import { IAppState } from "@core/store/app.state";
import { selectCurrencies, selectCurrencyLoadStatus } from "@core/store/currency/currency.selector";
import { selectAuthorizedIssuers, selectIssuerLoadStatus } from "@core/store/issuer/issuer.selector";
import { FadeInOutAnimation } from "src/app/general/animations/fadeInOut.animation";
import { MarkFormGroupTouched } from "src/utils/mark-formgroup-touched.helper";
import { NotificationMessageService } from "@core/services/notification-message.service";
import { PopupConfirmService } from "@components/popup-confirm/popup-confirm.service";
import { Router } from "@angular/router";
import { untilDestroyed } from "ngx-take-until-destroy";

@Component({
  selector: "app-add-dividend-payout",
  templateUrl: "./add-dividend-payout.component.html",
  styleUrls: ["./add-dividend-payout.component.scss"],
  animations: [FadeInOutAnimation]
})
export class AddDividendPayoutComponent extends ChangesDetector implements OnInit, OnDestroy {
  currencies$ = this.store.pipe(select(selectCurrencies));
  currenciesLoaded = this.store.pipe(select(selectCurrencyLoadStatus));
  issuers$ = this.store.pipe(select(selectAuthorizedIssuers));
  issuersLoaded$ = this.store.pipe(select(selectIssuerLoadStatus));

  breadcrumbItems: IBreadcrumb[] = [
    { text: "Operations", to: null },
    { text: "Dividend payouts", to: "/admin/operations/dividend-payouts" },
    { text: "Add payout", to: null }
  ];
  loading: boolean = false;
  form: FormGroup;

  stockIsLoading: boolean = false;
  stockData: IHttpStock = null;

  constructor(
    private store: Store<IAppState>,
    private dividendPayoutService: DividendPayoutService,
    private notificationMessageService: NotificationMessageService,
    private popupConfirmService: PopupConfirmService,
    private router: Router
  ) {
    super();
  }

  hasUnsavedChanges(): boolean {
    if (this.form) {
      return this.form.dirty;
    }
    return false;
  }

  ngOnInit() {}

  handleRegister() {
    if (this.form && !this.form.valid) {
      MarkFormGroupTouched(this.form.controls);
      this.notificationMessageService.error(
        "Form is invalid, please make sure all required fields are filled out correctly"
      );
    } else if (this.form && this.form.valid) {
      this.popupConfirmService.show(null, null, () => {
        this.loading = true;
        this.dividendPayoutService
          .create(this.form.value)
          .pipe(untilDestroyed(this))
          .subscribe(
            () => {
              this.form.reset();
              this.form.markAsPristine();
              this.router.navigate(["admin/operations/dividend-payouts"]);
              this.notificationMessageService.success("Divident payout has been added successfully");
            },
            () => {
              this.loading = false;
            }
          );
      });
    }
  }

  formInitialized(form: FormGroup) {
    this.form = form;
    this.form
      .get("stockId")
      .valueChanges.pipe(untilDestroyed(this))
      .subscribe(stockId => {
        if (stockId) {
          this.stockIsLoading = true;
          this.dividendPayoutService
            .getStockById(stockId)
            .pipe(untilDestroyed(this))
            .subscribe(stockData => {
              this.stockData = stockData;
              this.stockIsLoading = false;
            });
        } else {
          this.stockIsLoading = false;
          this.stockData = null;
        }
      });
  }

  ngOnDestroy() {}
}
