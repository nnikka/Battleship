import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { ConfirmDeactivateGuard } from "@core/guards/confirm-deactivate-guard.guard";

import { AddDividendPayoutComponent } from "./containers/add-dividend-payout/add-dividend-payout.component";
import { DividendPayoutComponent } from "./containers/dividend-payout/dividend-payout.component";
import { DividendPayoutsListComponent } from "./containers/dividend-payouts-list/dividend-payouts-list.component";

import { CurrencyResolver } from "@core/resolvers/catalogs/currency.resolver";
import { IssuerResolver } from "@core/resolvers/catalogs/issuer.resolver";

const routes: Routes = [
  {
    path: "",
    component: DividendPayoutsListComponent
  },
  {
    path: "add-dividend-payout",
    component: AddDividendPayoutComponent,
    canDeactivate: [ConfirmDeactivateGuard],
    resolve: {
      currencies: CurrencyResolver,
      issuers: IssuerResolver
    }
  },
  {
    path: ":id",
    component: DividendPayoutComponent,
    canDeactivate: [ConfirmDeactivateGuard],
    resolve: {
      currencies: CurrencyResolver,
      issuers: IssuerResolver
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DividendPayoutsRoutingRoutingModule {}
