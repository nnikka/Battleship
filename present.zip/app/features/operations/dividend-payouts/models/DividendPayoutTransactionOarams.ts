export interface DividendPayoutTransactionOarams {
  id: number;
  totalDividend: number;
  comment: string;
}
