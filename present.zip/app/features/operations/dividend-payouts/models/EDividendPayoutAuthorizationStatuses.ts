export enum EDividendPayoutAuthorizationStatuses {
  Unauthorized = 1,
  Authorized = 2
}

export enum EDividendPayoutAuthorizationStatusesColors {
  Unauthorized = "#ffc107",
  Authorized = "#00a3e0"
}

export enum EDividendPayoutTransactionAuthorizationStatuses {
  Unauthorized = 1,
  Authorized = 2
}
