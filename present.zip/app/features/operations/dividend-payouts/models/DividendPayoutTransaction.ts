export interface DividendPayoutTransaction {
  audit: {
    createDate: string;
    createUserFullName: string;
    createUserId: number;
    lastModifiedDate: string;
    lastModifiedUserFullName: string;
    lastModifiedUserId: number;
    status: number;
  };
  clientId: number;
  clientName: string;
  comment: null;
  dividendPayoutId: number;
  id: number;
  quantityOfShare: number;
  totalDividend: number;
  receivableDividend: number;
  transactionStatus: string;
  totalTax: number;
  clientCounterpartyId: number;
  clientCounterpartyName: string;
}
