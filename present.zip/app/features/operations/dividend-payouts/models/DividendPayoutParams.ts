export class DividendPayoutParams {
  stockId: number;
  paymentDate: string;
  exDividendDate: string;
  dividendPerShare: number;
  comment: string;
}
