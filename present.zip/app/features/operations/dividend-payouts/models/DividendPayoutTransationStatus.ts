export class DividendPayoutTransationStatus {
  static Pending: string = "Pending";
  static NotPaid: string = "Not paid";
  static Paid: string = "Paid";
  static Canceled: string = "Canceled";
}
