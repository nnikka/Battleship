export interface IListItemDividendPayout {
  createUserFullName: string;
  dividendPayoutBloombergName: string;
  dividendPayoutTicker: string;
  dividendPerShare: number;
  taxPerShare: number;
  exDividendDate: string;
  id: number;
  paymentDate: string;
  status: string;
  audit: {
    createDate: string;
    createUserFullName: string;
    createUserId: number;
    lastModifiedDate: string;
    lastModifiedUserFullName: string;
    lastModifiedUserId: number;
    status: number;
  };
}
