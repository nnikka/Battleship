import { DividendPayoutTransaction } from "./DividendPayoutTransaction";

export interface IHttpDividendPayout {
  id: number;
  audit: {
    createUserId: number;
    createUserFullName: string;
    lastModifiedUserId: number;
    lastModifiedUserFullName: string;
    createDate: string;
    lastModifiedDate: string;
    status: 1;
  };
  stockId: number;
  paymentDate: string;
  exDividendDate: string;
  dividendPerShare: number;
  comment: string;
  dividendPayoutTransactions: DividendPayoutTransaction[];
  currencyId: number;
  currencyName: string;
  taxPerShare: number;
  hasCashTransfer: boolean;
}
