import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { DividendTransactionsListComponent } from "./dividend-transactions-list.component";

describe("DividendTransactionsListComponent", () => {
  let component: DividendTransactionsListComponent;
  let fixture: ComponentFixture<DividendTransactionsListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DividendTransactionsListComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DividendTransactionsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
