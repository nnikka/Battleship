import { Component, OnInit, OnDestroy, Output, EventEmitter, Input, OnChanges } from "@angular/core";
import { GridDataResult } from "@progress/kendo-angular-grid";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { NotificationMessageService } from "@core/services/notification-message.service";
import { PopupConfirmService } from "@components/popup-confirm/popup-confirm.service";
import { MarkFormGroupTouched } from "src/utils/mark-formgroup-touched.helper";
import { DividendPayoutTransaction } from "../../models/DividendPayoutTransaction";
import { DividendPayoutService } from "../../services/dividend-payout.service";
import { AuthService } from "@auth/services/auth.service";
import {
  EDividendPayoutAuthorizationStatuses,
  EDividendPayoutAuthorizationStatusesColors,
  EDividendPayoutTransactionAuthorizationStatuses
} from "../../models/EDividendPayoutAuthorizationStatuses";
import { DividendPayoutTransationStatus } from "../../models/DividendPayoutTransationStatus";
import { IntlService } from "@progress/kendo-angular-intl";
import { deepCompareObjects } from "src/utils/compare-functions.helper";
import { untilDestroyed } from "ngx-take-until-destroy";

@Component({
  selector: "app-dividend-transactions-list",
  templateUrl: "./dividend-transactions-list.component.html",
  styleUrls: ["./dividend-transactions-list.component.scss"]
})
export class DividendTransactionsListComponent implements OnInit, OnDestroy, OnChanges {
  @Input() transactions: DividendPayoutTransaction[];
  @Input() dividendPayoutId: number;
  @Input() operationIsLoading: boolean = false;
  @Input() paymentDate: string;
  @Output() reloadData = new EventEmitter();

  notAuthorizedStatus: number = EDividendPayoutAuthorizationStatuses.Unauthorized;

  markAll: boolean = false;
  editIsOpen: boolean = false;

  selectedKeysBeforeUpdate = {};
  selectedKeys = {};

  editForm: FormGroup;
  editFormIsLoading: boolean = false;
  authorizationIsLoading: boolean = false;

  get gridView(): GridDataResult {
    return {
      data: this.transactions,
      total: this.transactions ? this.transactions.length : 0
    };
  }

  get updateIsDisabled(): boolean {
    return deepCompareObjects(this.selectedKeysBeforeUpdate, this.selectedKeys);
  }

  get executeTransactionsAreAvailable(): boolean {
    if (this.transactions && this.paymentDate) {
      const pattern = /(\d{2})\.(\d{2})\.(\d{4})/;
      const paymentDate = new Date(this.paymentDate.replace(pattern, "$3-$2-$1")).getTime();
      if (paymentDate > Date.now()) {
        return false;
      }
      for (const transaction of this.transactions) {
        if (
          (transaction.transactionStatus === "Pending" || transaction.transactionStatus === "Not paid") &&
          transaction.audit.status === EDividendPayoutTransactionAuthorizationStatuses.Authorized
        ) {
          return true;
        }
      }
      return false;
    }
    return false;
  }

  constructor(
    private formBuilder: FormBuilder,
    private notificationMessageService: NotificationMessageService,
    private popupConfirmService: PopupConfirmService,
    private dividendPayoutService: DividendPayoutService,
    private authService: AuthService,
    public intl: IntlService
  ) {}

  ngOnInit() {
    this.editForm = this.formBuilder.group({
      id: [{ disabled: true, value: null }, [Validators.required]],
      name: [{ disabled: true, value: null }, []],
      comment: [null, []],
      totalDividend: [null, [Validators.required, Validators.min(0.0001)]],
      receivableDividend: [null, [Validators.required, Validators.min(0.0001)]],
      totalTax: [null, [Validators.required, Validators.min(0)]]
    });
    this.generateAuthorizedKeys(this.transactions);
  }

  ngOnChanges(changes: import("@angular/core").SimpleChanges): void {
    this.generateAuthorizedKeys(this.transactions);
  }

  generateAuthorizedKeys(transactions: DividendPayoutTransaction[]) {
    if (transactions) {
      const res = {};
      transactions.map(tr => {
        if (
          tr.audit.status === EDividendPayoutAuthorizationStatuses.Authorized &&
          tr.transactionStatus === DividendPayoutTransationStatus.Pending
        ) {
          res[tr.id] = { value: true, disabled: false };
        } else if (
          tr.audit.status === EDividendPayoutAuthorizationStatuses.Authorized &&
          tr.transactionStatus !== DividendPayoutTransationStatus.Pending
        ) {
          res[tr.id] = {
            value: true,
            disabled: true,
            disableText: "You aren't allowed to deauthorize, the transaction is already committed"
          };
        } else if (
          tr.audit.status === EDividendPayoutAuthorizationStatuses.Unauthorized &&
          tr.audit.lastModifiedUserId !== parseInt(this.authService.getUserId(), 10)
        ) {
          res[tr.id] = { value: false, disabled: false };
        } else if (
          tr.audit.status === EDividendPayoutAuthorizationStatuses.Unauthorized &&
          tr.audit.lastModifiedUserId === parseInt(this.authService.getUserId(), 10)
        ) {
          res[tr.id] = {
            value: false,
            disabled: true,
            disableText: "You aren't allowed to authorize this transaction because last changes are made by you"
          };
        } else {
          res[tr.id] = {
            value: tr.audit.status === EDividendPayoutAuthorizationStatuses.Authorized,
            disabled: false
          };
        }
      });
      this.selectedKeysBeforeUpdate = JSON.parse(JSON.stringify(res));
      this.selectedKeys = JSON.parse(JSON.stringify(res));
    }
  }

  checkAllChanges($event) {
    Object.keys(this.selectedKeys).map(key => {
      if (!this.selectedKeys[key].disabled) {
        this.selectedKeys[key].value = $event;
      }
    });
  }

  generateAuthorizedArray(selectedKeys): number[] {
    const res: number[] = [];
    Object.keys(selectedKeys).map(key => {
      const selected = selectedKeys[key];
      if (selected.value) {
        res.push(parseInt(key, 10));
      }
    });
    return res;
  }

  handleAuthorizeTransactions() {
    this.popupConfirmService.show(null, null, () => {
      this.authorizationIsLoading = true;
      this.dividendPayoutService
        .changeAuthorizationStatusToDividendPayoutTransaction(
          this.dividendPayoutId,
          this.generateAuthorizedArray(this.selectedKeys)
        )
        .pipe(untilDestroyed(this))
        .subscribe(
          () => {
            this.authorizationIsLoading = false;
            this.reloadData.emit(true);
            this.notificationMessageService.success("Transactions has been updated successfully");
          },
          () => {
            this.authorizationIsLoading = false;
          }
        );
    });
  }

  handleEditDividendClick(dataItem) {
    this.editForm.get("id").setValue(dataItem.id);
    this.editForm.get("name").setValue(dataItem.clientName);
    this.editForm.get("comment").setValue(dataItem.comment);
    this.editForm.get("totalDividend").setValue(dataItem.totalDividend);
    this.editForm.get("receivableDividend").setValue(dataItem.receivableDividend);
    this.editForm.get("totalTax").setValue(dataItem.totalTax);
    this.editIsOpen = true;
  }

  handleUpdateTransaction() {
    if (!this.editForm.dirty) {
      this.notificationMessageService.info("Nothing is changed");
    } else {
      if (!this.editForm.valid) {
        MarkFormGroupTouched(this.editForm.controls);
        this.notificationMessageService.error(
          "Form is invalid, please make sure all required fields are filled out correctly"
        );
      } else {
        this.popupConfirmService.show(null, null, () => {
          this.editFormIsLoading = true;
          const trId = this.editForm.get("id").value;
          this.dividendPayoutService
            .updateDividendTransaction(trId, this.editForm.getRawValue())
            .pipe(untilDestroyed(this))
            .subscribe(
              () => {
                this.reloadData.emit(true);
                this.notificationMessageService.success("Transaction has been updated successfully");
                this.editFormIsLoading = false;
                this.closeEdit();
              },
              () => {
                this.editFormIsLoading = false;
              }
            );
        });
      }
    }
  }

  handleExecuteTransactions() {
    this.popupConfirmService.show(null, null, () => {
      this.authorizationIsLoading = true;
      this.dividendPayoutService
        .executeTransactions(this.dividendPayoutId)
        .pipe(untilDestroyed(this))
        .subscribe(
          () => {
            this.authorizationIsLoading = false;
            this.reloadData.emit(true);
            this.notificationMessageService.success("Transactions has been updated successfully");
          },
          () => {
            this.authorizationIsLoading = false;
          }
        );
    });
  }

  closeEdit() {
    this.editIsOpen = false;
    this.editForm.get("id").setValue(null);
    this.editForm.get("name").setValue(null);
    this.editForm.get("comment").setValue(null);
    this.editForm.get("receivableDividend").setValue(null);
    this.editForm.get("totalDividend").setValue(null);
    this.editForm.markAsPristine();
  }

  ngOnDestroy() {}

  authorizationStatusColor(status: string) {
    return EDividendPayoutAuthorizationStatusesColors[status];
  }

  transactionStatusColor(status: string) {
    if (status === "Not paid") {
      return "#fb311c";
    } else if (status === "Paid") {
      return "#28a745";
    } else if (status === "Pending") {
      return "#ffc107";
    } else {
      return "#6c757d";
    }
  }

  authorizationStatus(status) {
    return EDividendPayoutAuthorizationStatuses[status];
  }
}
