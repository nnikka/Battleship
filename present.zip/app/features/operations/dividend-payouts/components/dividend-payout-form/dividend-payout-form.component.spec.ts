import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { DividendPayoutFormComponent } from "./dividend-payout-form.component";

describe("DividendPayoutFormComponent", () => {
  let component: DividendPayoutFormComponent;
  let fixture: ComponentFixture<DividendPayoutFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DividendPayoutFormComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DividendPayoutFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
