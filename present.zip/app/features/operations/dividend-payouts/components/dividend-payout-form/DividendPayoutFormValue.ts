import { IHttpDividendPayout } from "../../models/IHttpDividendPayout";
import { convertToDMY } from "src/utils/date-converter.helper";

export class DividendPayoutFormValue {
  paymentDate: string;
  stockSearchType?: string;
  exDividendDate: string;
  stockId: number;
  dividendPerShare: number;
  comment: string;
  currencyId: number;
  taxPerShare: number;

  constructor(init?: IHttpDividendPayout) {
    if (init) {
      this.stockId = init.stockId;
      this.dividendPerShare = init.dividendPerShare;
      this.comment = init.comment;
      this.currencyId = init.currencyId;
      this.taxPerShare = init.taxPerShare;
      if (init.paymentDate) {
        this.paymentDate = convertToDMY(init.paymentDate).toLocaleDateString();
      }
      if (init.exDividendDate) {
        this.exDividendDate = convertToDMY(init.exDividendDate).toLocaleDateString();
      }
      // }
    }
  }
}
