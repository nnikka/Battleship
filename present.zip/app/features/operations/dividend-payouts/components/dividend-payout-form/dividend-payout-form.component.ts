import { Component, OnInit, Output, EventEmitter, Input, OnDestroy } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { EStockAuthorizationStatuses } from "@features/static-data/stocks/models/stockAuthorizationStatuses.enu";
import { DividendPayoutFormValidator } from "./helpers/dividend-payout-form.validator";
import { DividendPayoutFormValue } from "./DividendPayoutFormValue";
import { ICurrency } from "@core/models/catalogs/currency.interface";
import { constructSelectItemsFromArrayFrontAddition } from "src/utils/array.helper";
import { CustomDateValidators } from "src/app/general/validators/date.validator";
import { untilDestroyed } from "ngx-take-until-destroy";

@Component({
  selector: "app-dividend-payout-form",
  templateUrl: "./dividend-payout-form.component.html",
  styleUrls: ["./dividend-payout-form.component.scss"]
})
export class DividendPayoutFormComponent implements OnInit, OnDestroy {
  @Input() initialFormValue: DividendPayoutFormValue;
  @Input() currencies: ICurrency[];

  @Output() formReady = new EventEmitter<FormGroup>();

  form: FormGroup;
  currencyOptions: ICurrency[] = [];

  stocksByTickerSelectRequiredHttpParams = {
    "filterItem.status": EStockAuthorizationStatuses.Authorized,
    SortBy: "ticker",
    SortDirection: 0
  };
  stocksByBloombergSelectRequiredHttpParams = {
    "filterItem.status": EStockAuthorizationStatuses.Authorized,
    SortBy: "bloombergName",
    SortDirection: 0
  };

  constructor(private formBuilder: FormBuilder) {}

  ngOnInit() {
    this.currencyOptions = constructSelectItemsFromArrayFrontAddition(this.currencies, { id: null, name: "" });
    this.form = this.formBuilder.group(
      {
        paymentDate: [
          this.initialFormValue ? this.initialFormValue.paymentDate : null,
          [Validators.required, CustomDateValidators.minimumDateByDays(60)]
        ],
        stockSearchType: ["ticker", []],
        exDividendDate: [this.initialFormValue ? this.initialFormValue.exDividendDate : null, []],
        stockId: [this.initialFormValue ? this.initialFormValue.stockId : null, [Validators.required]],
        dividendPerShare: [
          this.initialFormValue ? this.initialFormValue.dividendPerShare : null,
          [Validators.required, Validators.min(0.0001)]
        ],
        currencyId: [this.initialFormValue ? this.initialFormValue.currencyId : null, []],
        taxPerShare: [this.initialFormValue ? this.initialFormValue.taxPerShare : 0, [Validators.min(0)]],
        comment: [this.initialFormValue ? this.initialFormValue.comment : null, []]
      },
      { validators: DividendPayoutFormValidator() }
    );

    this.form
      .get("stockSearchType")
      .valueChanges.pipe(untilDestroyed(this))
      .subscribe(() => {
        this.form.get("stockId").setValue(null);
      });

    this.formReady.emit(this.form);
  }

  ngOnDestroy(): void {}
}
