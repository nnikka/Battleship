import { FormGroup } from "@angular/forms";

export function DividendPayoutFormValidator() {
  return (formGroup: FormGroup) => {
    // Dates validation
    const paymentDateControl = formGroup.get("paymentDate");
    const exDividendDateControl = formGroup.get("exDividendDate");

    let paymentTime = null;
    let exDividendTime = null;

    if (paymentDateControl.value) { paymentTime = new Date(paymentDateControl.value).getTime(); }
    if (exDividendDateControl.value) { exDividendTime = new Date(exDividendDateControl.value).getTime(); }

    if (paymentTime && exDividendTime && paymentTime < exDividendTime) {
      paymentDateControl.setErrors({ paymentDateMustBeMoreOrEquallThenexDividendDate: true });
    } else if (paymentTime && exDividendTime && !(paymentTime < exDividendTime)) {
      paymentDateControl.setErrors(null);
    }
  };
}
