import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { DividendPayoutCardComponent } from "./dividend-payout-card.component";

describe("DividendPayoutCardComponent", () => {
  let component: DividendPayoutCardComponent;
  let fixture: ComponentFixture<DividendPayoutCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DividendPayoutCardComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DividendPayoutCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
