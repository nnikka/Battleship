import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { IHttpDividendPayout } from "../../models/IHttpDividendPayout";
import { DividendPayoutTransaction } from "../../models/DividendPayoutTransaction";
import { IntlService } from "@progress/kendo-angular-intl";
import { IHttpStock } from "@features/static-data/stocks/models/IHttpStock";

@Component({
  selector: "app-dividend-payout-card",
  templateUrl: "./dividend-payout-card.component.html",
  styleUrls: ["./dividend-payout-card.component.scss"]
})
export class DividendPayoutCardComponent implements OnInit {
  @Input() dividendPayoutData: IHttpDividendPayout;
  @Input() stock: IHttpStock;

  @Output() reloadData = new EventEmitter();

  get dividentPayoutTransactions(): DividendPayoutTransaction[] {
    return this.dividendPayoutData ? this.dividendPayoutData.dividendPayoutTransactions : null;
  }

  constructor(public intl: IntlService) {}

  onReloadData(e) {
    this.reloadData.emit(e);
  }

  ngOnInit() {}
}
