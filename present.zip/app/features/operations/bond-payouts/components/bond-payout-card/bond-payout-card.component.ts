import { Component, OnInit, Input, ChangeDetectionStrategy, OnChanges, SimpleChanges } from "@angular/core";
import { IHttpBondPayoutOperation } from "../../models/IHttpBondPayoutOperation";
import { EBondPayoutOperationTypeText } from "../../models/EBondPayoutOperationType";

@Component({
  selector: "app-bond-payout-card",
  templateUrl: "./bond-payout-card.component.html",
  styleUrls: ["./bond-payout-card.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class BondPayoutCardComponent implements OnInit, OnChanges {
  @Input() bondPayoutOperationData: IHttpBondPayoutOperation;

  operationTypeName: string = null;

  constructor() { }

  ngOnInit() { }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.bondPayoutOperationData.currentValue) {
      this.operationTypeName =
        EBondPayoutOperationTypeText[changes.bondPayoutOperationData.currentValue.operationTypeName];
    }
  }
}
