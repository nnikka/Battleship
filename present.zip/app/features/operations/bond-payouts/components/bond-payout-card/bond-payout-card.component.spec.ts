import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { BondPayoutCardComponent } from "./bond-payout-card.component";

describe("BondPayoutCardComponent", () => {
  let component: BondPayoutCardComponent;
  let fixture: ComponentFixture<BondPayoutCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BondPayoutCardComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BondPayoutCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
