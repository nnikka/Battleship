import { Component, OnInit, Input, ChangeDetectionStrategy, OnChanges, Output, EventEmitter } from "@angular/core";
import { IOperationTransaction } from "@core/models/IOperationTransaction";
import { ETransactionStatusColor, ETransactionStatus } from "@core/models/enums/ETransactionStatus";
import { IntlService } from "@progress/kendo-angular-intl";
import { IBondPayoutTransaction } from "../../models/IBondPayoutTransaction";
import { deepCompareObjects } from "src/utils/compare-functions.helper";
import { EOperationStatus } from "@core/models/enums/EOperationStatus";

@Component({
  selector: "app-bond-payout-transactions-list",
  templateUrl: "./bond-payout-transactions-list.component.html",
  styleUrls: ["./bond-payout-transactions-list.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class BondPayoutTransactionsListComponent implements OnInit, OnChanges {
  @Input() operationTransactions: IBondPayoutTransaction[];
  @Input() transactionsIsLoading: boolean;
  @Input() isExecutionOfTransactionsAvailable: boolean;
  @Input() hasWithHoldingTax: boolean;
  @Input() operationStatus: number;
  @Output() executeTransactions = new EventEmitter();
  @Output() updateTransactions = new EventEmitter<number[]>();

  markAll: boolean = false;
  selectedKeysBeforeUpdate = {};
  selectedKeys = {};

  get updateTransactionsIsDisabled(): boolean {
    return deepCompareObjects(this.selectedKeysBeforeUpdate, this.selectedKeys);
  }

  get updateTransactionsAreAvailable(): boolean {
    return (
      this.operationStatus &&
      this.hasWithHoldingTax &&
      (this.operationStatus === EOperationStatus.Pending || this.operationStatus === EOperationStatus.Fail)
    );
  }

  get debitAmountSum(): number {
    let res = 0;
    if (this.operationTransactions) {
      for (const tr of this.operationTransactions) {
        if (tr.debitAmount) {
          res += tr.debitAmount;
        }
      }
    }
    return res;
  }

  get whTaxSum(): number {
    let res = 0;
    if (this.operationTransactions) {
      for (const tr of this.operationTransactions) {
        if (tr.withholdingTaxAmount) {
          res += tr.withholdingTaxAmount;
        }
      }
    }
    return res;
  }

  get issuerSum(): number {
    return this.whTaxSum + this.debitAmountSum;
  }

  get currencyName(): string {
    if (this.operationTransactions && this.operationTransactions[0]) {
      return this.operationTransactions[0].currencyName;
    }
    return null;
  }

  constructor(public intl: IntlService) {}

  ngOnInit() {
    this.generateTransactionKeys(this.operationTransactions);
  }

  ngOnChanges(changes: import("@angular/core").SimpleChanges): void {
    this.generateTransactionKeys(this.operationTransactions);
  }

  generateTransactionKeys(transactions: IBondPayoutTransaction[]) {
    if (transactions) {
      const res = {};
      for (const tr of transactions) {
        if (!tr.creditAmount) {
          res[tr.clientId] = {
            value: tr.hasWithholdingTax
          };
        }
      }
      // pointer issue
      this.selectedKeys = JSON.parse(JSON.stringify(res));
      this.selectedKeysBeforeUpdate = JSON.parse(JSON.stringify(res));
    }
  }

  checkAllChanges($event) {
    Object.keys(this.selectedKeys).map(key => {
      this.selectedKeys[key].value = $event;
    });
  }

  transactionStatusColor(status: string): string {
    return status ? ETransactionStatusColor[status] : null;
  }

  executionDateIsNotAvailable(transaction: IOperationTransaction) {
    return transaction && ETransactionStatus[transaction.transactionStatus] === ETransactionStatus.Pending;
  }

  handleExecuteTransactions() {
    this.executeTransactions.emit();
  }

  handleUpdateTransactions() {
    const res: number[] = [];
    Object.keys(this.selectedKeys).map(key => {
      const selected = this.selectedKeys[key];
      if (selected.value) {
        res.push(parseInt(key, 10));
      }
    });
    this.updateTransactions.emit(res);
  }
}
