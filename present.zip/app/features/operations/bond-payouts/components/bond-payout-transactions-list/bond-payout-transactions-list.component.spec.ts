import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { BondPayoutTransactionsListComponent } from "./bond-payout-transactions-list.component";

describe("BondPayoutTransactionsListComponent", () => {
  let component: BondPayoutTransactionsListComponent;
  let fixture: ComponentFixture<BondPayoutTransactionsListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BondPayoutTransactionsListComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BondPayoutTransactionsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
