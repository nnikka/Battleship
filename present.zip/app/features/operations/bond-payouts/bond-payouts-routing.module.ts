import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { BondPayoutComponent } from "./containers/bond-payout/bond-payout.component";
import { BondPayoutsListComponent } from "./containers/bond-payouts-list/bond-payouts-list.component";

const routes: Routes = [
  {
    path: "",
    component: BondPayoutsListComponent
  },
  {
    path: ":id",
    component: BondPayoutComponent,
    canDeactivate: [],
    resolve: {}
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BondPayoutsRoutingRoutingModule {}
