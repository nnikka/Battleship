import { Component, OnInit, OnDestroy } from "@angular/core";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import { ActivatedRoute, Router } from "@angular/router";
import { PopupConfirmService } from "@components/popup-confirm/popup-confirm.service";
import { BondPayoutService } from "../../services/bond-payout.service";
import { IHttpBondPayoutOperation } from "../../models/IHttpBondPayoutOperation";
import {
  EBondPayoutOperationAuthorizationStatusesColors,
  EBondPayoutOperationAuthorizationStatuses
} from "../../models/EBondPayoutOperationAuthorizationStatuses";
import { EOperationStatus, EOperationStatusColor } from "@core/models/enums/EOperationStatus";
import { NotificationMessageService } from "@core/services/notification-message.service";
import { OperationService, EOperationType } from "@core/services/operation.service";
import { untilDestroyed } from "ngx-take-until-destroy";

@Component({
  selector: "app-bond-payout",
  templateUrl: "./bond-payout.component.html",
  styleUrls: ["./bond-payout.component.scss"]
})
export class BondPayoutComponent implements OnInit, OnDestroy {
  breadcrumbItems: IBreadcrumb[] = [
    { text: "Operations", to: null },
    { text: "Bond payouts", to: "/admin/operations/bond-payouts" },
    { text: "Bond payout", to: null }
  ];

  bondPayoutOperationId: string;
  loading: boolean = true;
  authorizationIsDisabled: boolean = false;
  formIsUpdatedSuccessfully: boolean = false;
  transactionsIsLoading: boolean = false;
  bondPayoutOperationData: IHttpBondPayoutOperation;

  get canDeauthorize(): boolean {
    if (this.bondPayoutOperationData && this.bondPayoutOperationData.operationStatus === EOperationStatus.Success) {
      return false;
    }
    return true;
  }

  get bondPayoutOperationAuthorizationStatus() {
    return this.bondPayoutOperationData
      ? EBondPayoutOperationAuthorizationStatuses[this.bondPayoutOperationData.status]
      : null;
  }

  get operationStatus(): string {
    if (this.bondPayoutOperationData) {
      return EOperationStatus[this.bondPayoutOperationData.operationStatus];
    }
    return null;
  }

  get isOperationSucceed() {
    return this.bondPayoutOperationData && this.bondPayoutOperationData.operationStatus === EOperationStatus.Success;
  }

  get isOperationCanceled(): boolean {
    if (this.bondPayoutOperationData) {
      return this.bondPayoutOperationData.operationStatus === EOperationStatus.Canceled;
    }
    return false;
  }

  get isExecutionOfTransactionsAvailable(): boolean {
    if (
      this.bondPayoutOperationData &&
      this.bondPayoutOperationData.operationStatus !== EOperationStatus.Success &&
      this.bondPayoutOperationData.operationStatus !== EOperationStatus.Canceled &&
      this.bondPayoutOperationData.status === "Authorized"
    ) {
      const pattern = /(\d{2})\.(\d{2})\.(\d{4})/;
      const settlementDate = new Date(
        this.bondPayoutOperationData.settlementDate.replace(pattern, "$3-$2-$1")
      ).getTime();
      if (
        settlementDate <= Date.now() &&
        this.bondPayoutOperationData.operationTransactions &&
        this.bondPayoutOperationData.operationTransactions.length > 0
      ) {
        return true;
      }
    }
    return false;
  }

  get isGenerateTransactionsAvailable(): boolean {
    if (
      this.bondPayoutOperationData &&
      this.bondPayoutOperationData.operationStatus !== EOperationStatus.Success &&
      this.bondPayoutOperationData.operationStatus !== EOperationStatus.Canceled &&
      this.bondPayoutOperationData.status === "Authorized"
    ) {
      const pattern = /(\d{2})\.(\d{2})\.(\d{4})/;
      const settlementDate = new Date(
        this.bondPayoutOperationData.settlementDate.replace(pattern, "$3-$2-$1")
      ).getTime();
      if (settlementDate <= Date.now()) {
        return true;
      }
    }
    return false;
  }

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private notificationMessageService: NotificationMessageService,
    private popupConfirmService: PopupConfirmService,
    private bondPayoutService: BondPayoutService,
    private operationService: OperationService
  ) {}

  ngOnInit() {
    this.route.paramMap.pipe(untilDestroyed(this)).subscribe(paramsAsMap => {
      this.bondPayoutOperationId = paramsAsMap.get("id");
      this.loadBondPayoutOperation(this.bondPayoutOperationId);
    });
  }

  loadBondPayoutOperation(id) {
    this.loading = true;
    this.bondPayoutService
      .getById(id)
      .pipe(untilDestroyed(this))
      .subscribe(
        bondOperation => {
          this.bondPayoutOperationData = bondOperation;
          this.loading = false;
          this.transactionsIsLoading = false;
        },
        err => {
          this.router.navigateByUrl("/not-found", { replaceUrl: true });
        }
      );
  }

  handleWithdraw() {
    this.popupConfirmService.show(null, null, () => {
      this.loading = true;
      this.bondPayoutService
        .CreateCashWithdrawalOperation(this.bondPayoutOperationId)
        .pipe(untilDestroyed(this))
        .subscribe(
          cashWithrawId => {
            this.loading = false;
            this.notificationMessageService.success("Cash Withdrawal added successfully");
            this.router.navigateByUrl("/admin/operations/cash/" + cashWithrawId);
          },
          err => {
            this.loading = false;
          }
        );
    });
  }

  handleViewWithdrawalOperation() {
    this.router.navigateByUrl("/admin/operations/cash/" + this.bondPayoutOperationData.cashWithrawalOperationId);
  }

  handleChangeAuthorize(status: string, message: string) {
    this.popupConfirmService.show(null, null, () => {
      this.authorizationIsDisabled = true;
      this.loading = true;
      this.bondPayoutService
        .changeAuthorizationStatus(this.bondPayoutOperationId, EBondPayoutOperationAuthorizationStatuses[status])
        .pipe(untilDestroyed(this))
        .subscribe(
          () => {
            this.authorizationIsDisabled = false;
            this.loading = false;
            this.loadBondPayoutOperation(this.bondPayoutOperationId);
            this.notificationMessageService.success(message);
          },
          () => {
            this.authorizationIsDisabled = false;
            this.loading = false;
          }
        );
    });
  }

  handleGenerateTransactions() {
    this.popupConfirmService.show(null, null, () => {
      this.transactionsIsLoading = true;
      this.bondPayoutService.generateTransactions(this.bondPayoutOperationId).subscribe(
        resp => {
          this.notificationMessageService.success("Transactions has been generated successfully");
          this.loadBondPayoutOperation(this.bondPayoutOperationId);
        },
        err => {
          this.transactionsIsLoading = false;
          this.notificationMessageService.success("Something went wrong");
        }
      );
    });
  }

  handleExecuteTransactions() {
    this.popupConfirmService.show(null, null, () => {
      this.loading = true;
      this.transactionsIsLoading = true;
      this.operationService
        .makeOperationTransactions(this.bondPayoutOperationId, EOperationType.BondPayout)
        .pipe(untilDestroyed(this))
        .subscribe(
          () => {
            this.notificationMessageService.success("Transaction has been executed successfully");
            this.loadBondPayoutOperation(this.bondPayoutOperationId);
          },
          () => {
            this.notificationMessageService.error("Something went wrong");
            this.loadBondPayoutOperation(this.bondPayoutOperationId);
          }
        );
    });
  }

  handleUpdateTransactions(arr) {
    this.popupConfirmService.show(null, null, () => {
      this.loading = true;
      this.transactionsIsLoading = true;
      this.bondPayoutService
        .updateTransactions(this.bondPayoutOperationId, arr)
        .pipe(untilDestroyed(this))
        .subscribe(
          () => {
            this.notificationMessageService.success("Transactions has been updated successfully");
            this.loadBondPayoutOperation(this.bondPayoutOperationId);
          },
          () => {
            this.notificationMessageService.error("Something went wrong");
            this.loading = false;
            this.transactionsIsLoading = false;
          }
        );
    });
  }

  authorizationStatusColor(status: string): string {
    return status ? EBondPayoutOperationAuthorizationStatusesColors[status] : null;
  }

  operationStatusColor(status: string): string {
    return status ? EOperationStatusColor[status] : null;
  }

  ngOnDestroy() {}
}
