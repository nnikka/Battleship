import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { BondPayoutComponent } from "./bond-payout.component";

describe("BondPayoutComponent", () => {
  let component: BondPayoutComponent;
  let fixture: ComponentFixture<BondPayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BondPayoutComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BondPayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
