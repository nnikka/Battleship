import { Component, OnInit, OnDestroy } from "@angular/core";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import { IntlService, formatDate } from "@progress/kendo-angular-intl";
import { constructSelectItemsFromEnum } from "src/utils/array.helper";
import { EBondPayoutOperationType, EBondPayoutOperationTypeText } from "../../models/EBondPayoutOperationType";
import { EOperationStatus, EOperationStatusColor } from "@core/models/enums/EOperationStatus";
import {
  EBondPayoutOperationAuthorizationStatuses,
  EBondPayoutOperationAuthorizationStatusesColors
} from "../../models/EBondPayoutOperationAuthorizationStatuses";
import { IColumn } from "@shared/components/complex-grid/interfaces/IColumn";
import { IOptions } from "@shared/components/complex-grid/interfaces/IOptions";
import {
  EBondOperationAuthorizationStatusesColors
} from "@features/operations/bond-operations/models/EBondOperationAuthorizationStatuses";
import { BondPayoutService } from "../../services/bond-payout.service";
import { FileDownloadService } from "@core/services/file-download.service";
import { untilDestroyed } from "ngx-take-until-destroy";

@Component({
  selector: "app-bond-payouts-list",
  templateUrl: "./bond-payouts-list.component.html",
  styleUrls: ["./bond-payouts-list.component.scss"]
})
export class BondPayoutsListComponent implements OnInit, OnDestroy {
  breadcrumbItems: IBreadcrumb[] = [
    { text: "Operations", to: null },
    { text: "Bond payouts", to: null }
  ];

  bondPayoutOperationAuthorizationStatuses: { key: string; value: number }[];
  bondPayoutOperationTypes: { key: string; value: number }[];
  bondPayoutOperationStatuses: { key: string; value: number }[];

  columns: IColumn[];
  options: IOptions = {
    tableKey: "BondPayoutsList",
    columnsTooboxEnable: true,
    dblClickEnable: true
  };

  excelIsDownloading: boolean = false;

  constructor(
    public intl: IntlService,
    private bondPayoutService: BondPayoutService,
    private fileDownloadService: FileDownloadService) { }

  ngOnInit() {
    this.bondPayoutOperationTypes = this.constructBondPayoutOperationTypeOptions();
    this.bondPayoutOperationStatuses = constructSelectItemsFromEnum(EOperationStatus);
    this.bondPayoutOperationAuthorizationStatuses = constructSelectItemsFromEnum(
      EBondPayoutOperationAuthorizationStatuses
    );
    this.columns = [
      {
        key: "id",
        name: "ID",
        type: "number",
        filterConfig: {
          filterType: "number"
        }
      },
      {
        key: "operationStatus",
        name: "Operation status",
        type: "string",
        style: {
          colorsMapping: EOperationStatusColor,
          conditionalColor: true
        },
        filterConfig: {
          filterData: this.bondPayoutOperationStatuses,
          filterType: "dropdown"
        }
      },
      {
        key: "bondName",
        name: "Bond name",
        type: "string",
        filterConfig: {
          filterType: "string"
        }
      },
      {
        key: "operationType",
        name: "Operation type",
        type: "string",
        filterConfig: {
          filterData: this.bondPayoutOperationTypes,
          filterType: "dropdown"
        }
      },
      {
        key: "settlementDate",
        name: "Settlement date",
        type: "date",
        filterConfig: {
          filterType: "date"
        }
      },
      {
        key: "status",
        name: "Authorization status",
        type: "string",
        style: {
          colorsMapping: EBondOperationAuthorizationStatusesColors,
          conditionalColor: true,
          isCard: true
        },
        filterConfig: {
          filterData: this.bondPayoutOperationAuthorizationStatuses,
          filterType: "dropdown"
        }
      }
    ];
  }

  exportExcel() {
    this.excelIsDownloading = true;
    this.bondPayoutService
      .exportExcel()
      .pipe(untilDestroyed(this))
      .subscribe(response => {
        this.fileDownloadService.downLoadFile(
          `${formatDate(new Date(), "dd-MM-yyyy HH:mm:ss")} Bond Payouts.xlsx`,
          response
        );
        this.excelIsDownloading = false;
      });
  }

  constructBondPayoutOperationTypeOptions() {
    const result = [];
    result.push({ name: "All", value: null });
    Object.keys(EBondPayoutOperationType).map(key => {
      if (!(parseInt(key, 10) >= 0)) {
        const obj = { name: "", value: "" };
        obj.name = EBondPayoutOperationTypeText[key];
        obj.value = EBondPayoutOperationType[key];
        result.push(obj);
      }
    });
    return result;
  }

  authorizationStatusColor(status: string) {
    return EBondPayoutOperationAuthorizationStatusesColors[status];
  }

  operationStatusColor(status: string): string {
    return status ? EOperationStatusColor[status] : null;
  }

  operationTypeText(status: string): string {
    return status ? EBondPayoutOperationTypeText[status] : null;
  }

  ngOnDestroy(): void { }
}
