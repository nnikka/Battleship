import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { BondPayoutsListComponent } from "./bond-payouts-list.component";

describe("BondPayoutsListComponent", () => {
  let component: BondPayoutsListComponent;
  let fixture: ComponentFixture<BondPayoutsListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BondPayoutsListComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BondPayoutsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
