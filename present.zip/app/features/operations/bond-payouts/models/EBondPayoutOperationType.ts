export enum EBondPayoutOperationType {
  CouponPayment = 1,
  FaceAmountPayment = 2
}

export enum EBondPayoutOperationTypeText {
  CouponPayment = "Coupon payment",
  FaceAmountPayment = "Face amount payment"
}
