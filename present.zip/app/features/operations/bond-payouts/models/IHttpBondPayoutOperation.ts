export interface IHttpBondPayoutOperation {
  bondId: number;
  bondName: string;
  id: number;
  operationStatus: number;
  operationStatusName: string;
  operationTransactions: Array<any>;
  operationType: number;
  operationTypeName: string;
  settlementDate: string;
  status: string;
  cashWithrawalOperationId: number;
  hasWithholdingTax: boolean;
}
