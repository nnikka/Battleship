export interface IBondPayoutTransaction {
  id: number;
  assetTypeName: string;
  audit: {
    createDate: string;
    createUserFullName: string;
    createUserId: number;
    lastModifiedDate: string;
    lastModifiedUserFullName: string;
    lastModifiedUserId: number;
    status: number;
  };
  clientName: string;
  clientId: number;
  comment: string;
  creditAmount: number;
  debitAmount: number;
  operationTypeName: string;
  productName: string;
  transactionDate: string;
  transactionStatus: string;
  transactionTypeName: string;
  currencyName: string;
  transactionStatusMessage: string;
  hasWithholdingTax: boolean;
  withholdingTaxAmount: number;
}
