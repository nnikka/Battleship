export enum EBondPayoutOperationAuthorizationStatuses {
  Unauthorized = 1,
  Authorized = 2
}

export enum EBondPayoutOperationAuthorizationStatusesColors {
  Unauthorized = "#ffc107",
  Authorized = "#00a3e0"
}
