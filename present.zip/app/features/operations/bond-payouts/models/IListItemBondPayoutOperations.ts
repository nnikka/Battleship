export interface IListItemBondPayoutOperations {
  bondId: number;
  bondName: string;
  id: number;
  operationStatus: string;
  operationType: string;
  settlementDate: string;
  status: string;
}
