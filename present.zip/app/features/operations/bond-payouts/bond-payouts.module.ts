import { NgModule } from "@angular/core";
import { BondPayoutsListComponent } from "./containers/bond-payouts-list/bond-payouts-list.component";
import { BondPayoutComponent } from "./containers/bond-payout/bond-payout.component";

import { SharedModule } from "@shared/shared.module";
import { BondPayoutsRoutingRoutingModule } from "./bond-payouts-routing.module";

import { BondPayoutService } from "./services/bond-payout.service";
import { BondPayoutCardComponent } from "./components/bond-payout-card/bond-payout-card.component";
import {
  BondPayoutTransactionsListComponent
} from "./components/bond-payout-transactions-list/bond-payout-transactions-list.component";

@NgModule({
  declarations: [
    BondPayoutsListComponent,
    BondPayoutComponent,
    BondPayoutCardComponent,
    BondPayoutTransactionsListComponent
  ],
  imports: [BondPayoutsRoutingRoutingModule, SharedModule],
  providers: [BondPayoutService]
})
export class BondPayoutsModule { }
