import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { ConfigService } from "@env/service/config.service";
import { IHttpPagingQueryParams } from "@shared/models/IHttpPagingQueryParams";
import { IPagingHttpResponse } from "@shared/models/IPagingHttpResponse";
import { IListItemBondPayoutOperations } from "../models/IListItemBondPayoutOperations";
import { IHttpBondPayoutOperation } from "../models/IHttpBondPayoutOperation";

@Injectable()
export class BondPayoutService {
  constructor(private http: HttpClient, private configService: ConfigService) { }

  getAll(queryParams: IHttpPagingQueryParams): Observable<IPagingHttpResponse<IListItemBondPayoutOperations>> {
    const params = queryParams as any;
    return this.http.get<IPagingHttpResponse<IListItemBondPayoutOperations>>(
      `${this.configService.config.apiBaseurl}/api/BondPayoutOperations`,
      {
        params
      }
    );
  }

  getById(id: string): Observable<IHttpBondPayoutOperation> {
    return this.http.get<IHttpBondPayoutOperation>(
      `${this.configService.config.apiBaseurl}/api/BondPayoutOperations/${id}`
    );
  }

  changeAuthorizationStatus(id: string, status: number): Observable<any> {
    return this.http.put(
      `${this.configService.config.apiBaseurl}/api/BondPayoutOperations/ChangeAuthorizationStatus/${id}/${status}`,
      {}
    );
  }

  CreateCashWithdrawalOperation(bondPayoutOperationId) {
    return this.http.post(
      `${this.configService.config.apiBaseurl}/api/BondPayoutOperations/CreateCashWithdrawalOperation`,
      {},
      { params: { bondPayoutOperationId } }
    );
  }

  generateTransactions(bondPayoutOperationId): Observable<any> {
    return this.http.post(
      `${this.configService.config.apiBaseurl}/api/BondPayoutOperations/GenerateBondPayoutTransactions`,
      {},
      { params: { bondPayoutOperationId } }
    );
  }

  updateTransactions(bondPayoutOperationId, arrNum): Observable<any> {
    return this.http.put(
      // tslint:disable-next-line: max-line-length
      `${this.configService.config.apiBaseurl}/api/BondPayoutOperations/UpdateWithholdingTaxPayableClients/${bondPayoutOperationId}`,
      arrNum
    );
  }

  exportExcel(): Observable<any> {
    return this.http.get(
      `${this.configService.config.apiBaseurl}/api/BondPayoutOperations/ExportBondPayoutOperationsWithTransaction`,
      {
        responseType: "blob"
      }
    );
  }
}
