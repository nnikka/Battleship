import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { ConfigService } from "@env/service/config.service";
import { BondParams } from "@features/static-data/bonds/models/BondParams";
import { Observable } from "rxjs";
import { IOperationCorrectionType } from "../interfaces/operation-correction-type.interface";

@Injectable()
export class PledgeOperationService {

  constructor(private http: HttpClient, private configService: ConfigService) { }

  create(formData): Observable<any> {
    return this.http.post(`${this.configService.config.apiBaseurl}/api/PledgeOperations`, formData);
  }

  getAll(): Observable<any> {
    return this.http.get(`${this.configService.config.apiBaseurl}/api/PledgeOperations`, {});
  }

  getById(id): Observable<any> {
    return this.http.get(`${this.configService.config.apiBaseurl}/api/PledgeOperations/${id}`, {});
  }

  update(id: string, formData): Observable<any> {
    formData.id = id;
    return this.http.put(`${this.configService.config.apiBaseurl}/api/PledgeOperations/${id}`, formData);
  }

  correctPledgeOperation({
    parentOperationId,
    amount,
    balanceCorrectionStartDate,
    endDate,
  }: IOperationCorrectionType): Observable<any> {
    let params = `parentOperationId=${parentOperationId}`;
    if (amount) {
      params += `&amount=${amount}`;
      params += `&balanceCorrectionStartDate=${balanceCorrectionStartDate}`;
    }
    if (endDate) {
      params += `&endDate=${endDate}`;
    }

    return this.http.post(
      `${this.configService.config.apiBaseurl}/api/PledgeOperations/CorrectPledgeOperation?` + params,
      {}
    );
  }

  getBondById(id) {
    return this.http.get(`${this.configService.config.apiBaseurl}/api/bonds/${id}`, {});
  }
  getStockById(id) {
    return this.http.get(`${this.configService.config.apiBaseurl}/api/stocks/${id}`, {});
  }

  getClientBalances(id: number | string): Observable<any> {
    return this.http.get(`${this.configService.config.apiBaseurl}/api/Clients/GetClientBalances/${id}`);
  }

  deletePledgeOperation(id: number | string): Observable<any> {
    return this.http.delete(`${this.configService.config.apiBaseurl}/api/PledgeOperations/${id}`);
  }



  changePledgeOperationStatus(id, status) {
    return this.http.put(
      `${
      this
        .configService
        .config
        .apiBaseurl}/api/PledgeOperations/RollbackPledgeOperation?parentOperationId=${id}&operationStatus=${status}`,
      {});
  }
  changeAuthorizationStatus(id: string, status: number): Observable<any> {
    return this.http.put(
      `${this.configService.config.apiBaseurl}/api/PledgeOperations/ChangeAuthorizationStatus/${id}/${status}`,
      {}
    );
  }
}
