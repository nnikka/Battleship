import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { PledgeOperationsRoutingModule } from "./pledge-operations-routing.module";
import { PledgeOperationCardComponent } from "./components/pledge-operation-card/pledge-operation-card.component";
import { PledgeOperationFormComponent } from "./components/pledge-operation-form/pledge-operation-form.component";
import { PledgeOperationComponent } from "./containers/pledge-operation/pledge-operation.component";
import { PledgeOperationAddComponent } from "./containers/pledge-operation-add/pledge-operation-add.component";
import { PledgeOperationsListComponent } from "./containers/pledge-operations-list/pledge-operations-list.component";
import { SharedModule } from "@shared/shared.module";
import { PledgeOperationService } from "./services/pledge-operation.service";
import { BalancesCardComponent } from "./components/balances-card/balances-card.component";
import { CorrectionListComponent } from './components/correction-list/correction-list.component';


@NgModule({
  declarations: [
    PledgeOperationCardComponent,
    PledgeOperationFormComponent,
    PledgeOperationComponent,
    PledgeOperationAddComponent,
    PledgeOperationsListComponent,
    BalancesCardComponent,
    CorrectionListComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    PledgeOperationsRoutingModule
  ],
  providers: [
    PledgeOperationService
  ]
})
export class PledgeOperationsModule { }
