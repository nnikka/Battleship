import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PledgeOperationsListComponent } from './pledge-operations-list.component';

describe('PledgeOperationsListComponent', () => {
  let component: PledgeOperationsListComponent;
  let fixture: ComponentFixture<PledgeOperationsListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PledgeOperationsListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PledgeOperationsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
