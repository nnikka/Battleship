import { Component, OnInit, OnDestroy } from "@angular/core";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import { IColumn } from "@shared/components/complex-grid/interfaces/IColumn";
import { IOptions } from "@shared/components/complex-grid/interfaces/IOptions";
import { Router } from "@angular/router";
import { constructSelectItemsFromEnum, constructSelectItemsFromArray } from "src/utils/array.helper";
import { EOperationStatus, EOperationStatusColor } from "@core/models/enums/EOperationStatus";
import { select, Store } from "@ngrx/store";
import { selectCurrencies, selectCurrencyLoadStatus } from "@core/store/currency/currency.selector";
import { IAppState } from "@core/store/app.state";
import { untilDestroyed } from "ngx-take-until-destroy";
import {
  EPledgeOperationAuthorizationStatusesColors,
  EPledgeOperationAuthorizationStatuses
} from "../../enums/EPledgeOperationAuthorizationStatuses.enum";
import {
  selectAuthorizedCounterParties,
  selectCounterPartyLoadStatus
} from "@core/store/counterParty/counterParty.selector";
import { zip } from "rxjs";
import { map } from "rxjs/operators";
import { EProductType } from "../../enums/product-type.enum";

@Component({
  selector: "app-pledge-operations-list",
  templateUrl: "./pledge-operations-list.component.html",
  styleUrls: ["./pledge-operations-list.component.scss"]
})
export class PledgeOperationsListComponent implements OnInit, OnDestroy {


  breadcrumbItems: IBreadcrumb[] = [
    { text: "Operations", to: null },
    { text: "Pledge", to: "/admin/operations/pledge" }
  ];

  currencies$ = this.store.pipe(select(selectCurrencies));
  currenciesLoaded = this.store.pipe(select(selectCurrencyLoadStatus));

  counterParties$ = this.store.pipe(select(selectAuthorizedCounterParties));
  counterPartiesLoaded$ = this.store.pipe(select(selectCounterPartyLoadStatus));

  currencies;
  counterParties;
  pledgeOperationProductTypes;

  columns: IColumn[] = [];
  options: IOptions = {
    tableKey: "PledgeOperationsList",
    columnsTooboxEnable: true,
    dblClickEnable: true,
    detailShowEnable: true
  };

  pledgeOperationAuthorizationStatuses;
  constructor(public router: Router, private store: Store<IAppState>, ) { }


  ngOnInit() {
    this.pledgeOperationAuthorizationStatuses = constructSelectItemsFromEnum(EPledgeOperationAuthorizationStatuses);
    this.pledgeOperationProductTypes = constructSelectItemsFromEnum(EProductType);
    zip(this.counterParties$, this.currencies$)
      .pipe(map(arr => ({ counterParties: arr[0], currencies: arr[1] })), untilDestroyed(this))
      .subscribe(({ counterParties, currencies }) => {
        this.currencies = constructSelectItemsFromArray(currencies, { name: "All", id: null });
        this.counterParties = constructSelectItemsFromArray(counterParties, { name: "TBC Capital", id: "0" });
        this.counterParties = constructSelectItemsFromArray(this.counterParties, { name: "All", id: null });
        this.columns = [
          {
            key: "id",
            name: "ID",
            type: "number",
            filterConfig: {
              filterType: "number"
            }
          },
          {
            key: "operationStatus",
            name: "Operation status",
            type: "string",
            style: {
              colorsMapping: EOperationStatusColor,
              conditionalColor: true
            },
            filterConfig: {
              filterData: constructSelectItemsFromEnum(EOperationStatus),
              filterType: "dropdown"
            }
          },
          {
            key: "startDate",
            name: "Start date",
            type: "date",
            filterConfig: {
              filterType: "date"
            }
          },
          {
            key: "endDate",
            name: "End date",
            type: "date",
            filterConfig: {
              filterType: "date"
            }
          },
          {
            key: "lenderClientName",
            name: "Lender client name",
            type: "string",
            filterConfig: {
              filterType: "string"
            }
          },
          {
            key: "borrowerClientName",
            name: "Borrower client name",
            type: "string",
            filterConfig: {
              filterType: "string"
            }
          },
          {
            key: "clientCounterpartyName",
            name: "Balance at",
            type: "string",
            filterConfig: {
              key: "clientCounterPartyId",
              filterData: this.counterParties,
              filterType: "dropdown",
              dropdownKeyKey: "name",
              dropdownValueKey: "id"
            }
          },
          {
            key: "currencyId",
            name: "Currency",
            type: "string",
            filterConfig: {
              containsDataMapping: true,
              filterData: this.currencies,
              filterType: "dropdown",
              dropdownKeyKey: "name",
              dropdownValueKey: "id"
            }
          },
          {
            key: "amount",
            name: "amount",
            type: "number",
            format: "##,#.##########",
            filterConfig: {
              filterType: "number"
            }
          },
          {
            key: "productType",
            name: "Product type",
            type: "string",
            filterConfig: {
              dataMappingSearchKey: "value",
              containsDataMapping: true,
              filterData: this.pledgeOperationProductTypes,
              filterType: "dropdown"
            }
          },

          {
            key: "status",
            name: "Authorization status",
            type: "string",
            style: {
              colorsMapping: EPledgeOperationAuthorizationStatusesColors,
              conditionalColor: true,
              isCard: true
            },
            filterConfig: {
              filterData: this.pledgeOperationAuthorizationStatuses,
              filterType: "dropdown"
            }
          }
        ];
      });
  }

  ngOnDestroy(): void {
  }

  handleAddPledgeOperation() {
    this.router.navigate(["admin/operations/pledge/add-pledge-operation"]);
  }

}
