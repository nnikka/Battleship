import { Component, OnInit, EventEmitter, OnDestroy } from "@angular/core";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import { TypedFormGroup } from "ngx-sub-form";
import { IPledgeformInterface } from "../../interfaces/pledge-operation-form.interface";
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { select, Store } from "@ngrx/store";
import { selectCurrencies, selectCurrencyLoadStatus } from "@core/store/currency/currency.selector";
import { PopupConfirmService } from "@components/popup-confirm/popup-confirm.service";
import { NotificationMessageService } from "@core/services/notification-message.service";
import { PledgeOperationService } from "../../services/pledge-operation.service";
import { Router, ActivatedRoute } from "@angular/router";
import { IAppState } from "@core/store/app.state";
import { MarkFormGroupTouched } from "src/utils/mark-formgroup-touched.helper";
import { untilDestroyed } from "ngx-take-until-destroy";
import { ChangesDetector } from "src/app/general/abstractClasses/ChangesDetector.abstractClass";
import { IPledgeHttpInterface } from "../../interfaces/pledge-operation-http.interface";
import { PledgeOperationInitialValue } from "../../components/pledge-operation-form/helpers/initial-value";
import { AuthService } from "@auth/services/auth.service";
import { EOperationStatus, EOperationStatusColor } from "@core/models/enums/EOperationStatus";
import {
  EPledgeOperationAuthorizationStatuses,
  EPledgeOperationAuthorizationStatusesColors
} from "../../enums/EPledgeOperationAuthorizationStatuses.enum";
import { OperationService, EOperationType } from "@core/services/operation.service";
import { convertToDMY } from "src/utils/date-converter.helper";
import { IOperationCorrectionType } from "../../interfaces/operation-correction-type.interface";
import { EProductType } from "../../enums/product-type.enum";

@Component({
  selector: "app-pledge-operation",
  templateUrl: "./pledge-operation.component.html",
  styleUrls: ["./pledge-operation.component.scss"]
})
export class PledgeOperationComponent extends ChangesDetector implements OnInit, OnDestroy {

  breadcrumbItems: IBreadcrumb[] = [
    { text: "Operations", to: null },
    { text: "Pledge", to: "/admin/operations/pledge" },
    { text: "Pledge operation", to: null }
  ];

  formReady: EventEmitter<TypedFormGroup<IPledgeformInterface> | null> =
    new EventEmitter<TypedFormGroup<IPledgeformInterface> | null>();
  loading = false;

  form;

  pledgeFormvalue: IPledgeformInterface;
  pledgeOperationFullData: IPledgeHttpInterface;

  pledgeOperationId;

  pledgeOperationLoading = false;

  currencies$ = this.store.pipe(select(selectCurrencies));
  currenciesLoaded = this.store.pipe(select(selectCurrencyLoadStatus));

  balancesData;

  productType;

  balancesDataDataLoading = false;

  authorizationIsDisabled = false;
  formIsUpdatedSuccessfully = false;


  correctionForm: FormGroup;
  correctionFormOpen = false;

  lastData;
  validateUsingLastChanges = false;


  get canAuthorize() {
    if (this.formIsUpdatedSuccessfully) {
      return false;
    }
    if (this.pledgeOperationFullData) {
      const lastUserId = this.pledgeOperationFullData.audit.lastModifiedUserId
        ? this.pledgeOperationFullData.audit.lastModifiedUserId
        : this.pledgeOperationFullData.audit.createUserId;
      if (lastUserId !== Number(this.authService.getUserId())) {
        return true;
      }
    }
    return null;
  }

  get canDeauthorize(): boolean {
    if (
      this.pledgeOperationFullData && this.pledgeOperationFullData.operationStatus === EOperationStatus.Success ||
      this.pledgeOperationFullData.operationStatus === EOperationStatus.Canceled ||
      this.pledgeOperationFullData.operationStatus === EOperationStatus.Terminated) {
      return false;
    }
    return true;
  }

  get operationStatus(): string {
    if (this.pledgeOperationFullData) {
      return EOperationStatus[this.pledgeOperationFullData.operationStatus];
    }
    return null;
  }

  get pledgeAuthorizationStatus() {
    return this.pledgeOperationFullData ?
      EPledgeOperationAuthorizationStatuses[this.pledgeOperationFullData.audit.status] : null;
  }

  get isPledgeUnauthorized() {
    return this.pledgeOperationFullData
      ? EPledgeOperationAuthorizationStatuses.Unauthorized === this.pledgeOperationFullData.audit.status
      : false;
  }
  get isPledgeOperationauthorized() {
    return this.pledgeOperationFullData
      ? EPledgeOperationAuthorizationStatuses.Authorized === this.pledgeOperationFullData.audit.status
      : false;
  }

  get isOperationSucceed(): boolean {
    if (this.pledgeOperationFullData) {
      return this.pledgeOperationFullData.operationStatus === EOperationStatus.Success;
    }
    return false;
  }

  get isExecutionOfTransactionsAvailable(): boolean {
    if (
      this.pledgeOperationFullData &&
      (this.pledgeOperationFullData.operationStatus === EOperationStatus.Pending ||
        this.pledgeOperationFullData.operationStatus === EOperationStatus.Fail)
    ) {
      return true;
    }
    return false;
  }
  get canDeleteChild() {
    return !this.isPledgeOperationauthorized;
  }

  constructor(
    private popupConfirmService: PopupConfirmService,
    private notificationMessageService: NotificationMessageService,
    private pledgeService: PledgeOperationService,
    private operationService: OperationService,
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute,
    private store: Store<IAppState>,
  ) {
    super();
  }

  hasUnsavedChanges(): boolean {
    if (this.form) {
      return this.form.dirty;
    }
    return false;
  }

  ngOnInit() {
    this.route.paramMap.pipe(untilDestroyed(this)).subscribe(paramsAsMap => {
      this.pledgeOperationId = paramsAsMap.get("id");
      this.loadPledgeOperation(this.pledgeOperationId);
    });

    this.formReady.pipe(untilDestroyed(this)).subscribe((form) => {
      if (form) {
        this.form = form;
        this.setupListeners();


        // load initial balance
        this.balancesDataDataLoading = false;
        this.balancesData = this.pledgeService.getClientBalances(this.form.get("lenderClientId").value);
      }
    });
  }

  setupListeners() {
    this.form.get("lenderClientId").valueChanges.pipe(untilDestroyed(this)).subscribe(id => {
      if (id) {
        this.balancesDataDataLoading = false;
        this.balancesData = this.pledgeService.getClientBalances(id);
      }
    });
    this.form.get("productType").valueChanges.pipe(untilDestroyed(this)).subscribe(type => {
      this.productType = type;
    });
  }

  ngOnDestroy(): void {
  }

  loadPledgeOperation(id) {
    this.pledgeOperationLoading = true;
    this.pledgeService
      .getById(id)
      .pipe(untilDestroyed(this))
      .subscribe(
        (ledgeOperationDataHttp: IPledgeHttpInterface) => {
          this.pledgeFormvalue = new PledgeOperationInitialValue(ledgeOperationDataHttp);

          const productTypeName = EProductType[ledgeOperationDataHttp.productType];

          this.pledgeOperationFullData = { ...ledgeOperationDataHttp, productTypeName };
          this.balancesData = this.pledgeService.getClientBalances(this.pledgeFormvalue.lenderClientId);
          this.pledgeOperationLoading = false;

          this.productType = this.pledgeOperationFullData.productType;

          this.generateCorrectionForm();
        },
        err => {
          this.router.navigateByUrl("/not-found", { replaceUrl: true });
        }
      );
  }

  generateCorrectionForm() {
    this.correctionForm = new FormGroup({
      endDate: new FormControl(
        convertToDMY(
          this.pledgeOperationFullData.endDate).toLocaleDateString(),
        [Validators.required]
      ),
      amount: new FormControl(this.pledgeOperationFullData.amount, Validators.required),
      balanceCorrectionStartDate: new FormControl(null),
    });
  }


  handleUpdate() {
    if (!this.form.dirty) {
      this.notificationMessageService.info("Nothing is changed");
      return;
    }
    if (!this.form.valid) {
      MarkFormGroupTouched(this.form.controls);
      this.notificationMessageService.error(
        "Form is invalid, please make sure all required fields are filled out correctly"
      );
    } else {
      this.popupConfirmService.show(null, null, () => {
        this.loading = true;
        this.pledgeService
          .update(this.pledgeOperationId, this.form.getRawValue())
          .pipe(untilDestroyed(this))
          .subscribe(
            resp => {
              this.form.reset();
              this.form.markAsPristine();
              this.router.navigate(["admin/operations/pledge"]);
              this.notificationMessageService.success("Pledge Operation has been added successfully");
            },
            err => {
              this.loading = false;
            }
          );
      });
    }
  }

  handleChangeAuthorize(status: string, message: string) {
    if (this.form && this.form.dirty) {
      this.notificationMessageService.warn(
        "Form is changed, if you want to change authorization status please update the form first"
      );
      return;
    }
    this.popupConfirmService.show(null, null, () => {
      this.pledgeOperationLoading = true;
      this.authorizationIsDisabled = true;
      this.pledgeService
        .changeAuthorizationStatus(this.pledgeOperationId, EPledgeOperationAuthorizationStatuses[status])
        .pipe(untilDestroyed(this))
        .subscribe(
          response => {
            this.pledgeOperationLoading = false;
            this.loadPledgeOperation(this.pledgeOperationId);
            this.notificationMessageService.success(message);
            this.authorizationIsDisabled = false;
          },
          error => {
            this.pledgeOperationLoading = false;
            this.authorizationIsDisabled = false;
          }
        );
    });
  }

  handleExecuteTransactions() {
    this.popupConfirmService.show(null, null, () => {
      this.pledgeOperationLoading = true;
      this.operationService
        .makeOperationTransactions(this.pledgeOperationId, EOperationType.Pledge)
        .pipe(untilDestroyed(this))
        .subscribe(
          resp => {
            this.loadPledgeOperation(this.pledgeOperationId);
            this.pledgeOperationLoading = false;
          },
          err => {
            this.loadPledgeOperation(this.pledgeOperationId);
            this.pledgeOperationLoading = false;
          }
        );
    });
  }

  authorizationStatusColor(status) {
    return EPledgeOperationAuthorizationStatusesColors[status];
  }

  operationStatusColor(status: string): string {
    return status ? EOperationStatusColor[status] : null;
  }


  handleCorrectionFormOpen(lastData?: IPledgeHttpInterface) {
    // console.log(lastData);

    if (lastData) {
      this.lastData = lastData;
      this.validateUsingLastChanges = true;

      this.correctionForm = new FormGroup({
        endDate: new FormControl(
          convertToDMY(
            lastData.endDate).toLocaleDateString(),
          [Validators.required]
        ),
        amount: new FormControl(lastData.amount, Validators.required),
        balanceCorrectionStartDate: new FormControl(null),
      });
    } else {
      this.validateUsingLastChanges = false;
    }
    this.correctionFormOpen = true;
  }

  handleCorrectionFormClose() {
    this.correctionFormOpen = false;
  }
  isCorrectionFormChanged(): boolean {
    if (this.validateUsingLastChanges) {
      const d1 = new Date(this.correctionForm.get("endDate").value);
      const d2 = new Date(convertToDMY(this.lastData.endDate).toLocaleDateString());

      return this.correctionForm.get("amount").value !== this.lastData.amount
        || d1.getTime() !== d2.getTime();
    } else {
      const d1 = new Date(this.correctionForm.get("endDate").value);
      const d2 = new Date(convertToDMY(this.pledgeOperationFullData.endDate).toLocaleDateString());

      return this.correctionForm.get("amount").value !== this.pledgeOperationFullData.amount
        || d1.getTime() !== d2.getTime();
    }

  }
  handleCorrectionFormSubmit() {
    let params;
    if (this.isCorrectionFormChanged()) {
      params = this.bulilRequestParams();
    }
    if (this.isCorrectionFormChanged() && this.correctionForm.get("balanceCorrectionStartDate").valid) {
      this.popupConfirmService.show(null, null, () => {
        this.pledgeOperationLoading = true;
        this.pledgeService
          .correctPledgeOperation(params)
          .pipe(untilDestroyed(this))
          .subscribe(
            resp => {
              this.correctionFormOpen = false;
              this.loadPledgeOperation(this.pledgeOperationId);
              this.pledgeOperationLoading = false;
              this.correctionForm = undefined;
            },
            err => {
              this.loadPledgeOperation(this.pledgeOperationId);
              this.pledgeOperationLoading = false;
              this.correctionForm = undefined;
            }
          );
      });
    } else {
      if (!this.correctionForm.get("balanceCorrectionStartDate").valid) {
        return;
        // this.notificationMessageService.error("Balance Correction Start Date is Required");
      } else {
        this.notificationMessageService.info("Nothing is changed");
      }
    }

  }

  handlePledgeTermination() {
    this.popupConfirmService.show(null, null, () => {
      this.pledgeOperationLoading = true;
      this.authorizationIsDisabled = true;
      this.pledgeService
        .changePledgeOperationStatus(this.pledgeOperationId, EOperationStatus.Terminated)
        .pipe(untilDestroyed(this))
        .subscribe(
          response => {
            this.pledgeOperationLoading = false;
            this.loadPledgeOperation(this.pledgeOperationId);
            this.notificationMessageService.success("Operation terminated successfully");
            this.authorizationIsDisabled = false;
          },
          error => {
            this.pledgeOperationLoading = false;
            this.authorizationIsDisabled = false;
          }
        );
    });
  }

  handlePledgeCancel() {
    this.popupConfirmService.show(null, null, () => {
      this.pledgeOperationLoading = true;
      this.authorizationIsDisabled = true;
      this.pledgeService
        .changePledgeOperationStatus(this.pledgeOperationId, EOperationStatus.Canceled)
        .pipe(untilDestroyed(this))
        .subscribe(
          response => {
            this.pledgeOperationLoading = false;
            this.loadPledgeOperation(this.pledgeOperationId);
            this.notificationMessageService.success("Pledge operation has been canceled successfully");
            this.authorizationIsDisabled = false;
          },
          error => {
            this.pledgeOperationLoading = false;
            this.authorizationIsDisabled = false;
          }
        );
    });
  }

  handlePledgeOperationDelete() {
    this.popupConfirmService.show(null, null, () => {
      this.pledgeOperationLoading = true;
      this.authorizationIsDisabled = true;
      this.pledgeService
        .deletePledgeOperation(this.pledgeOperationId)
        .pipe(untilDestroyed(this))
        .subscribe(
          response => {
            this.pledgeOperationLoading = false;
            this.notificationMessageService.success("Pledge operation has been deleted successfully");
            this.authorizationIsDisabled = false;
            this.router.navigate(["admin/operations/pledge"]);
          },
          error => {
            this.pledgeOperationLoading = false;
            this.authorizationIsDisabled = false;
          }
        );
    });
  }


  bulilRequestParams(): IOperationCorrectionType {
    const params: IOperationCorrectionType = {
      parentOperationId: this.pledgeOperationId
    };

    if (
      this.correctionForm.get("amount").value
      && this.correctionForm.get("amount").value !== this.pledgeOperationFullData.amount
    ) {
      if (this.correctionForm.get("balanceCorrectionStartDate").value) {
        params.amount = this.correctionForm.get("amount").value;
        params.balanceCorrectionStartDate = this.correctionForm.get("balanceCorrectionStartDate").value;
      } else {
        this.correctionForm.get("balanceCorrectionStartDate").setErrors({ required: true });
        this.correctionForm.get("balanceCorrectionStartDate").markAllAsTouched();
      }
    }

    if (
      this.correctionForm.get("endDate").value
      && this.correctionForm.get("endDate").value !== this.pledgeOperationFullData.endDate
    ) {
      params.endDate = this.correctionForm.get("endDate").value;
    }

    return params;
  }


}
