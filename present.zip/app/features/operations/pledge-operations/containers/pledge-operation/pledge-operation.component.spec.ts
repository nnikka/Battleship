import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PledgeOperationComponent } from './pledge-operation.component';

describe('PledgeOperationComponent', () => {
  let component: PledgeOperationComponent;
  let fixture: ComponentFixture<PledgeOperationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PledgeOperationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PledgeOperationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
