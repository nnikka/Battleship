import { Component, OnInit, EventEmitter, OnDestroy } from "@angular/core";
import { IPledgeformInterface } from "../../interfaces/pledge-operation-form.interface";
import { TypedFormGroup } from "ngx-sub-form";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import { ChangesDetector } from "src/app/general/abstractClasses/ChangesDetector.abstractClass";
import { FormGroup } from "@angular/forms";
import { MarkFormGroupTouched } from "src/utils/mark-formgroup-touched.helper";
import { PopupConfirmService } from "@components/popup-confirm/popup-confirm.service";
import { NotificationMessageService } from "@core/services/notification-message.service";
import { untilDestroyed } from "ngx-take-until-destroy";
import { PledgeOperationService } from "../../services/pledge-operation.service";
import { Store, select } from "@ngrx/store";
import { IAppState } from "@core/store/app.state";
import { selectCurrencies, selectCurrencyLoadStatus } from "@core/store/currency/currency.selector";
import { Router } from "@angular/router";
import { of } from "rxjs";

@Component({
  selector: "app-pledge-operation-add",
  templateUrl: "./pledge-operation-add.component.html",
  styleUrls: ["./pledge-operation-add.component.scss"]
})
export class PledgeOperationAddComponent extends ChangesDetector implements OnInit, OnDestroy {

  breadcrumbItems: IBreadcrumb[] = [
    { text: "Operations", to: null },
    { text: "Pledge", to: "/admin/operations/pledge" },
    { text: "Add operation", to: null }
  ];

  formReady: EventEmitter<TypedFormGroup<IPledgeformInterface> | null> =
    new EventEmitter<TypedFormGroup<IPledgeformInterface> | null>();
  loading = false;

  form;

  currencies$ = this.store.pipe(select(selectCurrencies));
  currenciesLoaded = this.store.pipe(select(selectCurrencyLoadStatus));

  balancesData;

  productType;

  balancesDataDataLoading;

  constructor(
    private popupConfirmService: PopupConfirmService,
    private notificationMessageService: NotificationMessageService,
    private pledgeService: PledgeOperationService,
    private router: Router,
    private store: Store<IAppState>,
  ) {
    super();
  }

  hasUnsavedChanges(): boolean {
    if (this.form) {
      return this.form.dirty;
    }
    return false;
  }

  ngOnInit() {
    this.formReady.pipe(untilDestroyed(this)).subscribe((form) => {
      this.form = form;
      this.balancesDataDataLoading = true;
      this.form.get("lenderClientId").valueChanges.pipe(untilDestroyed(this)).subscribe(id => {
        if (id) {
          this.balancesDataDataLoading = false;
          this.balancesData = this.pledgeService.getClientBalances(id);
        } else {
          this.balancesData = of([]);
        }
      });
      this.form.get("productType").valueChanges.pipe(untilDestroyed(this)).subscribe(type => {
        this.productType = type;
      });
    });
  }

  ngOnDestroy(): void {
  }

  handleRegister() {
    if (!this.form.valid) {
      MarkFormGroupTouched(this.form.controls);
      this.notificationMessageService.error(
        "Form is invalid, please make sure all required fields are filled out correctly"
      );
    } else {
      this.popupConfirmService.show(null, null, () => {
        this.loading = true;
        this.pledgeService
          .create(this.form.getRawValue())
          .pipe(untilDestroyed(this))
          .subscribe(
            resp => {
              this.form.reset();
              this.form.markAsPristine();
              this.router.navigate(["admin/operations/pledge"]);
              this.notificationMessageService.success("Pledge Operation has been added successfully");
            },
            err => {
              this.loading = false;
            }
          );
      });
    }
  }

}
