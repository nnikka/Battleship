import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PledgeOperationAddComponent } from './pledge-operation-add.component';

describe('PledgeOperationAddComponent', () => {
  let component: PledgeOperationAddComponent;
  let fixture: ComponentFixture<PledgeOperationAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PledgeOperationAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PledgeOperationAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
