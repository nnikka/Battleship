import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PledgeOperationFormComponent } from './pledge-operation-form.component';

describe('PledgeOperationFormComponent', () => {
  let component: PledgeOperationFormComponent;
  let fixture: ComponentFixture<PledgeOperationFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PledgeOperationFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PledgeOperationFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
