import {
    IPledgeHttpInterface
} from "@features/operations/pledge-operations/interfaces/pledge-operation-http.interface";
import {
    IPledgeformInterface
} from "@features/operations/pledge-operations/interfaces/pledge-operation-form.interface";
import { convertToDMY } from "src/utils/date-converter.helper";


export class PledgeOperationInitialValue implements IPledgeformInterface {
    startDate: string;
    endDate: string;
    lenderClientId: number;
    borrowerClientId: number;
    clientCounterpartyId: number;
    productType: string;
    productId: number;
    currencyId: number;
    amount: number;
    comment: string;
    balanceAtTbcCapital: boolean;

    constructor(pledgeData: IPledgeHttpInterface) {
        this.startDate = convertToDMY(pledgeData.startDate).toLocaleDateString();
        this.endDate = convertToDMY(pledgeData.endDate).toLocaleDateString();
        this.lenderClientId = pledgeData.lenderClientId;
        this.borrowerClientId = pledgeData.borrowerClientId;
        this.clientCounterpartyId = pledgeData.clientCounterpartyId;
        this.productType = pledgeData.productType;
        this.productId = pledgeData.productId;
        this.currencyId = pledgeData.currencyId;
        this.amount = pledgeData.amount;
        this.comment = pledgeData.comment;
        this.balanceAtTbcCapital = pledgeData.clientCounterpartyId === null ? true : false;
    }
}
