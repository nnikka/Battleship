import { TypedValidatorFn, TypedFormGroup } from "ngx-sub-form";

import {
    IPledgeformInterface
} from "@features/operations/pledge-operations/interfaces/pledge-operation-form.interface";

import { ValidationErrors, AbstractControl } from "@angular/forms";

export function PledgeOperationFormValidator(): TypedValidatorFn<IPledgeformInterface> {
    return (formGroup: TypedFormGroup<IPledgeformInterface>): ValidationErrors | null => {
        // Dates validation
        const startDateControl = formGroup.controls.startDate;
        const endDateControl = formGroup.controls.endDate;
        validateStartAndEndDate(startDateControl, endDateControl);

        const lenderControl = formGroup.controls.lenderClientId;
        const borrowerControl = formGroup.controls.borrowerClientId;
        validateLenderAndBorrower(lenderControl, borrowerControl);

        // need names word

        // const amountNominal = formGroup.controls.clientCurrency;
        // const counterpartCurrency = formGroup.controls.counterpartCurrency;
        // validateClientAndCounterpartCurrency(clientCurrency, counterpartCurrency);

        // return null default for form error we set individual control errors above
        return null;
    };
}


export function validateStartAndEndDate(startDateControl, endDateControl) {
    let startDate = null;
    let endDate = null;

    if (startDateControl.value) {
        startDate = new Date(startDateControl.value).getTime();
    }
    if (endDateControl.value) {
        endDate = new Date(endDateControl.value).getTime();
    }

    if (startDate && endDate && startDate >= endDate) {
        startDateControl.setErrors({ startDateMustBeLessThenEndDate: true });
        // return { settlementDateMustBeMoreOrEqualThenTradeDate: true };
    } else if (startDate && endDate && !(startDate > endDate)) {
        startDateControl.setErrors(null);
        // return null;
    }
}

export function validateLenderAndBorrower(lenderControl: AbstractControl, borrowerControl: AbstractControl) {
    let lenderClient = null;
    let borrowerClient = null;

    if (lenderControl.value) {
        lenderClient = lenderControl.value;
    }
    if (borrowerControl.value) {
        borrowerClient = borrowerControl.value;
    }
    if (lenderClient && borrowerClient && lenderClient === borrowerClient) {
        lenderControl.setErrors({ lenderAndBorrowerCannotBeSame: true });
    } else if (lenderClient && borrowerClient && !(lenderClient === borrowerClient)) {
        lenderControl.setErrors(null);
    }
}
