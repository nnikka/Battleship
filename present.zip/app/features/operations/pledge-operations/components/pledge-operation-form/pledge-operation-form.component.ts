import { Component, OnInit, Input, OnDestroy } from "@angular/core";
import { IPledgeformInterface } from "../../interfaces/pledge-operation-form.interface";
import { DataInput, Controls, FormUpdate, FormGroupOptions } from "ngx-sub-form";
import { ComplexFormRoot } from "src/app/general/abstractClasses/ComplexFormRoot.abstractClass";
import { Validators, FormControl } from "@angular/forms";
import { EClientStatuses } from "@features/static-data/clients/models/ClientStatuses.enum";
import { EClientTypes } from "@features/static-data/clients/models/ClientTypes.enum";
import { constructSelectItemsFromEnum } from "src/utils/array.helper";
import { EProductType } from "../../enums/product-type.enum";
import { EBondAuthorizationStatuses } from "@features/static-data/bonds/models/BondAuthorizationStatuses.enum";
import { EStockAuthorizationStatuses } from "@features/static-data/stocks/models/stockAuthorizationStatuses.enu";
import { trigger, transition, style, animate } from "@angular/animations";
import { ICurrency } from "@core/models/catalogs/currency.interface";
import { PledgeOperationService } from "../../services/pledge-operation.service";
import { PledgeOperationFormValidator } from "./helpers/pledge-operation.validator";

// TODO(giorgi): add loaders for some controlls
@Component({
  selector: "app-pledge-operation-form",
  templateUrl: "./pledge-operation-form.component.html",
  styleUrls: ["./pledge-operation-form.component.scss"],
  animations: [
    trigger(
      "inOutAnimationCounterparty",
      [
        transition(
          ":enter",
          [
            style({ height: 0, opacity: 0 }),
            animate(".5s ease-out",
              style({ height: "*", opacity: 1 }))
          ]
        ),
        transition(
          ":leave",
          [
            style({ height: "*", opacity: 1 }),
            animate(".5s ease-in",
              style({ height: 0, opacity: 0 }))
          ]
        )
      ]
    ),
    trigger(
      "inOutAnimation",
      [
        transition(
          ":enter",
          [
            style({ height: 0, opacity: 0 }),
            animate(".5s ease-out",
              style({ height: "*", opacity: 1 }))
          ]
        ),
        transition(
          ":leave",
          [
            style({ height: "*", opacity: 1 }),
            animate(".5s ease-in",
              style({ height: 0, opacity: 0 }))
          ]
        )
      ]
    )
  ]
})
export class PledgeOperationFormComponent extends ComplexFormRoot<IPledgeformInterface> implements OnInit, OnDestroy {

  @DataInput()
  @Input() public dataInput: Required<IPledgeformInterface>;

  authorizedClientRequiredHttpParams: any = {
    "filterItem.status": EClientStatuses.Authorized,
    SortBy: "clientName",
    SortDirection: 0
  };
  authorizedCounterPartyRequiredHttpParams: any = {
    "filterItem.clientTypes": EClientTypes.Counterparty,
    "filterItem.status": EClientStatuses.Authorized,
    "filterItem.id": 0,
    SortBy: "clientName",
    SortDirection: 0
  };
  authorizedBondRequiredParams = {
    "filterItem.status": EBondAuthorizationStatuses.Authorized,
    SortBy: "name",
    SortDirection: 0
  };
  authorizedStockRequiredParams = {
    "filterItem.status": EStockAuthorizationStatuses.Authorized,
    SortBy: "name",
    SortDirection: 0
  };

  productListUri = "";
  authorizedProductRequiredParams = null;

  get showproductName() {
    return this.formGroupControls.productType.value === EProductType.Cash
      || this.formGroupControls.productType.value == null;
  }

  get showCounterpartySelect() {
    return this.formGroupControls.productType.value === EProductType.Cash
      || this.formGroupControls.productType.value === EProductType.Stock;
  }

  get showBalanceAtRadio() {
    return this.formGroupControls.productType.value === EProductType.Cash;
  }

  get isBondOrStock() {
    return this.formGroupControls.productType.value === EProductType.Bond ||
      this.formGroupControls.productType.value === EProductType.Stock;
  }


  productTypes = [];
  // autocomplete needs custom boolean to disable control
  isProductSelectDisabled = true;
  isCounterpartyIdSelectDisabled = true;
  @Input() currencies: ICurrency[];

  constructor(
    private pledgeService: PledgeOperationService,
  ) {
    super();
  }

  ngOnInit() {
    super.ngOnInit();
    this.productTypes = constructSelectItemsFromEnum(EProductType, false);

    if (this.formGroupControls.lenderClientId.value && this.formGroupControls.productType.value) {
      this.updateFormForProductType();
    }
    if (this.formGroupControls.productType.value === EProductType.Cash
      && !this.formGroupControls.balanceAtTbcCapital.value) {
      this.isCounterpartyIdSelectDisabled = false;
    }
  }

  onFormUpdate(formUpdate: FormUpdate<IPledgeformInterface>) {
    if (formUpdate.balanceAtTbcCapital) {
      this.updateClientCounterpartyId();
    }
    if (formUpdate.productType) {
      this.updateFormForProductTypeManualy();
    }
    if (formUpdate.lenderClientId) {
      if (this.formGroupControls.lenderClientId.value) {
        this.setLenderParameters();
        this.formGroupControls.productId.reset(null, { emitEvent: false });
        this.isProductSelectDisabled = false;
      } else {
        this.setLenderParameters();
        this.formGroupControls.productId.reset(null, { emitEvent: false });
        this.isProductSelectDisabled = true;
      }
    }
    if (formUpdate.productId) {
      this.updateCurrencyByProductInfo();
    }
  }

  updateFormForProductTypeManualy() {
    if (this.formGroupControls.productType.value === EProductType.Bond) {
      this.updateFormForBond();
    }
    if (this.formGroupControls.productType.value === EProductType.Stock) {
      this.updateFormForStock();
    }
    if (this.formGroupControls.productType.value === EProductType.Cash) {
      this.updateFormForCash();
    }
  }
  updateFormForProductType() {
    if (this.formGroupControls.productType.value === EProductType.Bond) {
      this.setBondParameters();
      this.isProductSelectDisabled = false;
    }
    if (this.formGroupControls.productType.value === EProductType.Stock) {
      this.setStockParameters();
      this.isProductSelectDisabled = false;
      this.isCounterpartyIdSelectDisabled = false;
    }
    if (this.formGroupControls.productType.value === EProductType.Cash) {
      // this.updateFormForCash();
    }
  }

  updateCurrencyByProductInfo() {
    if (this.formGroupControls.productType.value === EProductType.Bond && this.formGroupControls.productId.value) {
      this.pledgeService.getBondById(this.formGroupControls.productId.value).subscribe((bond: any) => {
        this.formGroupControls.currencyId.setValue(bond.currencyId, { emitEvent: false });
      });
    } else {
      this.formGroupControls.currencyId.setValue(null, { emitEvent: false });
    }

    if (this.formGroupControls.productType.value === EProductType.Stock && this.formGroupControls.productId.value) {
      this.pledgeService.getStockById(this.formGroupControls.productId.value).subscribe((stock: any) => {
        this.formGroupControls.currencyId.setValue(stock.currencyId, { emitEvent: false });
      });
    } else {
      this.formGroupControls.currencyId.setValue(null, { emitEvent: false });
    }

  }

  updateFormForBond() {
    this.setBondParameters();
    if (this.formGroupControls.lenderClientId.value) {
      this.formGroupControls.productId.reset(null, { emitEvent: false });
      this.isProductSelectDisabled = false;
    } else {
      this.isProductSelectDisabled = true;
    }
    this.formGroupControls.clientCounterpartyId.reset(null, { emitEvent: false });
    this.formGroupControls.balanceAtTbcCapital.reset(null, { emitEvent: false });
    this.formGroupControls.currencyId.reset(null, { emitEvent: false });

    this.formGroupControls.clientCounterpartyId.disable();
    this.formGroupControls.balanceAtTbcCapital.disable();
    this.formGroupControls.currencyId.disable();
  }

  updateFormForStock() {
    this.setStockParameters();
    if (this.formGroupControls.lenderClientId.value) {
      this.formGroupControls.productId.reset(null, { emitEvent: false });
      this.isProductSelectDisabled = false;
      this.isCounterpartyIdSelectDisabled = false;
    } else {
      this.isProductSelectDisabled = true;
      this.isCounterpartyIdSelectDisabled = true;
    }
    this.formGroupControls.clientCounterpartyId.reset(null, { emitEvent: false });
    this.formGroupControls.balanceAtTbcCapital.reset(null, { emitEvent: false });
    this.formGroupControls.currencyId.reset(null, { emitEvent: false });

    this.formGroupControls.clientCounterpartyId.disable();
    this.formGroupControls.balanceAtTbcCapital.disable();
    this.formGroupControls.currencyId.disable();
  }

  updateFormForCash() {
    if (this.formGroupControls.lenderClientId.value) {
      this.formGroupControls.productId.reset(null, { emitEvent: false });
      this.isProductSelectDisabled = false;
    } else {
      this.isProductSelectDisabled = true;
    }
    this.formGroupControls.clientCounterpartyId.reset(null, { emitEvent: false });
    this.formGroupControls.balanceAtTbcCapital.reset(null, { emitEvent: false });
    this.formGroupControls.currencyId.reset(null, { emitEvent: false });

    this.formGroupControls.clientCounterpartyId.disable();
    this.formGroupControls.balanceAtTbcCapital.enable();
    this.formGroupControls.currencyId.enable();
  }

  // filter heder is sticked in other requests
  setBondParameters() {
    this.setLenderParameters();
    this.productListUri = "/api/bonds";
  }
  setStockParameters() {
    this.setLenderParameters();
    this.productListUri = "/api/stocks";
  }

  setLenderParameters() {
    if (this.formGroupControls.productType.value === EProductType.Stock) {
      this.authorizedProductRequiredParams = {
        ...this.authorizedProductRequiredParams,
        "filterItem.StockHolderId": this.formGroupControls.lenderClientId.value,
        "filterItem.BondHolderId": null
      };
    } else if (this.formGroupControls.productType.value === EProductType.Bond) {
      this.authorizedProductRequiredParams = {
        ...this.authorizedProductRequiredParams,
        "filterItem.BondHolderId": this.formGroupControls.lenderClientId.value,
        "filterItem.StockHolderId": null
      };
    }
  }

  updateClientCounterpartyId() {
    if (this.formGroupControls.balanceAtTbcCapital.value === true) {
      this.formGroupControls.clientCounterpartyId.reset(null, { emitEvent: false });
      this.isCounterpartyIdSelectDisabled = true;
    } else {
      this.formGroupControls.clientCounterpartyId.reset(null, { emitEvent: false });
      this.isCounterpartyIdSelectDisabled = false;
    }
  }

  updateCurrency(currency) {
    this.formGroupControls.currencyId.setValue(currency);
  }

  protected getFormControls(): Controls<IPledgeformInterface> {
    return {
      startDate: new FormControl(null, [Validators.required]),
      endDate: new FormControl(null, [Validators.required]),
      lenderClientId: new FormControl(null, [Validators.required]),
      borrowerClientId: new FormControl(null, [Validators.required]),
      clientCounterpartyId: new FormControl(null, []),
      productType: new FormControl(null, [Validators.required]),
      productId: new FormControl({ value: null, disabled: true }, []),
      currencyId: new FormControl({ value: null, disabled: true }, [Validators.required]),
      balanceAtTbcCapital: new FormControl(null, []),
      amount: new FormControl(null, [Validators.required]),
      comment: new FormControl(null, []),
    };
  }

  public getFormGroupControlOptions(): FormGroupOptions<IPledgeformInterface> {
    return {
      validators: [PledgeOperationFormValidator()]
    };
  }

}
