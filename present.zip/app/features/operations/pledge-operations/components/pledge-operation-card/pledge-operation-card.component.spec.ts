import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PledgeOperationCardComponent } from './pledge-operation-card.component';

describe('PledgeOperationCardComponent', () => {
  let component: PledgeOperationCardComponent;
  let fixture: ComponentFixture<PledgeOperationCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PledgeOperationCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PledgeOperationCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
