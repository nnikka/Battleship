import { Component, OnInit, Input } from "@angular/core";
import { IPledgeHttpInterface } from "../../interfaces/pledge-operation-http.interface";
import { IntlService } from "@progress/kendo-angular-intl";

@Component({
  selector: "app-pledge-operation-card",
  templateUrl: "./pledge-operation-card.component.html",
  styleUrls: ["./pledge-operation-card.component.scss"]
})
export class PledgeOperationCardComponent implements OnInit {

  @Input() pledgeOperationFullData: IPledgeHttpInterface;

  constructor(public intl: IntlService) { }

  ngOnInit() {
  }

}
