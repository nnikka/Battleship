import { Component, OnInit, Input, OnDestroy, EventEmitter, Output } from "@angular/core";
import { IPledgeHttpInterface } from "../../interfaces/pledge-operation-http.interface";
import { GridDataResult } from "@progress/kendo-angular-grid";
import { IntlService } from "@progress/kendo-angular-intl";
import {
  EPledgeOperationAuthorizationStatuses,
  EPledgeOperationAuthorizationStatusesColors
} from "../../enums/EPledgeOperationAuthorizationStatuses.enum";
import { NotificationMessageService } from "@core/services/notification-message.service";
import { PopupConfirmService } from "@components/popup-confirm/popup-confirm.service";
import { untilDestroyed } from "ngx-take-until-destroy";
import { PledgeOperationService } from "../../services/pledge-operation.service";
import { EOperationType, OperationService } from "@core/services/operation.service";
import { EOperationStatusColor, EOperationStatus } from "@core/models/enums/EOperationStatus";
import { AuthService } from "@auth/services/auth.service";

@Component({
  selector: "app-correction-list",
  templateUrl: "./correction-list.component.html",
  styleUrls: ["./correction-list.component.scss"]
})
export class CorrectionListComponent implements OnInit, OnDestroy {

  @Output() reloadPledgeOperation: EventEmitter<number> = new EventEmitter();
  @Output() openCorrectionmodal: EventEmitter<any> = new EventEmitter();

  get gridView(): GridDataResult {
    return {
      data: this.correctionHistory ? this.correctionHistory : [],
      total: this.correctionHistory ? this.correctionHistory.length : 0
    };
  }

  constructor(
    public intl: IntlService,
    private popupConfirmService: PopupConfirmService,
    private notificationMessageService: NotificationMessageService,
    private pledgeService: PledgeOperationService,
    private operationService: OperationService,
    private authService: AuthService,
  ) { }

  @Input() correctionHistory: IPledgeHttpInterface[];
  @Input() pledgeOperationId;

  isActionsDisabled = false;

  getChildAuthorizationStatus(auditStatus): string {
    return auditStatus ?
      EPledgeOperationAuthorizationStatuses[auditStatus] : null;
  }

  getChildOperationStatus(operationStatus): string {
    return operationStatus ?
      EOperationStatus[operationStatus] : null;
  }

  isChildAuthorized(auditStatus): boolean {
    return auditStatus
      ? EPledgeOperationAuthorizationStatuses.Authorized === auditStatus
      : false;
  }

  isPledgeOperationauthorized(auditStatus) {
    return auditStatus
      ? EPledgeOperationAuthorizationStatuses.Authorized === auditStatus
      : false;
  }

  isExecutionOfTransactionsAvailable(childRow) {
    if (
      childRow &&
      (childRow.operationStatus === EOperationStatus.Pending ||
        childRow.operationStatus === EOperationStatus.Fail)
    ) {
      // const pattern = /(\d{2})\.(\d{2})\.(\d{4})/;
      // const settlementDate = new Date(this.pledgeOperationFullData.endDate.replace(pattern, "$3-$2-$1")).getTime();
      // if (settlementDate < Date.now()) {

      // }
      return true;
    }
    return false;
  }

  isChildOperationSucceed(operationStatus) {
    return operationStatus === EOperationStatus.Success;
  }

  getCanAuthorize(audit): boolean {
    if (audit) {
      const lastUserId = audit.lastModifiedUserId
        ? audit.lastModifiedUserId
        : audit.createUserId;
      if (lastUserId !== Number(this.authService.getUserId())) {
        return true;
      }
    }
    return null;
  }

  getCanDeAuthorize(status) {
    if (
      status && status === EOperationStatus.Success ||
      status === EOperationStatus.Canceled ||
      status === EOperationStatus.Terminated
    ) {
      return false;
    }
    return true;
  }

  canDeleteChild(authorizationStatus) {
    if (
      authorizationStatus &&
      EPledgeOperationAuthorizationStatuses.Unauthorized === authorizationStatus
    ) {
      return true;
    }
    return false;
  }

  ngOnInit() {
  }

  ngOnDestroy(): void {
  }

  handleChangeAuthorize(status: string, message: string, id: string) {
    // if (this.form && this.form.dirty) {
    //   this.notificationMessageService.warn(
    //     "Form is changed, if you want to change authorization status please update the form first"
    //   );
    //   return;
    // }
    this.popupConfirmService.show(null, null, () => {
      this.isActionsDisabled = true;
      this.pledgeService
        .changeAuthorizationStatus(id, EPledgeOperationAuthorizationStatuses[status])
        .pipe(untilDestroyed(this))
        .subscribe(
          response => {
            this.reloadPledgeOperation.emit(this.pledgeOperationId);
            this.notificationMessageService.success(message);
            this.isActionsDisabled = false;
          },
          error => {
            this.isActionsDisabled = false;
          }
        );
    });
  }

  handlePledgeOperationDelete(childOperationId) {
    this.popupConfirmService.show(null, null, () => {
      this.isActionsDisabled = true;
      this.pledgeService
        .deletePledgeOperation(childOperationId)
        .pipe(untilDestroyed(this))
        .subscribe(
          response => {
            this.reloadPledgeOperation.emit(this.pledgeOperationId);
            this.notificationMessageService.success("Operation deleted successfully");
            this.isActionsDisabled = false;
          },
          error => {
            this.isActionsDisabled = false;
          }
        );
    });
  }

  handleExecuteTransactions(id) {
    this.popupConfirmService.show(null, null, () => {
      this.operationService
        .makeOperationTransactions(id, EOperationType.Pledge)
        .pipe(untilDestroyed(this))
        .subscribe(
          resp => {
            this.reloadPledgeOperation.emit(this.pledgeOperationId);
          },
          err => {
            this.reloadPledgeOperation.emit(this.pledgeOperationId);
          }
        );
    });
  }


  childAuthorizationStatusColor(status) {
    return EPledgeOperationAuthorizationStatusesColors[status];
  }

  childOperationStatusColor(status: string): string {
    return status ? EOperationStatusColor[status] : null;
  }

  handleCorrectionFormOpen(lastData) {
    this.openCorrectionmodal.emit(lastData);
  }

}
