import { Component, OnInit, Input } from "@angular/core";
import { Subject } from "rxjs";
import { EProductType } from "../../enums/product-type.enum";
import { IntlService } from "@progress/kendo-angular-intl";

@Component({
  selector: "app-balances-card",
  templateUrl: "./balances-card.component.html",
  styleUrls: ["./balances-card.component.scss"]
})
export class BalancesCardComponent implements OnInit {

  @Input() balancesData;
  @Input() productType: EProductType;

  clientBalances;

  selectedBalanceClient;
  selectedBalanceCounterparty;

  get isBond() {
    return this.productType === EProductType.Bond;
  }
  get isStock() {
    return this.productType === EProductType.Stock;
  }
  get isCash() {
    return this.productType === EProductType.Cash;
  }

  constructor(public intl: IntlService) { }

  ngOnInit() {
  }
}
