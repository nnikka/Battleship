import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BalancesCardComponent } from './balances-card.component';

describe('BalancesCardComponent', () => {
  let component: BalancesCardComponent;
  let fixture: ComponentFixture<BalancesCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BalancesCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BalancesCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
