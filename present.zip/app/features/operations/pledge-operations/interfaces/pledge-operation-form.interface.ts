
export interface IPledgeformInterface {
    startDate: string;
    endDate: string;
    lenderClientId: number;
    borrowerClientId: number;
    clientCounterpartyId: number;
    productType: string;
    productId: number;
    currencyId: number;
    amount: number;
    comment: string;
    balanceAtTbcCapital: boolean;
}
