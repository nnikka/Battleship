import { IAuditCommand } from "@core/models/commands/IAuditCommand";

export interface IPledgeHttpInterface {
    id: number;
    audit: IAuditCommand;
    operationStatus: number;
    startDate: string;
    endDate: string;
    lenderClientId: number;
    clientCounterpartyId: number;
    borrowerClientId: number;
    lenderClientName: string;
    borrowerClientName: string;
    clientCounterpartyName: string;
    productType: string;
    productTypeName: number; // name generated on response
    productId: number;
    productName: number;
    currencyId: number;
    currencyName: string;
    balanceAtTbcCapital: boolean;
    amount: number;
    comment: string;
    isAmountChanged?: boolean;
    isEndDateChanged?: boolean;
    operationTransactions: ITransaction[];
    childOperations: IPledgeHttpInterface[];
}


interface ITransaction {
    id: number;
    transactionDate: string;
    clientId: number;
    clientName: string;
    assetTypeName: string;
    transactionTypeName: string;
    debitAmount: number;
    creditAmount: number;
    transactionStatus: string;
    transactionStatusMessage: string;
    currencyName: string;
    comment: string;
    hasWithholdingTax: boolean;
    withholdingTaxAmount: number;
}
