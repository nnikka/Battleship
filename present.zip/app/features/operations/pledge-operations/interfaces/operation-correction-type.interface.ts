export interface IOperationCorrectionType {
    parentOperationId: string;
    endDate?: string;
    amount?: number;
    balanceCorrectionStartDate?: string;
}
