export enum EProductType {
    Stock = 1,
    Bond = 2,
    Cash = 4
}
