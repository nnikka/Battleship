import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { PledgeOperationsListComponent } from "./containers/pledge-operations-list/pledge-operations-list.component";
import { PledgeOperationComponent } from "./containers/pledge-operation/pledge-operation.component";
import { ConfirmDeactivateGuard } from "@core/guards/confirm-deactivate-guard.guard";
import { PledgeOperationAddComponent } from "./containers/pledge-operation-add/pledge-operation-add.component";
import { CurrencyResolver } from "@core/resolvers/catalogs/currency.resolver";
import { CounterPartyResolver } from "@core/resolvers/catalogs/counterParty.resolver";


const routes: Routes = [
  {
    path: "",
    component: PledgeOperationsListComponent,
    resolve: {
      currency: CurrencyResolver,
      counterParty: CounterPartyResolver
    }
  },
  {
    path: "add-pledge-operation",
    component: PledgeOperationAddComponent,
    canDeactivate: [ConfirmDeactivateGuard]
  },
  {
    path: ":id",
    component: PledgeOperationComponent,
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PledgeOperationsRoutingModule { }
