import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { ConfigService } from "@env/service/config.service";
import { IHttpPagingQueryParams } from "@shared/models/IHttpPagingQueryParams";
import { IPagingHttpResponse } from "@shared/models/IPagingHttpResponse";
import { IHttpStock } from "@features/static-data/stocks/models/IHttpStock";
import { StockOperationParams } from "../models/StockOperationParams";
import { ClientStockBalance } from "../models/ClientStockBalance";
import { IHttpStockOperation } from "../models/IHttpStockOperation";
import { IStockOperationListItem } from "../models/IStockOperationListItem";

@Injectable()
export class StockOperationService {
  constructor(private http: HttpClient, private configService: ConfigService) { }

  getStockById(id: string): Observable<IHttpStock> {
    return this.http.get<IHttpStock>(`${this.configService.config.apiBaseurl}/api/Stocks/${id}`);
  }

  create(params: StockOperationParams): Observable<any> {
    return this.http.post(`${this.configService.config.apiBaseurl}/api/StockOperations`, params);
  }

  getAll(queryParams: IHttpPagingQueryParams): Observable<IPagingHttpResponse<IStockOperationListItem[]>> {
    const params = queryParams as any;
    return this.http.get<IPagingHttpResponse<IStockOperationListItem[]>>(
      `${this.configService.config.apiBaseurl}/api/StockOperations`,
      {
        params
      }
    );
  }

  getById(id: string): Observable<IHttpStockOperation> {
    return this.http.get<IHttpStockOperation>(`${this.configService.config.apiBaseurl}/api/StockOperations/${id}`);
  }

  update(id: string, params): Observable<any> {
    params.id = id;
    return this.http.put(`${this.configService.config.apiBaseurl}/api/StockOperations/${id}`, params);
  }

  changeAuthorizationStatus(id: string, status: number): Observable<any> {
    return this.http.put(
      `${this.configService.config.apiBaseurl}/api/StockOperations/ChangeAuthorizationStatus/${id}/${status}`,
      {}
    );
  }

  // updateDividendTransaction(id: number, params: any): Observable<any> {
  //   return this.http.put(
  //     `${this.configService.config.apiBaseurl}/api/StockOperations/EditDividendPayoutTransaction/${id}`,
  //     params
  //   )
  // }

  getClientStockBalancesOnCounterparty({
    stockId,
    clientId
  }: {
    stockId: string | number;
    clientId: string | number;
  }): Observable<{ clientBalances: ClientStockBalance[] }> {
    return this.http.get<{ clientBalances: ClientStockBalance[] }>(
      `${
      this
        .configService
        .config
        .apiBaseurl
      }/api/StockOperations/GetClientStockBalancesOnCounterparty/${stockId}/${clientId}`
    );
  }

  getStockPrice(stockId, date): Observable<any> {
    return this.http.get<any>(`${this.configService.config.apiBaseurl}/api/Stocks/GetStockPrice`, {
      params: { stockId, date }
    });
  }

  exportExcel(): Observable<any> {
    return this.http.get(
      `${this.configService.config.apiBaseurl}/api/StockOperations/ExportStockOperationsWithTransaction`,
      {
        responseType: "blob"
      }
    );
  }
}
