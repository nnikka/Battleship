import { NgModule } from "@angular/core";
import { SharedModule } from "@shared/shared.module";
import { StockOperationsRoutingRoutingModule } from "./stock-operations-routing.module";
import { AddStockOperationComponent } from "./containers/add-stock-operation/add-stock-operation.component";
import { StockOperationComponent } from "./containers/stock-operation/stock-operation.component";
import { StockOperationsListComponent } from "./containers/stock-operations-list/stock-operations-list.component";
import {
  StockOperationsTypeSelectorComponent
} from "./components/stock-operations-type-selector/stock-operations-type-selector.component";
import { StockOperationFormComponent } from "./components/stock-operation-form/stock-operation-form.component";

import { StockOperationService } from "./services/stock-operation.service";
import {
  ClientStockBalanceCardComponent
} from "./components/client-stock-balance-card/client-stock-balance-card.component";
import { StockOperationCardComponent } from "./components/stock-operation-card/stock-operation-card.component";
import {
  StockOperationCommissionsFormComponent
} from "./components/stock-operation-commissions-form/stock-operation-commissions-form.component";

@NgModule({
  declarations: [
    AddStockOperationComponent,
    StockOperationComponent,
    StockOperationsListComponent,
    StockOperationsTypeSelectorComponent,
    StockOperationFormComponent,
    ClientStockBalanceCardComponent,
    StockOperationCardComponent,
    StockOperationCommissionsFormComponent
  ],
  imports: [SharedModule, StockOperationsRoutingRoutingModule],
  providers: [StockOperationService]
})
export class StockOperationsModule { }
