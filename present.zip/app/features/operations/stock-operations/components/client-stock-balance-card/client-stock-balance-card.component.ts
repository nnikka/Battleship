import { Component, OnInit, Input, ChangeDetectionStrategy } from "@angular/core";
import { ClientStockBalance } from "../../models/ClientStockBalance";
import { IntlService } from "@progress/kendo-angular-intl";

@Component({
  selector: "app-client-stock-balance-card",
  templateUrl: "./client-stock-balance-card.component.html",
  styleUrls: ["./client-stock-balance-card.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ClientStockBalanceCardComponent implements OnInit {
  @Input() balances: ClientStockBalance[];

  constructor(public intl: IntlService) {}

  ngOnInit() {}
}
