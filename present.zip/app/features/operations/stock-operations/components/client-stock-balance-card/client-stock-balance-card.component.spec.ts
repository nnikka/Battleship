import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { ClientStockBalanceCardComponent } from "./client-stock-balance-card.component";

describe("ClientStockBalanceCardComponent", () => {
  let component: ClientStockBalanceCardComponent;
  let fixture: ComponentFixture<ClientStockBalanceCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ClientStockBalanceCardComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientStockBalanceCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
