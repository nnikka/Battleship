import { IHttpStockOperation } from "../../models/IHttpStockOperation";
import { convertToDMY } from "src/utils/date-converter.helper";

export class StockOperationFormValue {
  operationType: number;
  tradeDate: string;
  settlementDate: string;
  stockSearchType: ["ticker"[]];
  stockId: number;
  clientId: number;
  clientCounterpartyId: number;
  numberOfShares: number;
  comment: string;
  sharePrice: number;

  tradeCommission: number;
  counterpartyCommission;
  tradeCommissionCurrencyId: number;
  counterpartyCommissionCurrencyId: number;

  additionalCommissions: [
    {
      amount: number;
      additionalCommissionNameId: number;
    }
  ];

  constructor(init?: IHttpStockOperation) {
    if (init) {
      this.operationType = init.operationType;
      this.stockId = init.stockId;
      this.clientId = init.clientId;
      this.clientCounterpartyId = init.clientCounterpartyId;
      this.numberOfShares = init.numberOfShares;
      this.comment = init.comment;
      this.sharePrice = init.sharePrice;
      this.tradeCommission = init.tradeCommission;
      this.counterpartyCommission = init.counterpartyCommission;
      this.tradeCommissionCurrencyId = init.tradeCommissionCurrencyId;
      this.counterpartyCommissionCurrencyId = init.counterpartyCommissionCurrencyId;
      this.additionalCommissions = init.additionalCommissions;
      if (init.tradeDate) {
        this.tradeDate = convertToDMY(init.tradeDate).toLocaleDateString();
      }
      if (init.settlementDate) {
        this.settlementDate = convertToDMY(init.settlementDate).toLocaleDateString();
      }
    }
  }
}
