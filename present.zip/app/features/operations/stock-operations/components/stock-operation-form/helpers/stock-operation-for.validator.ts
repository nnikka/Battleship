import { FormGroup, ValidatorFn, AbstractControl } from "@angular/forms";
import { ClientStockBalance } from "../../../models/ClientStockBalance";
import { EStockOperationTypes } from "../../../models/EStockOperationTypes";

export function StockOperationFormValidator() {
  return (formGroup: FormGroup) => {
    // Dates validation
    const tradeDateControl = formGroup.get("tradeDate");
    const settlementDateControl = formGroup.get("settlementDate");

    let tradeTime = null;
    let settlementTime = null;

    if (tradeDateControl.value) {
      tradeTime = new Date(tradeDateControl.value).getTime();
    }
    if (settlementDateControl.value) {
      settlementTime = new Date(settlementDateControl.value).getTime();
    }

    if (tradeTime && settlementTime && tradeTime > settlementTime) {
      settlementDateControl.setErrors({ settlementDateMustBeMoreOrEqualThenTradeDate: true });
    } else if (tradeTime && settlementTime && !(tradeTime > settlementTime)) {
      settlementDateControl.setErrors(null);
    }
  };
}

export function stockOperationSharesValidator(
  clientStockBalanceData: ClientStockBalance[],
  counterPartyId: number,
  operationType: number
): ValidatorFn {
  return (control: AbstractControl): { [key: string]: boolean } | null => {
    if (
      operationType === EStockOperationTypes.Buy ||
      operationType === EStockOperationTypes.Deposit ||
      operationType === EStockOperationTypes.Sell
    ) {
      return null;
    }
    if (clientStockBalanceData && counterPartyId) {
      let clinetHas: number = 0;
      clientStockBalanceData.map(csb => {
        if (csb.clientCounterpartyId === counterPartyId) {
          clinetHas = csb.quantity;
        }
      });
      if (control.value > clinetHas) {
        return { ClientDoesNotHasThisMuchStock: true };
      }
    }
    return null;
  };
}
