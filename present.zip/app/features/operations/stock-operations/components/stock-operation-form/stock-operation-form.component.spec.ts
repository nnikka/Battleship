import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { StockOperationFormComponent } from "./stock-operation-form.component";

describe("StockOperationFormComponent", () => {
  let component: StockOperationFormComponent;
  let fixture: ComponentFixture<StockOperationFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [StockOperationFormComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StockOperationFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
