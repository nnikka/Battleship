import { Component, OnInit, Input, Output, EventEmitter, OnDestroy, OnChanges } from "@angular/core";
import { FormGroup, FormBuilder, Validators, FormArray, FormControl } from "@angular/forms";
import { EStockAuthorizationStatuses } from "@features/static-data/stocks/models/stockAuthorizationStatuses.enu";
import { IStockOperationType } from "../../models/IStockOperationType";
import { EStockOperationTypes } from "../../models/EStockOperationTypes";
import { EClientStatuses } from "@features/static-data/clients/models/ClientStatuses.enum";
import { EClientTypes } from "@features/static-data/clients/models/ClientTypes.enum";
import { StockOperationFormValidator, stockOperationSharesValidator } from "./helpers/stock-operation-for.validator";
import { IAdditionalCommision } from "@core/models/catalogs/additionalCommision.interface";
import { StockOperationFormValue } from "./stockOperationFormValue";
import { IntlService } from "@progress/kendo-angular-intl";
import { ClientStockBalance } from "../../models/ClientStockBalance";
import { constructSelectItemsFromEnum } from "src/utils/array.helper";
import { ICurrency } from "@core/models/catalogs/currency.interface";
import { CustomDateValidators } from "src/app/general/validators/date.validator";
import { StockOperationService } from "../../services/stock-operation.service";
import { NotificationMessageService } from "@core/services/notification-message.service";
import { untilDestroyed } from "ngx-take-until-destroy";

@Component({
  selector: "app-stock-operation-form",
  templateUrl: "./stock-operation-form.component.html",
  styleUrls: ["./stock-operation-form.component.scss"]
})
export class StockOperationFormComponent implements OnInit, OnDestroy, OnChanges {
  @Input() initialFormValue: StockOperationFormValue;
  @Input() commissions: IAdditionalCommision[];
  @Input() operationType: number;
  @Input() clientStockBalanceData: ClientStockBalance[] = null;
  @Input() currencies: ICurrency[];

  @Output() formReady = new EventEmitter<FormGroup>();

  sharePriceIsLoading: boolean = false;

  form: FormGroup;
  operationTypes: IStockOperationType[];

  counterPartyIsDisabled: boolean = false;
  clientIsDisabled: boolean = false;

  stocksByTickerSelectRequiredHttpParams: any = {
    "filterItem.status": EStockAuthorizationStatuses.Authorized,
    SortBy: "ticker",
    SortDirection: 0
  };
  stocksByBloombergSelectRequiredHttpParams: any = {
    "filterItem.status": EStockAuthorizationStatuses.Authorized,
    SortBy: "bloombergName",
    SortDirection: 0
  };
  authorizedClientRequiredHttpParams: any = {
    "filterItem.status": EClientStatuses.Authorized,
    SortBy: "clientNameEng",
    SortDirection: 0
  };
  authorizedCounterpartiesRequiredHttpParams: any = {
    "filterItem.status": EClientStatuses.Authorized,
    "filterItem.clientTypes": EClientTypes.Counterparty,
    SortBy: "clientNameEng",
    SortDirection: 0
  };

  get typeIsSell(): boolean {
    return this.operationType === EStockOperationTypes.Sell;
  }

  get typeIsBuy(): boolean {
    return this.operationType === EStockOperationTypes.Buy;
  }

  get selectedCommissions(): { additionalCommissionNameId: number; amount: number }[] {
    return this.form.value.additionalCommissions;
  }

  get sharesSumPrice(): number {
    if (this.form.controls.sharePrice && this.form.controls.numberOfShares) {
      const sharepriceValue = this.form.controls.sharePrice.value;
      const numberOfSharesValue = this.form.controls.numberOfShares.value;
      if (sharepriceValue && numberOfSharesValue) {
        return sharepriceValue * numberOfSharesValue;
      }
    }
    return null;
  }

  // get commissionAmount(): number {
  //   if (this.form.controls['sharePrice']
  //    && this.form.controls['numberOfShares']
  //    && this.form.controls['tradeCommission']) {
  //     let sharepriceValue = this.form.controls['sharePrice'].value
  //     let numberOfSharesValue = this.form.controls['numberOfShares'].value
  //     let commissionValue = this.form.controls['tradeCommission'].value
  //     if (sharepriceValue && numberOfSharesValue && commissionValue)
  //       return sharepriceValue * numberOfSharesValue * commissionValue / 100
  //   }
  //   return null
  // }

  // get totalNetAmount(): number {
  //   let additionalCommissionsSum = 0
  //   if (this.form.value['additionalCommissions']) {
  //     this.form.value['additionalCommissions'].map(com => {
  //       additionalCommissionsSum += com.amount
  //     })
  //   }
  //   if (this.typeIsBuy && this.sharesSumPrice && this.commissionAmount) {
  //     return this.sharesSumPrice + additionalCommissionsSum + this.commissionAmount
  //   } else if (this.typeIsSell && this.sharesSumPrice && this.commissionAmount) {
  //     return this.sharesSumPrice - additionalCommissionsSum - this.commissionAmount
  //   }
  //   return null
  // }

  constructor(
    private formBuilder: FormBuilder,
    public intl: IntlService,
    private stockOperationService: StockOperationService,
    private notificationMessageService: NotificationMessageService
  ) {}

  ngOnInit() {
    this.operationTypes = constructSelectItemsFromEnum(EStockOperationTypes);
    this.form = this.formBuilder.group(
      {
        operationType: [
          {
            value: this.initialFormValue ? this.initialFormValue.operationType : this.operationType,
            disabled: true
          },
          [Validators.required]
        ],
        tradeDate: [
          this.initialFormValue
            ? this.initialFormValue.tradeDate
            : this.dateFormat(new Date().toISOString().slice(0, 10)),
          [Validators.required]
        ],
        settlementDate: [
          this.initialFormValue ? this.initialFormValue.settlementDate : null,
          [Validators.required, CustomDateValidators.minimumDateByDays(60)]
        ],
        stockSearchType: ["ticker", []],
        stockId: [this.initialFormValue ? this.initialFormValue.stockId : null, [Validators.required]],
        clientId: [this.initialFormValue ? this.initialFormValue.clientId : null, [Validators.required]],
        clientCounterpartyId: [
          this.initialFormValue ? this.initialFormValue.clientCounterpartyId : null,
          [Validators.required]
        ],
        numberOfShares: [
          this.initialFormValue ? this.initialFormValue.numberOfShares : null,
          [
            Validators.required,
            Validators.min(0.0001),
            stockOperationSharesValidator(
              this.clientStockBalanceData,
              this.initialFormValue ? this.initialFormValue.clientCounterpartyId : null,
              this.operationType
            )
          ]
        ],
        comment: [this.initialFormValue ? this.initialFormValue.comment : null, []]
      },
      { validators: [StockOperationFormValidator()] }
    );

    if (
      this.form.get("operationType").value === EStockOperationTypes.Buy ||
      this.form.get("operationType").value === EStockOperationTypes.Sell
    ) {
      this.form
        .get("stockId")
        .valueChanges.pipe(untilDestroyed(this))
        .subscribe(stockId => {
          this.handleSharePrice(stockId, this.form.get("tradeDate").value);
        });
      this.form
        .get("tradeDate")
        .valueChanges.pipe(untilDestroyed(this))
        .subscribe(tradeDate => {
          this.handleSharePrice(this.form.get("stockId").value, tradeDate);
        });
    }

    this.setInitialFieldDisableStatuses();
    this.handeFormDynamicPart();
    this.handleFieldSubscriptions();

    this.formReady.emit(this.form);
  }

  ngOnChanges(changes: import("@angular/core").SimpleChanges): void {
    if (changes.clientStockBalanceData && this.form && this.form.get("numberOfShares")) {
      this.form
        .get("numberOfShares")
        .setValidators(
          Validators.compose([
            Validators.required,
            Validators.min(0.0001),
            stockOperationSharesValidator(
              this.clientStockBalanceData,
              this.form.get("clientCounterpartyId") ? this.form.get("clientCounterpartyId").value : null,
              this.operationType
            )
          ])
        );
    }
  }

  ngOnDestroy(): void {}

  setInitialFieldDisableStatuses() {
    if (!this.form.get("stockId").value) {
      this.clientIsDisabled = true;
    }
    if (!this.form.get("clientId").value) {
      this.counterPartyIsDisabled = true;
    }
    if (!this.form.get("clientCounterpartyId").value) {
      this.form.get("numberOfShares").disable();
    }
  }

  handeFormDynamicPart() {
    if (this.typeIsBuy || this.typeIsSell) {
      this.form.addControl(
        "sharePrice",
        new FormControl(this.initialFormValue ? this.initialFormValue.sharePrice : null, [
          Validators.required,
          Validators.min(0.0001)
        ])
      );
      this.form.addControl(
        "tradeCommission",
        new FormControl(this.initialFormValue ? this.initialFormValue.tradeCommission : null, [Validators.required])
      );
      this.form.addControl(
        "tradeCommissionCurrencyId",
        new FormControl(this.initialFormValue ? this.initialFormValue.tradeCommissionCurrencyId : null, [
          Validators.required
        ])
      );
      this.form.addControl(
        "counterpartyCommission",
        new FormControl(this.initialFormValue ? this.initialFormValue.counterpartyCommission : null, [
          Validators.required
        ])
      );
      this.form.addControl(
        "counterpartyCommissionCurrencyId",
        new FormControl(this.initialFormValue ? this.initialFormValue.counterpartyCommissionCurrencyId : null, [
          Validators.required
        ])
      );

      this.form.addControl("additionalCommissions", this.formBuilder.array([]));
      if (this.initialFormValue && this.initialFormValue.additionalCommissions) {
        const control = this.form.controls.additionalCommissions as FormArray;
        this.initialFormValue.additionalCommissions.map(com => {
          control.push(
            this.formBuilder.group({
              additionalCommissionNameId: [com.additionalCommissionNameId, []],
              amount: [com.amount, []]
            })
          );
        });
      }
    }
  }

  handleFieldSubscriptions() {
    this.form
      .get("stockSearchType")
      .valueChanges.pipe(untilDestroyed(this))
      .subscribe(() => {
        this.form.get("stockId").setValue(null);
      });

    this.form
      .get("stockId")
      .valueChanges.pipe(untilDestroyed(this))
      .subscribe(val => {
        this.form.get("clientId").markAsUntouched();
        if (val) {
          this.clientIsDisabled = false;
        } else {
          this.clientIsDisabled = true;
        }
        this.form.get("clientId").setValue(null);
        if (
          // this.operationType === EStockOperationTypes.Sell ||
          this.operationType === EStockOperationTypes.Withdrawal
        ) {
          this.authorizedClientRequiredHttpParams = {
            ...this.authorizedClientRequiredHttpParams,
            "filterItem.stockHolderId": val
          };
        } else {
          this.authorizedClientRequiredHttpParams = {
            ...this.authorizedClientRequiredHttpParams,
            "filterItem.stockHolderId": null
          };
        }
      });

    this.form
      .get("clientId")
      .valueChanges.pipe(untilDestroyed(this))
      .subscribe(val => {
        this.form.get("clientCounterpartyId").markAsUntouched();
        if (val) {
          this.counterPartyIsDisabled = false;
        } else {
          this.counterPartyIsDisabled = true;
        }
        this.form.get("clientCounterpartyId").setValue(null);
      });

    this.form
      .get("clientCounterpartyId")
      .valueChanges.pipe(untilDestroyed(this))
      .subscribe(val => {
        this.form.get("numberOfShares").markAsUntouched();
        this.form.get("numberOfShares").markAsPristine();
        if (val) {
          this.form.get("numberOfShares").enable();
        } else {
          this.form.get("numberOfShares").disable();
        }
        this.form.get("numberOfShares").setValue(null);
        this.form
          .get("numberOfShares")
          .setValidators(
            Validators.compose([
              Validators.required,
              Validators.min(0.0001),
              stockOperationSharesValidator(
                this.clientStockBalanceData,
                this.form.get("clientCounterpartyId").value,
                this.operationType
              )
            ])
          );
      });
  }

  handleAddCommission(com: { additionalCommissionNameId: number; amount: number }) {
    const control = this.form.controls.additionalCommissions as FormArray;
    control.push(
      this.formBuilder.group({
        additionalCommissionNameId: [com.additionalCommissionNameId, []],
        amount: [com.amount, []]
      })
    );
    this.form.markAsDirty();
  }

  handleRemoveCommission(id: number) {
    if (this.form.value.additionalCommissions) {
      for (let i = 0; i < this.form.value.additionalCommissions.length; i++) {
        if (this.form.value.additionalCommissions[i].additionalCommissionNameId === id) {
          (this.form.controls.additionalCommissions as FormArray).removeAt(i);
          this.form.markAsDirty();
        }
      }
    }
  }

  handleSharePrice(stockId, date) {
    if (stockId && date) {
      this.sharePriceIsLoading = true;
      this.stockOperationService
        .getStockPrice(stockId, date)
        .pipe(untilDestroyed(this))
        .subscribe(
          resp => {
            if (resp) {
              this.form.get("sharePrice").setValue(resp);
              this.sharePriceIsLoading = false;
            } else {
              this.form.get("sharePrice").setValue(null);
              this.notificationMessageService.info("Stock share price for this date is not available");
              this.sharePriceIsLoading = false;
            }
          },
          () => {
            this.form.get("sharePrice").setValue(null);
            this.sharePriceIsLoading = false;
          }
        );
    } else {
      this.form.get("sharePrice").setValue(null);
    }
  }

  dateFormat(date) {
    const split = date.split("-");
    return split[1] + "/" + split[2] + "/" + split[0];
  }
}
