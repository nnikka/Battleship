import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { StockOperationCardComponent } from "./stock-operation-card.component";

describe("StockOperationCardComponent", () => {
  let component: StockOperationCardComponent;
  let fixture: ComponentFixture<StockOperationCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [StockOperationCardComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StockOperationCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
