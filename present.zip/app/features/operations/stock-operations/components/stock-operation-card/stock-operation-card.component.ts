import { Component, OnInit, Input, ChangeDetectionStrategy } from "@angular/core";
import { IHttpStockOperation } from "../../models/IHttpStockOperation";
import { IntlService } from "@progress/kendo-angular-intl";
import { EStockOperationTypes } from "../../models/EStockOperationTypes";
import { IHttpStock } from "@features/static-data/stocks/models/IHttpStock";

@Component({
  selector: "app-stock-operation-card",
  templateUrl: "./stock-operation-card.component.html",
  styleUrls: ["./stock-operation-card.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class StockOperationCardComponent implements OnInit {
  @Input() stockOperation: IHttpStockOperation;
  @Input() stockData: IHttpStock;

  isTradeOrSell: boolean = false;
  totalSumShares: number;
  commission: number;
  totalNetAMount: number;

  constructor(public intl: IntlService) { }

  ngOnInit() {
    if (
      this.stockOperation.operationType === EStockOperationTypes.Sell ||
      this.stockOperation.operationType === EStockOperationTypes.Buy
    ) {
      this.isTradeOrSell = true;
    }
    if (this.isTradeOrSell) {
      this.totalSumShares = this.stockOperation.sharePrice * this.stockOperation.numberOfShares;
      this.commission = (this.totalSumShares * this.stockOperation.tradeCommission) / 100;
      let additionalCommissions = 0;
      this.stockOperation.additionalCommissions.map(com => {
        additionalCommissions += com.amount;
      });
      if (this.stockOperation.operationType === EStockOperationTypes.Sell) {
        this.totalNetAMount = this.totalSumShares - this.commission - additionalCommissions;
      } else if (this.stockOperation.operationType === EStockOperationTypes.Buy) {
        this.totalNetAMount = this.totalSumShares + this.commission + additionalCommissions;
      }
    }
  }
}
