import { Component, OnInit, ChangeDetectionStrategy } from "@angular/core";
import { Router } from "@angular/router";

@Component({
  selector: "app-stock-operations-type-selector",
  templateUrl: "./stock-operations-type-selector.component.html",
  styleUrls: ["./stock-operations-type-selector.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class StockOperationsTypeSelectorComponent implements OnInit {
  stockOperationTypes: string[] = ["Buy", "Sell", "Withdrawal", "Deposit"];
  selectedType: string = null;

  constructor(private router: Router) {}

  ngOnInit() {}

  redirectToAddBond(e) {
    this.router.navigate(["admin/operations/stocks/add-stock-operation", { operationType: e }]);
  }
}
