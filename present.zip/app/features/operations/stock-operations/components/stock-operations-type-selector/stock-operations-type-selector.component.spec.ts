import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { StockOperationsTypeSelectorComponent } from "./stock-operations-type-selector.component";

describe("StockOperationsTypeSelectorComponent", () => {
  let component: StockOperationsTypeSelectorComponent;
  let fixture: ComponentFixture<StockOperationsTypeSelectorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [StockOperationsTypeSelectorComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StockOperationsTypeSelectorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
