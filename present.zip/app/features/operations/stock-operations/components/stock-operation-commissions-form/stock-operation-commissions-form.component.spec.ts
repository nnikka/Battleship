import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { StockOperationCommissionsFormComponent } from "./stock-operation-commissions-form.component";

describe("StockOperationCommissionsFormComponent", () => {
  let component: StockOperationCommissionsFormComponent;
  let fixture: ComponentFixture<StockOperationCommissionsFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [StockOperationCommissionsFormComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StockOperationCommissionsFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
