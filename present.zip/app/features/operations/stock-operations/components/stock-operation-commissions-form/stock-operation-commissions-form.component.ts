import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { IAdditionalCommision } from "@core/models/catalogs/additionalCommision.interface";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { IntlService } from "@progress/kendo-angular-intl";
import { getObjectParamFromArray } from "src/utils/array.helper";

@Component({
  selector: "app-stock-operation-commissions-form",
  templateUrl: "./stock-operation-commissions-form.component.html",
  styleUrls: ["./stock-operation-commissions-form.component.scss"]
})
export class StockOperationCommissionsFormComponent implements OnInit {
  @Input() commissions: IAdditionalCommision[];
  @Input() selectedCommissions: { additionalCommissionNameId: number; amount: number }[] = [];

  @Output() addCommission = new EventEmitter<{ additionalCommissionNameId: number; amount: number }>();
  @Output() removeCommission = new EventEmitter<number>();

  form: FormGroup;

  get selectOptions(): IAdditionalCommision[] {
    return this.commissions.filter(com => {
      for (const selectedCommission of this.selectedCommissions) {
        if (selectedCommission.additionalCommissionNameId === com.id) {
          return false;
        }
      }
      return true;
    });
  }

  constructor(private formBuilder: FormBuilder, public intl: IntlService) {}

  ngOnInit() {
    this.form = this.formBuilder.group({
      additionalCommissionNameId: [null, [Validators.required]],
      amount: [null, [Validators.required, Validators.min(0.0001)]]
    });
  }

  handleAddCommission() {
    this.addCommission.emit(this.form.value);
    this.form.reset();
  }

  handleRemoveCommission(commissionId) {
    this.removeCommission.emit(commissionId);
  }

  getCommissionNameById(id): string {
    return getObjectParamFromArray(this.commissions, id);
  }

  selectedCommissionsContainId(id) {
    this.selectedCommissions.map(com => {
      if (com.additionalCommissionNameId === id) {
        return true;
      }
    });
    return false;
  }
}
