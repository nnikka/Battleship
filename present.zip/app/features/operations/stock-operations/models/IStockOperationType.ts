export interface IStockOperationType {
  name: string;
  value: number;
}
