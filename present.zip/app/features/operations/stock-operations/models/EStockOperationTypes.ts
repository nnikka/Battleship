export enum EStockOperationTypes {
  Buy = 1,
  Sell = 2,
  Withdrawal = 4,
  Deposit = 8
}
