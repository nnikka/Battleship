export class StockOperationParams {
  id: number;
  audit: {
    createUserId: number;
    createUserFullName: string;
    lastModifiedUserId: number;
    lastModifiedUserFullName: string;
    createDate: string;
    lastModifiedDate: string;
    status: number;
  };
  operationType: number;
  tradeDate: string;
  settlementDate: string;
  stockId: number;
  clientId: number;
  clientCounterpartyId: number;
  numberOfShares: number;
  comment: string;
}
