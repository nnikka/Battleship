export interface IStockOperationListItem {
  audit: {
    createDate: string;
    createUserFullName: string;
    createUserId: number;
    lastModifiedDate: string;
    lastModifiedUserFullName: string;
    lastModifiedUserId: string;
    status: number;
  };
  clientName: string;
  createUserFullName: string;
  id: number;
  numberOfShares: number;
  settlementDate: string;
  status: string;
  stockOperationBloombergName: string;
  stockOperationTicker: string;
  tradeDate: string;
  operationType: string;
  clientCounterpartyName: string;
}
