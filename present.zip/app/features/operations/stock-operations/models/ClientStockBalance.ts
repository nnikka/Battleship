export interface ClientStockBalance {
  clientCounterpartyId: 6;
  clientCounterpartyName: "counter";
  id: 3;
  quantity: 1;
}
