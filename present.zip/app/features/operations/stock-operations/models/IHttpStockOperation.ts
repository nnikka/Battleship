export interface IHttpStockOperation {
  id: number;
  audit: {
    createUserId: number;
    createUserFullName: string;
    lastModifiedUserId: number;
    lastModifiedUserFullName: string;
    createDate: string;
    lastModifiedDate: string;
    status: number;
  };
  operationType: number;
  operationTypeName: string;
  tradeDate: string;
  settlementDate: string;
  stockId: number;
  stockOperationBloombergName: string;
  clientId: number;
  clientName: string;
  clientCounterpartyId: number;
  clientCounterpartyName: string;
  numberOfShares: number;
  comment: string;
  sharePrice: number;
  tradeCommission: number;
  counterpartyCommission;
  tradeCommissionCurrencyId: number;
  counterpartyCommissionCurrencyId: number;
  counterpartyCommissionCurrencyName: string;
  tradeCommissionCurrencyName: string;
  additionalCommissions: [
    {
      amount: number;
      additionalCommissionNameId: number;
      additionalCommissionName: string;
    }
  ];
}
