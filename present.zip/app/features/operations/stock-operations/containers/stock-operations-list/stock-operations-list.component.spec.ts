import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { StockOperationsListComponent } from "./stock-operations-list.component";

describe("StockOperationsListComponent", () => {
  let component: StockOperationsListComponent;
  let fixture: ComponentFixture<StockOperationsListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [StockOperationsListComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StockOperationsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
