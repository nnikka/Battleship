import { Component, OnInit, OnDestroy } from "@angular/core";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import { Router, ActivatedRoute } from "@angular/router";
import { IntlService } from "@progress/kendo-angular-intl";
import {
  EStockOperationAuthorizationStatusesColors,
  EStockOperationAuthorizationStatuses
} from "../../models/EStockOperationAuthorizationStatuses";
import { StockOperationService } from "../../services/stock-operation.service";
import { constructSelectItemsFromEnum } from "src/utils/array.helper";
import { EStockOperationTypes } from "../../models/EStockOperationTypes";
import { EOperationStatus, EOperationStatusColor } from "@core/models/enums/EOperationStatus";
import { FileDownloadService } from "@core/services/file-download.service";
import { formatDate } from "@telerik/kendo-intl";
import { untilDestroyed } from "ngx-take-until-destroy";
import { IColumn } from "@shared/components/complex-grid/interfaces/IColumn";
import { IOptions } from "@shared/components/complex-grid/interfaces/IOptions";

@Component({
  selector: "app-stock-operations-list",
  templateUrl: "./stock-operations-list.component.html",
  styleUrls: ["./stock-operations-list.component.scss"]
})
export class StockOperationsListComponent implements OnInit, OnDestroy {
  breadcrumbItems: IBreadcrumb[] = [
    { text: "Operations", to: null },
    { text: "Stocks", to: null }
  ];
  stockOperationAuthorizationStatuses: { key: string; value: number }[];
  stockOperationStatuses: { key: string; value: number }[];
  operationTypes: { key: string; value: number }[];

  columns: IColumn[];
  options: IOptions = {
    tableKey: "StockOperationsList",
    columnsTooboxEnable: true,
    dblClickEnable: true,
    detailShowEnable: true
  };

  excelIsDownloading: boolean = false;

  constructor(
    private stockOperationService: StockOperationService,
    public intl: IntlService,
    private fileDownloadService: FileDownloadService
  ) { }

  ngOnInit() {
    this.stockOperationAuthorizationStatuses = constructSelectItemsFromEnum(EStockOperationAuthorizationStatuses);
    this.operationTypes = constructSelectItemsFromEnum(EStockOperationTypes);
    this.stockOperationStatuses = constructSelectItemsFromEnum(EOperationStatus);

    this.columns = [
      {
        key: "id",
        name: "ID",
        type: "number",
        filterConfig: {
          filterType: "number"
        }
      },
      {
        // addSpaces(dataItem.operationType)
        key: "operationStatus",
        name: "Operation Status",
        type: "string",
        style: {
          colorsMapping: EOperationStatusColor,
          conditionalColor: true
        },
        filterConfig: {
          filterData: this.stockOperationStatuses,
          filterType: "dropdown"
        }
      },
      {
        // addSpaces(dataItem.operationType)
        key: "operationType",
        name: "Operation type",
        type: "string",
        filterConfig: {
          filterData: this.operationTypes,
          filterType: "dropdown"
        }
      },
      {
        key: "stockOperationTicker",
        name: "Ticker",
        type: "string",
        filterConfig: {
          filterType: "string"
        }
      },
      {
        key: "tradeDate",
        name: "Trade date",
        type: "date",
        filterConfig: {
          filterType: "date"
        }
      },

      {
        key: "clientName",
        name: "Client",
        type: "string",
        filterConfig: {
          filterType: "string"
        }
      },
      {
        key: "numberOfShares",
        name: "Shares",
        type: "number",
        filterConfig: {
          filterType: "number"
        }
      },
      {
        key: "createUserFullName",
        name: "Created by",
        type: "string",
        filterConfig: {
          filterType: "string"
        }
      },
      {
        key: "status",
        name: "Authorization Status",
        type: "string",
        style: {
          colorsMapping: EStockOperationAuthorizationStatusesColors,
          conditionalColor: true,
          isCard: true
        },
        filterConfig: {
          filterData: this.stockOperationAuthorizationStatuses,
          filterType: "dropdown"
        }
      }
    ];
  }

  exportExcel() {
    this.excelIsDownloading = true;
    this.stockOperationService
      .exportExcel()
      .pipe(untilDestroyed(this))
      .subscribe(response => {
        this.excelIsDownloading = false;
        this.fileDownloadService.downLoadFile(
          `${formatDate(new Date(), "MM/dd/yyyy")} stock-operations.xlsx`,
          response
        );
      });
  }

  authorizationStatusColor(status: string) {
    return EStockOperationAuthorizationStatusesColors[status];
  }

  operationStatusColor(status: string): string {
    return status ? EOperationStatusColor[status] : null;
  }

  ngOnDestroy() { }
}
