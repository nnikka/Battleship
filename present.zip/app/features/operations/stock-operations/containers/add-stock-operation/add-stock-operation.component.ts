import { Component, OnInit, OnDestroy } from "@angular/core";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import { FormGroup } from "@angular/forms";
import { IHttpStock } from "@features/static-data/stocks/models/IHttpStock";
import { StockOperationService } from "../../services/stock-operation.service";
import { EStockOperationTypes } from "../../models/EStockOperationTypes";
import { ActivatedRoute, Router } from "@angular/router";
import { Store, select } from "@ngrx/store";
import { selectCurrencies, selectCurrencyLoadStatus } from "@core/store/currency/currency.selector";
import { selectAuthorizedIssuers, selectIssuerLoadStatus } from "@core/store/issuer/issuer.selector";
import { IAppState } from "@core/store/app.state";
import { FadeInOutAnimation } from "src/app/general/animations/fadeInOut.animation";
import { MarkFormGroupTouched } from "src/utils/mark-formgroup-touched.helper";
import { NotificationMessageService } from "@core/services/notification-message.service";
import { PopupConfirmService } from "@components/popup-confirm/popup-confirm.service";
import { ClientStockBalance } from "../../models/ClientStockBalance";
import { ChangesDetector } from "src/app/general/abstractClasses/ChangesDetector.abstractClass";
import {
  selectAdditionalCommissions,
  selectAdditionalCommissionLoadStatus
} from "@core/store/additionalCommission/additionalCommission.selector";
import { untilDestroyed } from "ngx-take-until-destroy";

@Component({
  selector: "app-add-stock-operation",
  templateUrl: "./add-stock-operation.component.html",
  styleUrls: ["./add-stock-operation.component.scss"],
  animations: [FadeInOutAnimation]
})
export class AddStockOperationComponent extends ChangesDetector implements OnInit, OnDestroy {
  constructor(
    private store: Store<IAppState>,
    private stockOperationService: StockOperationService,
    private route: ActivatedRoute,
    private router: Router,
    private notificationMessageService: NotificationMessageService,
    private popupConfirmService: PopupConfirmService
  ) {
    super();
    if (this.router.getCurrentNavigation() && this.router.getCurrentNavigation().extras.state) {
      this.stockDataFromRoute = this.router.getCurrentNavigation().extras.state.data;
    }
  }

  breadcrumbItems: IBreadcrumb[] = [
    { text: "Operations", to: null },
    { text: "Stocks", to: "/admin/operations/stocks" },
    { text: "Add operation", to: null }
  ];

  currencies$ = this.store.pipe(select(selectCurrencies));
  currenciesLoaded = this.store.pipe(select(selectCurrencyLoadStatus));
  issuers$ = this.store.pipe(select(selectAuthorizedIssuers));
  issuersLoaded$ = this.store.pipe(select(selectIssuerLoadStatus));
  additionalCommissions$ = this.store.pipe(select(selectAdditionalCommissions));
  additionalCommissionsLoaded$ = this.store.pipe(select(selectAdditionalCommissionLoadStatus));

  loading: boolean = false;
  operationType: number;
  form: FormGroup;

  stockIsLoading: boolean = false;
  stockData: IHttpStock = null;

  clientStockBalanceIsLoading: boolean = false;
  clientStockBalanceData: ClientStockBalance[] = null;
  stockDataFromRoute;

  hasUnsavedChanges(): boolean {
    if (this.form) {
      return this.form.dirty;
    }
    return false;
  }

  ngOnInit() {
    if (this.route.snapshot.paramMap.get("operationType")) {
      this.operationType = EStockOperationTypes[this.route.snapshot.paramMap.get("operationType")];
      if (!this.operationType) {
        this.router.navigateByUrl("/not-found", { replaceUrl: true });
      }
    }
  }

  handleRegister() {
    if (this.form && !this.form.valid) {
      MarkFormGroupTouched(this.form.controls);
      this.notificationMessageService.error(
        "Form is invalid, please make sure all required fields are filled out correctly"
      );
    } else if (this.form && this.form.valid) {
      this.popupConfirmService.show(null, null, () => {
        this.loading = true;
        this.stockOperationService
          .create(this.form.getRawValue())
          .pipe(untilDestroyed(this))
          .subscribe(
            () => {
              this.form.reset();
              this.form.markAsPristine();
              this.router.navigate(["admin/operations/stocks"]);
              this.notificationMessageService.success("Stock operation has been added successfully");
            },
            () => {
              this.loading = false;
            }
          );
      });
    }
  }

  formInitialized(form: FormGroup) {
    this.form = form;
    this.form
      .get("stockId")
      .valueChanges.pipe(untilDestroyed(this))
      .subscribe(stockId => {
        if (stockId) {
          this.stockIsLoading = true;
          this.stockOperationService
            .getStockById(stockId)
            .pipe(untilDestroyed(this))
            .subscribe(stockData => {
              this.stockData = stockData;
              this.stockIsLoading = false;
            });
        } else {
          this.stockIsLoading = false;
          this.stockData = null;
        }
        this.getClientStockBalances(stockId, this.form.get("clientId").value);
      });
    this.form
      .get("clientId")
      .valueChanges.pipe(untilDestroyed(this))
      .subscribe(clientId => {
        this.getClientStockBalances(this.form.get("stockId").value, clientId);
      });

    if (this.stockDataFromRoute) {
      this.form.get("stockId").setValue(this.stockDataFromRoute.id);
      this.form.get("stockId").markAsDirty();
    }
  }

  getClientStockBalances(stockId: number | string, clientId: number | string) {
    if (stockId && clientId) {
      this.clientStockBalanceIsLoading = true;
      this.stockOperationService
        .getClientStockBalancesOnCounterparty({ stockId, clientId })
        .pipe(untilDestroyed(this))
        .subscribe(balances => {
          this.clientStockBalanceData = balances.clientBalances;
          this.clientStockBalanceIsLoading = false;
        });
    } else {
      this.clientStockBalanceIsLoading = false;
      this.clientStockBalanceData = null;
    }
  }

  ngOnDestroy() {}
}
