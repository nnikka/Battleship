import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { AddStockOperationComponent } from "./add-stock-operation.component";

describe("AddStockOperationComponent", () => {
  let component: AddStockOperationComponent;
  let fixture: ComponentFixture<AddStockOperationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AddStockOperationComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddStockOperationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
