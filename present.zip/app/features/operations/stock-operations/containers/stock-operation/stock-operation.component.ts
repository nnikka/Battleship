import { Component, OnInit, OnDestroy } from "@angular/core";
import { ChangesDetector } from "src/app/general/abstractClasses/ChangesDetector.abstractClass";
import { select, Store } from "@ngrx/store";
import { selectCurrencies, selectCurrencyLoadStatus } from "@core/store/currency/currency.selector";
import { selectAuthorizedIssuers, selectIssuerLoadStatus } from "@core/store/issuer/issuer.selector";
import { FormGroup } from "@angular/forms";
import { IAppState } from "@core/store/app.state";
import { StockOperationService } from "../../services/stock-operation.service";
import { ActivatedRoute, Router } from "@angular/router";
import { NotificationMessageService } from "@core/services/notification-message.service";
import { PopupConfirmService } from "@components/popup-confirm/popup-confirm.service";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import {
  EStockOperationAuthorizationStatusesColors,
  EStockOperationAuthorizationStatuses
} from "../../models/EStockOperationAuthorizationStatuses";
import { AuthService } from "@auth/services/auth.service";
import { IHttpStock } from "@features/static-data/stocks/models/IHttpStock";
import { ClientStockBalance } from "../../models/ClientStockBalance";
import { StockOperationFormValue } from "../../components/stock-operation-form/stockOperationFormValue";
import { MarkFormGroupTouched } from "src/utils/mark-formgroup-touched.helper";
import { FadeInOutAnimation } from "src/app/general/animations/fadeInOut.animation";
import {
  selectAdditionalCommissions,
  selectAdditionalCommissionLoadStatus
} from "@core/store/additionalCommission/additionalCommission.selector";
import { ICountDownResult, TimerService } from "@core/services/timer.service";
import { EOperationStatus, EOperationStatusColor } from "@core/models/enums/EOperationStatus";
import { OperationService, EOperationType } from "@core/services/operation.service";
import { untilDestroyed } from "ngx-take-until-destroy";

@Component({
  selector: "app-stock-operation",
  templateUrl: "./stock-operation.component.html",
  styleUrls: ["./stock-operation.component.scss"],
  animations: [FadeInOutAnimation]
})
export class StockOperationComponent extends ChangesDetector implements OnInit, OnDestroy {
  get transactionTimingColor(): string {
    if (this.transactionTiming && this.transactionTiming.expired) {
      return "#fb311c";
    }
    return "#28a745";
  }

  get stockOperationAuthorizationStatus() {
    return this.stockOperationData ? EStockOperationAuthorizationStatuses[this.stockOperationData.audit.status] : null;
  }

  get isStockOperationkAuthorized() {
    return this.stockOperationData
      ? EStockOperationAuthorizationStatuses.Authorized === this.stockOperationData.audit.status
      : false;
  }

  get isStockOperationkUnauthorized() {
    return this.stockOperationData
      ? EStockOperationAuthorizationStatuses.Unauthorized === this.stockOperationData.audit.status
      : false;
  }

  get operationStatus(): string {
    if (this.stockOperationData) {
      return EOperationStatus[this.stockOperationData.operationStatus];
    }
    return null;
  }

  get canAuthorize() {
    if (this.formIsUpdatedSuccessfully) {
      return false;
    }
    if (this.stockOperationData) {
      const lastUserId = this.stockOperationData.audit.lastModifiedUserId
        ? this.stockOperationData.audit.lastModifiedUserId
        : this.stockOperationData.audit.createUserId;
      if (lastUserId !== Number(this.authService.getUserId())) {
        return true;
      }
    }
    return null;
  }

  get canDeauthorize(): boolean {
    if (this.stockOperationData && this.stockOperationData.operationStatus === EOperationStatus.Success) {
      return false;
    }
    return true;
  }

  get isOperationSucceed(): boolean {
    if (this.stockOperationData) {
      return this.stockOperationData.operationStatus === EOperationStatus.Success;
    }
    return false;
  }

  get isOperationCanceled(): boolean {
    if (this.stockOperationData) {
      return this.stockOperationData.operationStatus === EOperationStatus.Canceled;
    }
    return false;
  }

  get initialFormValue(): StockOperationFormValue {
    return new StockOperationFormValue(this.stockOperationData);
  }

  get isStockOperationStatusPending(): boolean {
    return this.stockOperationData && this.stockOperationData.operationStatus === EOperationStatus.Pending;
  }

  get isExecutionOfTransactionsAvailable(): boolean {
    if (
      this.stockOperationData &&
      (this.stockOperationData.operationStatus === EOperationStatus.Pending ||
        this.stockOperationData.operationStatus === EOperationStatus.Fail)
    ) {
      const pattern = /(\d{2})\.(\d{2})\.(\d{4})/;
      const settlementDate = new Date(this.stockOperationData.settlementDate.replace(pattern, "$3-$2-$1")).getTime();
      if (settlementDate < Date.now()) {
        return true;
      }
    }
    return false;
  }

  constructor(
    private store: Store<IAppState>,
    private stockOperationService: StockOperationService,
    private route: ActivatedRoute,
    private router: Router,
    private notificationMessageService: NotificationMessageService,
    private popupConfirmService: PopupConfirmService,
    private authService: AuthService,
    private timerService: TimerService,
    private operationService: OperationService
  ) {
    super();
  }

  breadcrumbItems: IBreadcrumb[] = [
    { text: "Operations", to: null },
    { text: "Stocks", to: "/admin/operations/stocks" },
    { text: "Stock Operation", to: null }
  ];

  currencies$ = this.store.pipe(select(selectCurrencies));
  currenciesLoaded = this.store.pipe(select(selectCurrencyLoadStatus));
  issuers$ = this.store.pipe(select(selectAuthorizedIssuers));
  issuersLoaded$ = this.store.pipe(select(selectIssuerLoadStatus));
  additionalCommissions$ = this.store.pipe(select(selectAdditionalCommissions));
  additionalCommissionsLoaded$ = this.store.pipe(select(selectAdditionalCommissionLoadStatus));

  loading: boolean = false;
  operationType: number;
  form: FormGroup;

  stockOperationId: string;
  authorizationIsDisabled: boolean = false;
  stockOperationDataIsLoading: boolean = true;
  stockOperationData: any = null;

  stockIsLoading: boolean = false;
  stockData: IHttpStock = null;

  clientStockBalanceIsLoading: boolean = false;
  clientStockBalanceData: ClientStockBalance[] = null;

  transactionTiming: ICountDownResult;
  transactionTimingInterval;

  formIsUpdatedSuccessfully: boolean = false;

  hasUnsavedChanges(): boolean {
    if (this.form) {
      return this.form.dirty;
    }
    return false;
  }

  ngOnInit() {
    this.route.paramMap.pipe(untilDestroyed(this)).subscribe(paramsAsMap => {
      this.stockOperationId = paramsAsMap.get("id");
      this.loadStockOperation(this.stockOperationId);
    });
    this.transactionTimingInterval = setInterval(() => {
      if (
        this.stockOperationData &&
        this.stockOperationData.settlementDate &&
        this.stockOperationData.operationStatus === EOperationStatus.Pending
      ) {
        this.transactionTiming = this.timerService.countDown(this.stockOperationData.settlementDate);
      }
    }, 1000);
  }

  ngOnDestroy() {
    if (this.transactionTimingInterval) {
      clearInterval(this.transactionTimingInterval);
    }
  }

  formInitialized(form: FormGroup) {
    this.form = form;
    this.form
      .get("stockId")
      .valueChanges.pipe(untilDestroyed(this))
      .subscribe(stockId => {
        this.getStock(stockId, this.form.get("clientId").value);
      });
    this.form
      .get("clientId")
      .valueChanges.pipe(untilDestroyed(this))
      .subscribe(clientId => {
        this.getClientStockBalances(this.form.get("stockId").value, clientId);
      });
    this.getStock(this.form.get("stockId").value, null);
    this.getClientStockBalances(this.form.get("stockId").value, this.form.get("clientId").value);
  }

  getStock(stockId, clientId) {
    if (stockId) {
      this.stockIsLoading = true;
      this.stockOperationService
        .getStockById(stockId)
        .pipe(untilDestroyed(this))
        .subscribe(stockData => {
          this.stockData = stockData;
          this.stockIsLoading = false;
        });
    } else {
      this.stockIsLoading = false;
      this.stockData = null;
    }
    if (clientId) {
      this.getClientStockBalances(stockId, clientId);
    }
  }

  getClientStockBalances(stockId: number | string, clientId: number | string) {
    if (stockId && clientId) {
      this.clientStockBalanceIsLoading = true;
      this.stockOperationService
        .getClientStockBalancesOnCounterparty({ stockId, clientId })
        .pipe(untilDestroyed(this))
        .subscribe(balances => {
          this.clientStockBalanceData = balances.clientBalances;
          this.clientStockBalanceIsLoading = false;
        });
    } else {
      this.clientStockBalanceIsLoading = false;
      this.clientStockBalanceData = null;
    }
  }

  authorizationStatusColor(status: string): string {
    return status ? EStockOperationAuthorizationStatusesColors[status] : null;
  }

  operationStatusColor(status: string): string {
    return status ? EOperationStatusColor[status] : null;
  }

  loadStockOperation(stockOperationId: string) {
    this.stockOperationDataIsLoading = true;
    this.stockOperationService
      .getById(stockOperationId)
      .pipe(untilDestroyed(this))
      .subscribe(
        stockOperation => {
          this.stockOperationData = stockOperation;
          this.stockOperationDataIsLoading = false;
          this.operationType = stockOperation.operationType;
          if (this.isStockOperationkAuthorized) {
            this.getStock(stockOperation.stockId, null);
            this.getClientStockBalances(stockOperation.stockId, stockOperation.clientId);
          }
        },
        err => {
          this.router.navigateByUrl("/not-found", { replaceUrl: true });
        }
      );
  }

  handleUpdate() {
    if (!this.form.dirty) {
      this.notificationMessageService.info("Nothing is changed");
    } else {
      if (!this.form.valid) {
        MarkFormGroupTouched(this.form.controls);
        this.notificationMessageService.error(
          "Form is invalid, please make sure all required fields are filled out correctly"
        );
      } else {
        this.popupConfirmService.show(null, null, () => {
          this.loading = true;
          this.stockOperationDataIsLoading = true;
          this.stockOperationService
            .update(this.stockOperationId, this.form.getRawValue())
            .pipe(untilDestroyed(this))
            .subscribe(
              resp => {
                // this.form.reset();
                this.form.markAsPristine();
                this.formIsUpdatedSuccessfully = true;
                this.loading = false;
                this.stockOperationDataIsLoading = false;
                // this.router.navigate(["admin/operations/stocks"]);
                this.notificationMessageService.success("Stock operation has been updated successfully");
              },
              err => {
                this.loading = false;
                this.stockOperationDataIsLoading = false;
              }
            );
        });
      }
    }
  }

  handleChangeAuthorize(status: string, message: string) {
    if (this.form && this.form.dirty) {
      this.notificationMessageService.warn(
        "Form is changed, if you want to change authorization status please update the form first"
      );
      return;
    }
    this.popupConfirmService.show(null, null, () => {
      this.authorizationIsDisabled = true;
      this.stockOperationDataIsLoading = true;
      this.stockOperationService
        .changeAuthorizationStatus(this.stockOperationId, EStockOperationAuthorizationStatuses[status])
        .pipe(untilDestroyed(this))
        .subscribe(
          resp => {
            this.authorizationIsDisabled = false;
            this.stockOperationDataIsLoading = false;
            this.loadStockOperation(this.stockOperationId);
            this.notificationMessageService.success(message);
          },
          err => {
            this.authorizationIsDisabled = false;
            this.stockOperationDataIsLoading = false;
          }
        );
    });
  }

  handleExecuteTransactions() {
    this.popupConfirmService.show(null, null, () => {
      this.loading = true;
      this.operationService
        .makeOperationTransactions(this.stockOperationId, EOperationType.Stock)
        .pipe(untilDestroyed(this))
        .subscribe(
          resp => {
            this.loadStockOperation(this.stockOperationId);
            this.loading = false;
          },
          err => {
            this.loadStockOperation(this.stockOperationId);
            this.loading = false;
          }
        );
    });
  }
}
