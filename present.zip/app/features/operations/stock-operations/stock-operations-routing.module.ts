import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { AddStockOperationComponent } from "./containers/add-stock-operation/add-stock-operation.component";
import { StockOperationComponent } from "./containers/stock-operation/stock-operation.component";
import { StockOperationsListComponent } from "./containers/stock-operations-list/stock-operations-list.component";

import { ConfirmDeactivateGuard } from "@core/guards/confirm-deactivate-guard.guard";

import { CurrencyResolver } from "@core/resolvers/catalogs/currency.resolver";
import { IssuerResolver } from "@core/resolvers/catalogs/issuer.resolver";
import { AdditionalCommissionResolver } from "@core/resolvers/catalogs/additionalCommission.resolver";

const routes: Routes = [
  {
    path: "",
    component: StockOperationsListComponent
  },
  {
    path: "add-stock-operation",
    component: AddStockOperationComponent,
    canDeactivate: [ConfirmDeactivateGuard],
    resolve: {
      currency: CurrencyResolver,
      issuers: IssuerResolver,
      additionalCommission: AdditionalCommissionResolver
    }
  },
  {
    path: ":id",
    component: StockOperationComponent,
    canDeactivate: [ConfirmDeactivateGuard],
    resolve: {
      currency: CurrencyResolver,
      issuers: IssuerResolver,
      additionalCommission: AdditionalCommissionResolver
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StockOperationsRoutingRoutingModule {}
