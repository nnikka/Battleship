import { Component, OnInit, Input, OnChanges } from "@angular/core";
import { IBondOperationCashFlowItem } from "../../models/IBondOperationCashFlowItem";
import { CashFlowTypes } from "../../models/CashFlowTypes";
import { IntlService } from "@progress/kendo-angular-intl";

@Component({
  selector: "app-bond-operation-trade-settlement-calculation",
  templateUrl: "./bond-operation-trade-settlement-calculation.component.html",
  styleUrls: ["./bond-operation-trade-settlement-calculation.component.scss"]
})
export class BondOperationTradeSettlementCalculationComponent implements OnInit, OnChanges {
  @Input() currency: string;
  @Input() sellerId: number;
  @Input() buyerId: number;
  @Input() data: IBondOperationCashFlowItem[];
  @Input() loading: boolean;

  buyerPrincipal: number = null;
  buyerAccruedCoupon: number = null;
  buyerFee: number = null;
  buyerSettlementAmount: number = null;

  sellerPrincipal: number = null;
  sellerAccruedCoupon: number = null;
  sellerFee: number = null;
  sellerSettlementAmount: number = null;

  constructor(public intl: IntlService) {}

  ngOnInit() {}

  ngOnChanges(changes: import("@angular/core").SimpleChanges): void {
    if (changes.data && changes.data.currentValue) {
      changes.data.currentValue.map((flow: IBondOperationCashFlowItem) => {
        if (flow.clientId === this.sellerId) {
          if (flow.cashFlowType === CashFlowTypes.Principal) {
            this.sellerPrincipal = Math.abs(flow.amount);
          }
          if (flow.cashFlowType === CashFlowTypes.Commission) {
            this.sellerFee = Math.abs(flow.amount);
          }
          if (flow.cashFlowType === CashFlowTypes.AccruedInterest && typeof flow.amount === "number") {
            this.sellerAccruedCoupon = Math.abs(flow.amount);
          }
          this.sellerSettlementAmount =
            (this.sellerPrincipal ? this.sellerPrincipal : 0) -
            (this.sellerFee ? this.sellerFee : 0) +
            (this.sellerAccruedCoupon ? this.sellerAccruedCoupon : 0);
        } else if (flow.clientId === this.buyerId) {
          if (flow.cashFlowType === CashFlowTypes.Principal) {
            this.buyerPrincipal = Math.abs(flow.amount);
          }
          if (flow.cashFlowType === CashFlowTypes.Commission) {
            this.buyerFee = Math.abs(flow.amount);
          }
          if (flow.cashFlowType === CashFlowTypes.AccruedInterest && typeof flow.amount === "number") {
            this.buyerAccruedCoupon = Math.abs(flow.amount);
          }
          this.buyerSettlementAmount =
            (this.buyerPrincipal ? this.buyerPrincipal : 0) +
            (this.buyerFee ? this.buyerFee : 0) +
            (this.buyerAccruedCoupon ? this.buyerAccruedCoupon : 0);
        }
      });
    }
  }
}
