import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import {
  BondOperationTradeSettlementCalculationComponent
} from "./bond-operation-trade-settlement-calculation.component";

describe("BondOperationTradeSettlementCalculationComponent", () => {
  let component: BondOperationTradeSettlementCalculationComponent;
  let fixture: ComponentFixture<BondOperationTradeSettlementCalculationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BondOperationTradeSettlementCalculationComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BondOperationTradeSettlementCalculationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
