import { Component, OnInit, Input, ChangeDetectionStrategy } from "@angular/core";
import { IHttpBondOperation } from "../../models/IHttpBondOperation";
import { ICurrency } from "@core/models/catalogs/currency.interface";
import { EBondOperationTypes } from "../../models/EBondOperationTypes";
import { GridDataResult } from "@progress/kendo-angular-grid";
import { IntlService } from "@progress/kendo-angular-intl";
import { CashFlowTypes } from "../../models/CashFlowTypes";
import { IBondOperationCashFlowItem } from "../../models/IBondOperationCashFlowItem";

@Component({
  selector: "app-bond-operation-card",
  templateUrl: "./bond-operation-card.component.html",
  styleUrls: ["./bond-operation-card.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class BondOperationCardComponent implements OnInit {
  @Input() bondOperationData: IHttpBondOperation;
  @Input() currencies: ICurrency[];

  currencyName: string;
  operationTypeName: string;

  buyerPrincipal: number = null;
  buyerAccruedCoupon: number = null;
  buyerFee: number = null;
  buyerSettlementAmount: number = null;

  sellerPrincipal: number = null;
  sellerAccruedCoupon: number = null;
  sellerFee: number = null;
  sellerSettlementAmount: number = null;

  issuerDepositTypeId: number = EBondOperationTypes.IssuerDeposit;

  get gridView(): GridDataResult {
    return {
      data: this.bondOperationData ? this.bondOperationData.cashFlow : [],
      total: this.bondOperationData && this.bondOperationData.cashFlow ? this.bondOperationData.cashFlow.length : 0
    };
  }

  get buyerCashFlow(): GridDataResult {
    let arr = [];
    if (this.bondOperationData.buyerClientId) {
      arr = this.bondOperationData
        ? this.bondOperationData.cashFlow.filter(cf => cf.clientId === this.bondOperationData.buyerClientId)
        : [];
    }
    return {
      data: arr,
      total: arr.length
    };
  }

  get sellerCashFlow(): GridDataResult {
    let arr = [];
    if (this.bondOperationData.sellerClientId) {
      arr = this.bondOperationData
        ? this.bondOperationData.cashFlow.filter(cf => cf.clientId === this.bondOperationData.sellerClientId)
        : [];
    }
    return {
      data: arr,
      total: arr.length
    };
  }

  get isTrade(): boolean {
    return this.bondOperationData.operationType === EBondOperationTypes.Trade;
  }

  constructor(public intl: IntlService) { }

  ngOnInit() {
    this.currencies.map(cur => {
      if (cur.id === this.bondOperationData.bondCurrencyId) { this.currencyName = cur.name; }
    });
    this.operationTypeName = EBondOperationTypes[this.bondOperationData.operationType];

    if (this.isTrade) {
      this.bondOperationData.cashFlow.map((flow: IBondOperationCashFlowItem) => {
        if (flow.clientId === this.bondOperationData.sellerClientId) {
          if (flow.cashFlowType === CashFlowTypes.Principal) { this.sellerPrincipal = Math.abs(flow.amount); }
          if (flow.cashFlowType === CashFlowTypes.Commission) { this.sellerFee = Math.abs(flow.amount); }
          if (flow.cashFlowType === CashFlowTypes.AccruedInterest && typeof flow.amount === "number") {
            this.sellerAccruedCoupon = Math.abs(flow.amount);
          }
          this.sellerSettlementAmount =
            (this.sellerPrincipal ? this.sellerPrincipal : 0) -
            (this.sellerFee ? this.sellerFee : 0) +
            (this.sellerAccruedCoupon ? this.sellerAccruedCoupon : 0);
        } else if (flow.clientId === this.bondOperationData.buyerClientId) {
          if (flow.cashFlowType === CashFlowTypes.Principal) { this.buyerPrincipal = Math.abs(flow.amount); }
          if (flow.cashFlowType === CashFlowTypes.Commission) { this.buyerFee = Math.abs(flow.amount); }
          if (flow.cashFlowType === CashFlowTypes.AccruedInterest && typeof flow.amount === "number") {
            this.buyerAccruedCoupon = Math.abs(flow.amount);
          }
          this.buyerSettlementAmount =
            (this.buyerPrincipal ? this.buyerPrincipal : 0) +
            (this.buyerFee ? this.buyerFee : 0) +
            (this.buyerAccruedCoupon ? this.buyerAccruedCoupon : 0);
        }
      });
    }
  }
}
