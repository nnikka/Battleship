import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { BondOperationCardComponent } from "./bond-operation-card.component";

describe("BondOperationCardComponent", () => {
  let component: BondOperationCardComponent;
  let fixture: ComponentFixture<BondOperationCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BondOperationCardComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BondOperationCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
