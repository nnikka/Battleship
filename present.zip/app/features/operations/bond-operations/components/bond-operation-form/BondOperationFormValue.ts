import { IHttpBondOperation } from "../../models/IHttpBondOperation";
import { convertToDMY } from "src/utils/date-converter.helper";

export class BondOperationFormValue {
  bondId: number;
  depositClientId: number;
  depositCommission: number;
  operationType: number;
  parValue: number;
  price: number;
  settlementDate: string;
  tradeDate: string;
  depositIssuerClientId: number;
  depositIssuerCommission: number;
  depositIssuerClientName: string;
  withdrawalClientId: number;
  withdrawalCommission: number;
  withdrawalClientName: string;
  sellerClientId: number;
  sellerCommission: number;
  sellerClientName: string;
  buyerClientId: number;
  buyerCommission: number;
  buyerClientName: string;
  comment: string;
  referenceRate: number;

  constructor(init: IHttpBondOperation) {
    if (init) {
      this.depositClientId = init.depositClientId;
      this.operationType = init.operationType;
      this.parValue = init.parValue;
      this.price = init.price;
      this.comment = init.comment;
      if (init.settlementDate) {
        this.settlementDate = convertToDMY(init.settlementDate).toLocaleDateString();
      }
      if (init.tradeDate) {
        this.tradeDate = convertToDMY(init.tradeDate).toLocaleDateString();
      }
      this.bondId = init.bondId;
      this.depositCommission = init.depositCommission;
      this.depositIssuerClientId = init.depositIssuerClientId;
      this.depositIssuerCommission = init.depositIssuerCommission;
      this.depositIssuerClientName = init.depositIssuerClientName;

      this.withdrawalClientId = init.withdrawalClientId;
      this.withdrawalCommission = init.withdrawalCommission;
      this.withdrawalClientName = init.withdrawalClientName;

      this.sellerClientId = init.sellerClientId;
      this.sellerClientName = init.sellerClientName;
      this.sellerCommission = init.sellerCommission;

      this.buyerClientId = init.buyerClientId;
      this.buyerClientName = init.buyerClientName;
      this.buyerCommission = init.buyerCommission;

      this.referenceRate = init.referenceRate;
    }
  }
}
