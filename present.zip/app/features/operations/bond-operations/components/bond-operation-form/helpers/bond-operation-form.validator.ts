import { FormGroup, ValidatorFn, AbstractControl } from "@angular/forms";
import { IHttpBond } from "@features/static-data/bonds/models/IHttpBond";

export function BondOperationFormValidator() {
  return (formGroup: FormGroup) => {
    const bondControl = formGroup.get("bond");
    let bond = null;
    if (bondControl && bondControl.value) { bond = bondControl.value; }

    // Dates validation
    const tradeDateControl = formGroup.get("tradeDate");
    const settlementDateControl = formGroup.get("settlementDate");

    let tradeTime = null;
    let settlementTime = null;

    if (tradeDateControl.value) { tradeTime = new Date(tradeDateControl.value).getTime(); }
    if (settlementDateControl.value) { settlementTime = new Date(settlementDateControl.value).getTime(); }

    if (tradeTime && settlementTime && tradeTime > settlementTime) {
      tradeDateControl.setErrors({ tradeDateMustBeLessOrEquallThensettlementDate: true });
    } else if (tradeTime && settlementTime && !(tradeTime > settlementTime)) {
      tradeDateControl.setErrors(null);
    }

    // Trade: buyer and seller validation
    const buyerClientControl = formGroup.get("buyerClientId");
    const sellerClientControl = formGroup.get("sellerClientId");

    let buyerClient = null;
    let sellerClient = null;

    if (buyerClientControl && buyerClientControl.value) { buyerClient = buyerClientControl.value; }
    if (sellerClientControl && sellerClientControl.value) { sellerClient = sellerClientControl.value; }

    if (buyerClient && sellerClient && buyerClient === sellerClient) {
      sellerClientControl.setErrors({ sellerClientMustBeDifferentFromBuyer: true });
    } else if (buyerClient && sellerClient && buyerClient !== sellerClient) {
      sellerClientControl.setErrors(null);
    }
  };
}

export function bondOperationMaturityDateValidator(bondData: IHttpBond): ValidatorFn {
  return (control: AbstractControl): { [key: string]: boolean } | null => {
    if (bondData && bondData.maturityDate && control.value) {
      const st = bondData.maturityDate.substr(0, 10);
      const pattern = /(\d{2})\.(\d{2})\.(\d{4})/;
      const bondMatuTime = new Date(new Date(st.replace(pattern, "$3-$2-$1")).toLocaleDateString()).getTime();
      const operationSettlementTime = new Date(control.value).getTime();
      if (bondMatuTime && operationSettlementTime && bondMatuTime <= operationSettlementTime) {
        return { settlementDateMustBeLessOrEquallThenMaturityDate: true };
      }
    }
    return null;
  };
}

export function bondOperationDepositClientValidator(bondData: IHttpBond): ValidatorFn {
  return (control: AbstractControl): { [key: string]: boolean } | null => {
    if (bondData && bondData.clientId && control.value) {
      if (bondData.clientId === control.value) { return { depositClientMustBeDifferentFromBondIssuer: true }; }
    }
    return null;
  };
}

export function bondOperationbuyerClientValidator(bondData: IHttpBond): ValidatorFn {
  return (control: AbstractControl): { [key: string]: boolean } | null => {
    // droebit davikidoto es validaciao zemodan

    // if (bondData && bondData.clientId && control.value) {
    //     if (bondData.clientId === control.value) return { buyerClientMustBeDifferentFromBondIssuer: true }
    // }
    return null;
  };
}

export function bondOperationNominalAmountValidator(bondData: IHttpBond): ValidatorFn {
  return (control: AbstractControl): { [key: string]: boolean } | null => {
    if (bondData && bondData.clientId && control.value) {
      if (control.value < bondData.parValue || control.value > bondData.issueSize) {
        return { OperationNominalAmountMustBeBetweenBondNominalAmountAndIssueSize: true };
      } else if (control.value % bondData.parValue !== 0) {
        return { OperationNominalAmountMustBeDivisibleByBondNominalAmount: true };
      } else if (control.value < bondData.minTradeAmount) {
        return { OperationNominalAmountMustBeLessOrEqualThanBondMinTradeAmount: true };
      }
    }
    return null;
  };
}
