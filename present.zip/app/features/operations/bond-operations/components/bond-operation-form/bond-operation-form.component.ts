import { Component, OnInit, Output, EventEmitter, Input, OnDestroy, OnChanges, SimpleChanges } from "@angular/core";
import { FormGroup, FormBuilder, Validators, FormControl } from "@angular/forms";
import { IBondOperationType } from "../../models/IBondOperationType";
import { EBondOperationTypes } from "../../models/EBondOperationTypes";
import { IListItemBond } from "@features/static-data/bonds/models/IListItemBond";
import { ICurrency } from "@core/models/catalogs/currency.interface";
import { EClientStatuses } from "@features/static-data/clients/models/ClientStatuses.enum";
import { EBondAuthorizationStatuses } from "@features/static-data/bonds/models/BondAuthorizationStatuses.enum";
import { BondOperationFormValue } from "./BondOperationFormValue";
import {
  BondOperationFormValidator,
  bondOperationMaturityDateValidator,
  bondOperationDepositClientValidator,
  bondOperationbuyerClientValidator,
  bondOperationNominalAmountValidator
} from "./helpers/bond-operation-form.validator";
import { IHttpBond } from "@features/static-data/bonds/models/IHttpBond";
import { NotificationMessageService } from "@core/services/notification-message.service";
import { constructSelectItemsFromEnum } from "src/utils/array.helper";
import { ECouponTypes } from "@features/static-data/bonds/models/CouponTypes.enum";
import { CustomDateValidators } from "src/app/general/validators/date.validator";
import { BondOperationService } from "../../services/bond-operation.service";
import { untilDestroyed } from "ngx-take-until-destroy";
import { timer } from "rxjs";
import { debounce } from "rxjs/operators";

@Component({
  selector: "app-bond-operation-form",
  templateUrl: "./bond-operation-form.component.html",
  styleUrls: ["./bond-operation-form.component.scss"]
})
export class BondOperationFormComponent implements OnInit, OnDestroy, OnChanges {
  @Input() initialFormValue: BondOperationFormValue | any;
  @Input() operationType: number;
  @Input() currencies: ICurrency[];
  @Input() bondData: IHttpBond;
  @Output() formReady = new EventEmitter<FormGroup>();

  issuerDepositTypeId: number = EBondOperationTypes.IssuerDeposit;

  bondPriceIsLoading = false;

  form: FormGroup;
  operationTypes: IBondOperationType[];
  authorizedClientRequiredHttpParams = {
    "filterItem.status": EClientStatuses.Authorized,
    SortBy: "clientNameEng",
    SortDirection: 0
  };
  authorizedBondRequiredParams = {
    "filterItem.status": EBondAuthorizationStatuses.Authorized,
    SortBy: "name",
    SortDirection: 0
  };
  withdrawalClientRequiredHttpParams = {
    "filterItem.status": EClientStatuses.Authorized,
    "filterItem.bondHolderId": null,
    SortBy: "clientNameEng",
    SortDirection: 0
  };
  sellerClientRequiredHttpParams = {
    "filterItem.status": EClientStatuses.Authorized,
    "filterItem.bondHolderId": null,
    SortBy: "clientNameEng",
    SortDirection: 0
  };

  constructor(
    private formBuilder: FormBuilder,
    private notificationMessageService: NotificationMessageService,
    private bondOperationService: BondOperationService
  ) {}

  ngOnInit() {
    this.operationTypes = constructSelectItemsFromEnum(EBondOperationTypes);
    this.form = this.formBuilder.group(
      {
        tradeDate: [
          this.initialFormValue
            ? this.initialFormValue.tradeDate
            : this.dateFormat(new Date().toISOString().slice(0, 10)),
          [Validators.required]
        ],
        settlementDate: [
          this.initialFormValue ? this.initialFormValue.settlementDate : null,
          [
            Validators.required,
            bondOperationMaturityDateValidator(this.bondData),
            CustomDateValidators.minimumDateByDays(60)
          ]
        ],
        bondId: [this.initialFormValue ? this.initialFormValue.bondId : null, [Validators.required]],
        operationType: [
          {
            value: this.initialFormValue ? this.initialFormValue.operationType : this.operationType,
            disabled: true
          },
          [Validators.required]
        ],
        parValue: [
          this.initialFormValue ? this.initialFormValue.parValue : null,
          [Validators.required, bondOperationNominalAmountValidator(this.bondData)]
        ],
        comment: [this.initialFormValue ? this.initialFormValue.comment : null, []]
      },
      {
        validators: BondOperationFormValidator()
      }
    );
    this.form
      .get("bondId")
      .valueChanges.pipe(untilDestroyed(this))
      .subscribe((id: IListItemBond) => {
        this.form.get("parValue").setValue(null);

        if (this.form.get("buyerClientId")) {
          this.form.get("buyerClientId").setValue(null);
        }
        if (this.form.get("sellerClientId")) {
          this.form.get("sellerClientId").setValue(null);
        }
        if (this.form.get("withdrawalClientId")) {
          this.form.get("withdrawalClientId").setValue(null);
        }
        if (this.form.get("depositClientId")) {
          this.form.get("depositClientId").setValue(null);
        }
        if (this.form.get("depositIssuerClientId")) {
          this.form.get("depositIssuerClientId").setValue(null);
        }
        if (this.form.get("depositIssuerClientName")) {
          this.form.get("depositIssuerClientName").setValue(null);
        }

        if (id) {
          this.withdrawalClientRequiredHttpParams = {
            ...this.withdrawalClientRequiredHttpParams,
            "filterItem.bondHolderId": id
          };
          this.sellerClientRequiredHttpParams = {
            ...this.sellerClientRequiredHttpParams,
            "filterItem.bondHolderId": id
          };
        } else {
          this.withdrawalClientRequiredHttpParams = {
            ...this.withdrawalClientRequiredHttpParams,
            "filterItem.bondHolderId": null
          };
          this.sellerClientRequiredHttpParams = {
            ...this.sellerClientRequiredHttpParams,
            "filterItem.bondHolderId": null
          };
        }
        if (this.form.get("operationType").value === EBondOperationTypes.Trade) {
          this.handleBondPrice(id, this.form.get("tradeDate").value);
        }
      });
    if (this.form.get("operationType").value === EBondOperationTypes.Trade) {
      this.form
        .get("tradeDate")
        .valueChanges.pipe(
          debounce(() => timer(500)),
          untilDestroyed(this)
        )
        .subscribe(tradeDate => {
          this.handleBondPrice(this.form.get("bondId").value, tradeDate);
        });
    }
    this.constructFormDynamicPart();
    this.formReady.emit(this.form);

    this.handleFloatingBondRate();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.bondData && this.form && this.form.get("operationType").value === EBondOperationTypes.IssuerDeposit) {
      if (changes.bondData.currentValue && this.form.get("depositIssuerClientId")) {
        this.form.get("depositIssuerClientId").setValue(changes.bondData.currentValue.clientId);
        this.form.get("depositIssuerClientName").setValue(changes.bondData.currentValue.clientName);
      } else {
        this.form.get("depositIssuerClientId").setValue(null);
        this.form.get("depositIssuerClientName").setValue(null);
      }
    }
    if (changes.bondData && this.form) {
      this.form
        .get("settlementDate")
        .setValidators(Validators.compose([Validators.required, bondOperationMaturityDateValidator(this.bondData)]));
      this.form
        .get("parValue")
        .setValidators(Validators.compose([Validators.required, bondOperationNominalAmountValidator(this.bondData)]));
      if (this.form.get("depositClientId")) {
        this.form
          .get("depositClientId")
          .setValidators(Validators.compose([Validators.required, bondOperationDepositClientValidator(this.bondData)]));
      }
      if (this.form.get("buyerClientId")) {
        this.form
          .get("buyerClientId")
          .setValidators(Validators.compose([Validators.required, bondOperationbuyerClientValidator(this.bondData)]));
      }
      this.handleFloatingBondRate();
    }
  }

  handleFloatingBondRate() {
    if (
      this.bondData &&
      this.bondData.couponType === ECouponTypes.Floating &&
      this.form &&
      this.form.get("operationType").value === EBondOperationTypes.Trade
    ) {
      this.form.addControl(
        "referenceRate",
        new FormControl(this.initialFormValue ? this.initialFormValue.referenceRate : null, [Validators.min(0.0001)])
      );
    } else {
      this.form.removeControl("referenceRate");
    }
  }

  constructFormDynamicPart() {
    const operationType = this.form.get("operationType").value;

    this.form.removeControl("buyerClientId");
    this.form.removeControl("buyerCommission");
    this.form.removeControl("sellerClientId");
    this.form.removeControl("sellerCommission");
    this.form.removeControl("withdrawalClientId");
    this.form.removeControl("withdrawalCommission");
    this.form.removeControl("depositClientId");
    this.form.removeControl("depositCommission");
    this.form.removeControl("depositIssuerClientId");
    this.form.removeControl("depositIssuerClientName");
    this.form.removeControl("depositIssuerCommission");
    this.form.removeControl("price");

    if (operationType === EBondOperationTypes.Trade) {
      this.form.addControl(
        "buyerClientId",
        new FormControl(this.initialFormValue ? this.initialFormValue.buyerClientId : null, [
          Validators.required,
          bondOperationbuyerClientValidator(this.bondData)
        ])
      );
      this.form.addControl(
        "buyerCommission",
        new FormControl(this.initialFormValue ? this.initialFormValue.buyerCommission : 0, [
          Validators.required,
          Validators.min(0)
        ])
      );
      this.form.addControl(
        "sellerClientId",
        new FormControl(this.initialFormValue ? this.initialFormValue.sellerClientId : null, [Validators.required])
      );
      this.form.addControl(
        "sellerCommission",
        new FormControl(this.initialFormValue ? this.initialFormValue.sellerCommission : 0, [
          Validators.required,
          Validators.min(0)
        ])
      );
      this.form.addControl(
        "price",
        new FormControl(this.initialFormValue ? this.initialFormValue.price : null, [
          Validators.required,
          Validators.min(0.00001)
        ])
      );
    } else if (operationType === EBondOperationTypes.Deposit) {
      this.form.addControl(
        "depositClientId",
        new FormControl(this.initialFormValue ? this.initialFormValue.depositClientId : null, [
          Validators.required,
          bondOperationDepositClientValidator(this.bondData)
        ])
      );
      this.form.addControl(
        "depositCommission",
        new FormControl(this.initialFormValue ? this.initialFormValue.depositCommission : 0, [
          Validators.required,
          Validators.min(0)
        ])
      );
    } else if (operationType === EBondOperationTypes.Withdrawal) {
      this.form.addControl(
        "withdrawalClientId",
        new FormControl(this.initialFormValue ? this.initialFormValue.withdrawalClientId : null, [Validators.required])
      );
      this.form.addControl(
        "withdrawalCommission",
        new FormControl(this.initialFormValue ? this.initialFormValue.withdrawalCommission : 0, [
          Validators.required,
          Validators.min(0)
        ])
      );
    } else if (operationType === EBondOperationTypes.IssuerDeposit) {
      this.form.addControl(
        "depositIssuerClientId",
        new FormControl(
          {
            value: this.initialFormValue ? this.initialFormValue.depositIssuerClientId : null,
            disabled: true
          },
          [Validators.required]
        )
      );
      this.form.addControl(
        "depositIssuerClientName",
        new FormControl(
          {
            value: this.initialFormValue ? this.initialFormValue.depositIssuerClientName : null,
            disabled: true
          },
          [Validators.required]
        )
      );
      this.form.addControl(
        "depositIssuerCommission",
        new FormControl(this.initialFormValue ? this.initialFormValue.depositIssuerCommission : 0, [
          Validators.required,
          Validators.min(0)
        ])
      );
    }
  }

  handleBondPrice(bondId, date) {
    if (bondId && date) {
      this.bondPriceIsLoading = true;
      this.bondOperationService
        .getBondPrice(bondId, date)
        .pipe(untilDestroyed(this))
        .subscribe(
          resp => {
            if (resp) {
              this.form.get("price").setValue(resp);
            } else {
              this.form.get("price").setValue(null);
              this.notificationMessageService.info("Bond price for this date is not available");
            }
            this.bondPriceIsLoading = false;
          },
          () => {
            this.form.get("price").setValue(null);
            this.bondPriceIsLoading = false;
          }
        );
    } else {
      this.form.get("price").setValue(null);
      this.bondPriceIsLoading = false;
    }
  }

  ngOnDestroy(): void {}

  handleBondMarkAsPristine(val: boolean) {
    if (val) {
      this.form.get("bondId").markAsPristine();
    }
  }

  withdrawalClientOptionsAreEmty(e) {
    if (e) {
      this.notificationMessageService.warn("Selected bond does not belong to anyone, so client options are empty");
    }
  }

  sellerClientOptionsAreEmpty(e) {
    if (e) {
      this.notificationMessageService.warn(
        "Selected bond does not belong to anyone, so seller client options are empty"
      );
    }
  }

  dateFormat(date) {
    const split = date.split("-");
    return split[1] + "/" + split[2] + "/" + split[0];
  }
}
