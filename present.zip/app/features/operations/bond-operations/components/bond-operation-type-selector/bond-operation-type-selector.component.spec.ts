import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { BondOperationTypeSelectorComponent } from "./bond-operation-type-selector.component";

describe("BondOperationTypeSelectorComponent", () => {
  let component: BondOperationTypeSelectorComponent;
  let fixture: ComponentFixture<BondOperationTypeSelectorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BondOperationTypeSelectorComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BondOperationTypeSelectorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
