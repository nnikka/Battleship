import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";

@Component({
  selector: "app-bond-operation-type-selector",
  templateUrl: "./bond-operation-type-selector.component.html",
  styleUrls: ["./bond-operation-type-selector.component.scss"]
})
export class BondOperationTypeSelectorComponent implements OnInit {
  bondOperationTypes: string[] = ["Trade", "Deposit", "Withdrawal", "IssuerDeposit"];
  selectedType: string = null;

  constructor(private router: Router) {}

  ngOnInit() {}

  redirectToAddBond(e) {
    this.router.navigate(["admin/operations/bonds/add-bond-operation", { operationType: e }]);
  }
}
