import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { BondOperationCashFlowComponent } from "./bond-operation-cash-flow.component";

describe("BondOperationCashFlowComponent", () => {
  let component: BondOperationCashFlowComponent;
  let fixture: ComponentFixture<BondOperationCashFlowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BondOperationCashFlowComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BondOperationCashFlowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
