import { Component, OnInit, Input } from "@angular/core";
import { IBondOperationCashFlowItem } from "../../models/IBondOperationCashFlowItem";
import { GridDataResult } from "@progress/kendo-angular-grid";
import { IntlService } from "@progress/kendo-angular-intl";

@Component({
  selector: "app-bond-operation-cash-flow",
  templateUrl: "./bond-operation-cash-flow.component.html",
  styleUrls: ["./bond-operation-cash-flow.component.scss"]
})
export class BondOperationCashFlowComponent implements OnInit {
  @Input() data: IBondOperationCashFlowItem[];
  @Input() currency: string;
  @Input() loading: boolean;

  get gridView(): GridDataResult {
    return {
      data: this.data,
      total: this.data ? this.data.length : 0
    };
  }

  constructor(public intl: IntlService) {}

  ngOnInit() {}
}
