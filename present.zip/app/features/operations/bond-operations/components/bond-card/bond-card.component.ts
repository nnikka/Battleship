import { Component, OnInit, Input, ChangeDetectionStrategy, SimpleChanges, OnChanges } from "@angular/core";
import { IHttpBond } from "@features/static-data/bonds/models/IHttpBond";
import { IIssuer } from "@core/models/catalogs/issuer.interface";
import { ICurrency } from "@core/models/catalogs/currency.interface";
import { ECouponTypes } from "@features/static-data/bonds/models/CouponTypes.enum";
import { IntlService } from "@progress/kendo-angular-intl";

@Component({
  selector: "app-bond-card",
  templateUrl: "./bond-card.component.html",
  styleUrls: ["./bond-card.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class BondCardComponent implements OnInit, OnChanges {
  @Input() bondData: IHttpBond;
  @Input() issuers: IIssuer[];
  @Input() currencies: ICurrency[];

  issuer: IIssuer = null;
  currencyName: string = null;
  couponTypeName: string = null;

  constructor(public intl: IntlService) { }

  ngOnInit() { }

  ngOnChanges(changes: SimpleChanges): void {
    this.handleChanges();
  }

  handleChanges() {
    if (this.bondData) {
      this.issuers.map(issuer => {
        if (issuer.id === this.bondData.clientId) { this.issuer = issuer; }
      });
      this.currencies.map(cur => {
        if (cur.id === this.bondData.currencyId) { this.currencyName = cur ? cur.name : null; }
      });
      this.couponTypeName = ECouponTypes[this.bondData.couponType];
    }
  }
}
