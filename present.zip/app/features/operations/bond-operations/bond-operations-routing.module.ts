import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { BondOperationsListComponent } from "./containers/bond-operations-list/bond-operations-list.component";
import { AddBondOperationComponent } from "./containers/add-bond-operation/add-bond-operation.component";
import { BondOperationComponent } from "./containers/bond-operation/bond-operation.component";
import { ConfirmDeactivateGuard } from "@core/guards/confirm-deactivate-guard.guard";

import { CurrencyResolver } from "@core/resolvers/catalogs/currency.resolver";
import { IssuerResolver } from "@core/resolvers/catalogs/issuer.resolver";

const routes: Routes = [
  {
    path: "",
    component: BondOperationsListComponent
  },
  {
    path: "add-bond-operation",
    component: AddBondOperationComponent,
    canDeactivate: [ConfirmDeactivateGuard],
    resolve: {
      currency: CurrencyResolver,
      issuer: IssuerResolver
    }
  },
  {
    path: ":id",
    component: BondOperationComponent,
    canDeactivate: [ConfirmDeactivateGuard],
    resolve: {
      currency: CurrencyResolver,
      issuer: IssuerResolver
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BondOperationsRoutingRoutingModule {}
