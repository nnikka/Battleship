import { ICurrency } from "@core/models/catalogs/currency.interface";
import { FormGroup } from "@angular/forms";
import { IBondOperationCashFlowItem } from "../models/IBondOperationCashFlowItem";
import { IHttpBond } from "@features/static-data/bonds/models/IHttpBond";
import { EBondOperationTypes } from "../models/EBondOperationTypes";
import { MarkFormGroupTouched } from "src/utils/mark-formgroup-touched.helper";
import { BondOperationParams } from "../models/BondOperationParams";
import { NotificationMessageService } from "@core/services/notification-message.service";
import { BondOperationService } from "../services/bond-operation.service";
import { ChangesDetector } from "src/app/general/abstractClasses/ChangesDetector.abstractClass";
import { Injector } from "@angular/core";
import { untilDestroyed } from "ngx-take-until-destroy";

enum ClientOperationType {
  buyer = 1,
  seller = 2
}

export abstract class BondOperation extends ChangesDetector {
  protected notificationMessageService: NotificationMessageService;
  protected bondOperationService: BondOperationService;

  currencies: ICurrency[];

  loading: boolean = true;
  form: FormGroup;

  operationType: number;

  flowIsOpen: boolean = false;
  flowIsLoading: boolean = false;
  flowData: IBondOperationCashFlowItem[];
  flowHeader: string = "Cash flow";

  settlementCalculationIsOpean: boolean = false;
  settlementCalculationIsLoading: boolean = false;
  settlementCalculationData: IBondOperationCashFlowItem[];

  bondData: IHttpBond = null;
  bondIsLoading: boolean = false;

  constructor(injector: Injector) {
    super();
    this.notificationMessageService = injector.get(NotificationMessageService);
    this.bondOperationService = injector.get(BondOperationService);
  }

  get isTrade(): boolean {
    return this.operationType && this.operationType === EBondOperationTypes.Trade;
  }

  get bondOperationCurrency(): string {
    if (this.bondData && this.bondData.currencyId) {
      for (const currency of this.currencies) {
        if (currency.id === this.bondData.currencyId) {
          return currency.name;
        }
      }
    }
    return null;
  }
  get sellerClientId(): number {
    if (this.form && this.form.controls.sellerClientId) {
      return this.form.controls.sellerClientId.value;
    }
    return null;
  }

  get buyerClientId(): number {
    if (this.form && this.form.controls.buyerClientId) {
      return this.form.controls.buyerClientId.value;
    }
    return null;
  }

  hasUnsavedChanges(): boolean {
    if (this.form) {
      return this.form.dirty;
    }
    return false;
  }

  handleBondLoad() {
    this.form
      .get("bondId")
      .valueChanges.pipe(untilDestroyed(this))
      .subscribe(bondId => {
        if (bondId) {
          this.bondIsLoading = true;
          this.bondOperationService
            .getBondById(bondId)
            .pipe(untilDestroyed(this))
            .subscribe(bondData => {
              this.bondData = bondData;
              this.bondIsLoading = false;
            });
        } else {
          this.bondIsLoading = false;
          this.bondData = null;
        }
      });
  }

  getClientIdByType(type: number): number {
    if (!type) {
      return null;
    }
    let filterClientId;
    if (type === ClientOperationType.buyer) {
      filterClientId = this.form.get("buyerClientId") ? this.form.get("buyerClientId").value : null;
    } else if (type === ClientOperationType.seller) {
      filterClientId = this.form.get("sellerClientId") ? this.form.get("sellerClientId").value : null;
    }
    return filterClientId;
  }

  openFlow(type?: number) {
    if (!this.form.valid) {
      MarkFormGroupTouched(this.form.controls);
      this.notificationMessageService.error(
        "Form is invalid, please make sure all required fields are filled out correctly"
      );
    } else {
      this.flowIsOpen = true;
      this.flowIsLoading = true;
      this.bondOperationService
        .generateCashFlow(new BondOperationParams(this.form.getRawValue()))
        .pipe(untilDestroyed(this))
        .subscribe(
          resp => {
            if (type === 1) {
              this.flowHeader = "Buyer cash flow";
            } else if (type === 2) {
              this.flowHeader = "Seller cash flow";
            }
            const filterClientId = this.getClientIdByType(type);
            if (filterClientId) {
              this.flowData = resp.filter(it => it.clientId === filterClientId);
            } else {
              this.flowData = resp;
            }
            this.flowIsLoading = false;
          },
          () => {
            this.flowIsLoading = false;
          }
        );
    }
  }

  closeFlow() {
    this.flowIsOpen = false;
    this.flowData = null;
    this.flowHeader = "Cash flow";
  }

  openSettlementCalculation() {
    if (!this.form.valid) {
      MarkFormGroupTouched(this.form.controls);
      this.notificationMessageService.error(
        "Form is invalid, please make sure all required fields are filled out correctly"
      );
    } else {
      this.settlementCalculationIsOpean = true;
      this.settlementCalculationIsLoading = true;
      this.bondOperationService
        .generateCashFlow(new BondOperationParams(this.form.getRawValue()))
        .pipe(untilDestroyed(this))
        .subscribe(
          resp => {
            this.settlementCalculationData = resp;
            this.settlementCalculationIsLoading = false;
          },
          () => {
            this.settlementCalculationIsLoading = false;
            this.settlementCalculationData = null;
          }
        );
    }
  }

  closeSettlementCalculation() {
    this.settlementCalculationIsOpean = false;
    this.settlementCalculationData = null;
  }
}
