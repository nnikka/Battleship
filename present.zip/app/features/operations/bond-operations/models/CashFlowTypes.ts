export class CashFlowTypes {
  public static Principal: string = "Principal";
  public static AccruedInterest: string = "Accrued Coupon";
  public static Coupon: string = "Principal";
  public static Commission: string = "Fee";
  public static Nominal: string = "Face Amount";
}
