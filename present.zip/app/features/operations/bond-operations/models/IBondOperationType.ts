export interface IBondOperationType {
  name: string;
  value: number;
}
