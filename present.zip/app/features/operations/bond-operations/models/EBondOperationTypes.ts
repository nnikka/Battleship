export enum EBondOperationTypes {
  Trade = 1,
  Deposit = 2,
  Withdrawal = 4,
  IssuerDeposit = 8
}
