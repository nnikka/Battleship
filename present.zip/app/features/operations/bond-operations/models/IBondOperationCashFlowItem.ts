export interface IBondOperationCashFlowItem {
  date: string;
  cashFlowType: string;
  amount: number;
  clientId: number;
}
