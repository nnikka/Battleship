import { IAuditCommand } from "@core/models/commands/IAuditCommand";
import { IOperationTransaction } from "@core/models/IOperationTransaction";

export interface IHttpBondOperation {
  id: number;
  audit: IAuditCommand;
  operationType: number;
  operationStatus: number;
  bondName: string;
  bondISIN: string;
  bondCurrencyId: number;
  maturityDate: string;
  tradeDate: string;
  settlementDate: string;
  parValue: number;
  price: number;
  bondId: number;

  depositClientId: number;
  depositClientName: string;
  depositCommission: number;

  depositIssuerClientId: number;
  depositIssuerClientName: string;
  depositIssuerCommission: number;

  withdrawalClientId: number;
  withdrawalCommission: number;
  withdrawalClientName: string;

  sellerClientId: number;
  sellerCommission: number;
  sellerClientName: string;

  buyerClientId: number;
  buyerCommission: number;
  buyerClientName: string;

  comment: string;

  cashFlow: [
    {
      date: string;
      cashFlowType: string;
      amount: number;
      clientId: number;
    }
  ];

  operationTransactions: IOperationTransaction[];

  referenceRate: number;
}
