export interface IListItemBondOperation {
  id: number;
  operationType: number;
  tradeDate: string;
  bondName: string;
  bondISIN: number;
  bondCurrencyId: number;
  status: number;
}
