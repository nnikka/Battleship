import { IAuditCommand } from "@core/models/commands/IAuditCommand";
import { BondOperationFormValue } from "../components/bond-operation-form/BondOperationFormValue";

export class BondOperationParams {
  id: number;
  audit: IAuditCommand;
  operationType: number;
  tradeDate: string;
  settlementDate: string;
  parValue: number;
  price: number;
  depositCommission: number;
  bondId: number;
  depositClientId: number;
  depositIssuerClientId: number;
  depositIssuerCommission: number;
  withdrawalClientId: number;
  withdrawalCommission: number;
  sellerClientId: number;
  sellerCommission: number;
  buyerClientId: number;
  buyerCommission: number;
  comment: string;
  referenceRate: number;

  constructor(init?: BondOperationFormValue) {
    if (init) {
      this.operationType = init.operationType;
      this.tradeDate = init.tradeDate;
      this.settlementDate = init.settlementDate;
      this.parValue = init.parValue;
      this.price = init.price;
      this.depositCommission = init.depositCommission;
      this.bondId = init.bondId;
      this.depositClientId = init.depositClientId;
      this.depositIssuerClientId = init.depositIssuerClientId;
      this.depositIssuerCommission = init.depositIssuerCommission;
      this.withdrawalClientId = init.withdrawalClientId;
      this.withdrawalCommission = init.withdrawalCommission;
      this.sellerClientId = init.sellerClientId;
      this.sellerCommission = init.sellerCommission;
      this.buyerClientId = init.buyerClientId;
      this.buyerCommission = init.buyerCommission;
      this.comment = init.comment;
      this.referenceRate = init.referenceRate;
    }
  }
}
