import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { ConfigService } from "@env/service/config.service";
import { IHttpPagingQueryParams } from "@shared/models/IHttpPagingQueryParams";
import { IPagingHttpResponse } from "@shared/models/IPagingHttpResponse";
import { BondOperationParams } from "../models/BondOperationParams";
import { IListItemBondOperation } from "../models/IListItemBondOperation";
import { IHttpBondOperation } from "../models/IHttpBondOperation";
import { IBondOperationCashFlowItem } from "../models/IBondOperationCashFlowItem";
import { IHttpBond } from "@features/static-data/bonds/models/IHttpBond";

@Injectable()
export class BondOperationService {
  constructor(private http: HttpClient, private configService: ConfigService) {}

  create(params: BondOperationParams): Observable<any> {
    return this.http.post(`${this.configService.config.apiBaseurl}/api/BondOperations`, params);
  }

  generateCashFlow(params: BondOperationParams): Observable<IBondOperationCashFlowItem[]> {
    return this.http.post<IBondOperationCashFlowItem[]>(
      `${this.configService.config.apiBaseurl}/api/BondOperations/GenerateCashFlow`,
      params
    );
  }

  getAll(queryParams: IHttpPagingQueryParams): Observable<IPagingHttpResponse<IListItemBondOperation>> {
    const params = queryParams as any;
    return this.http.get<IPagingHttpResponse<IListItemBondOperation>>(
      `${this.configService.config.apiBaseurl}/api/BondOperations`,
      {
        params
      }
    );
  }

  getById(id: string): Observable<IHttpBondOperation> {
    return this.http.get<IHttpBondOperation>(`${this.configService.config.apiBaseurl}/api/BondOperations/${id}`);
  }

  getBondById(id: string): Observable<IHttpBond> {
    return this.http.get<IHttpBond>(`${this.configService.config.apiBaseurl}/api/Bonds/${id}`);
  }

  update(id: string, params): Observable<any> {
    params.id = id;
    return this.http.put(`${this.configService.config.apiBaseurl}/api/BondOperations/${id}`, params);
  }

  changeAuthorizationStatus(id: string, status: number): Observable<any> {
    return this.http.put(
      `${this.configService.config.apiBaseurl}/api/BondOperations/ChangeAuthorizationStatus/${id}/${status}`,
      {}
    );
  }

  getBondPrice(bondId, date): Observable<any> {
    return this.http.get<IHttpBondOperation>(`${this.configService.config.apiBaseurl}/api/Bonds/GetBondPrice`, {
      params: { date, bondId }
    });
  }

  exportExcel(): Observable<any> {
    return this.http.get(
      `${this.configService.config.apiBaseurl}/api/BondOperations/ExportBondOperationsWithTransaction`,
      {
        responseType: "blob"
      }
    );
  }

  exportOrderDocument(tradeOperationId: string, isBuyerClient: boolean, isTradeOrder: boolean): Observable<any> {
    return this.http.get(`${this.configService.config.apiBaseurl}/api/BondOperations/ExportTrade`, {
      params: { tradeOperationId, isBuyerClient: isBuyerClient.toString(), isTradeOrder: isTradeOrder.toString() },
      responseType: "blob"
    });
  }
}
