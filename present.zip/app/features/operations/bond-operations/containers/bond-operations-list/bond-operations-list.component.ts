import { Component, OnInit, OnDestroy } from "@angular/core";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import { Router, ActivatedRoute } from "@angular/router";
import { FormBuilder, FormGroup } from "@angular/forms";
import { Store, select } from "@ngrx/store";
import { IAppState } from "@core/store/app.state";
import { selectCurrencies, selectCurrencyLoadStatus } from "@core/store/currency/currency.selector";
import { ICurrency } from "@core/models/catalogs/currency.interface";
import {
  EBondOperationAuthorizationStatusesColors,
  EBondOperationAuthorizationStatuses
} from "../../models/EBondOperationAuthorizationStatuses";
import { EBondOperationTypes } from "../../models/EBondOperationTypes";
import { BondOperationService } from "../../services/bond-operation.service";
import {
  constructSelectItemsFromArray,
  constructSelectItemsFromEnum,
  getObjectParamFromArray
} from "src/utils/array.helper";
import { EOperationStatus, EOperationStatusColor } from "@core/models/enums/EOperationStatus";
import { FileDownloadService } from "@core/services/file-download.service";
import { formatDate } from "@telerik/kendo-intl";
import { untilDestroyed } from "ngx-take-until-destroy";
import { IColumn } from "@shared/components/complex-grid/interfaces/IColumn";
import { IOptions } from "@shared/components/complex-grid/interfaces/IOptions";

@Component({
  selector: "app-bond-operations-list",
  templateUrl: "./bond-operations-list.component.html",
  styleUrls: ["./bond-operations-list.component.scss"]
})
export class BondOperationsListComponent implements OnInit, OnDestroy {
  currencies$ = this.store.pipe(select(selectCurrencies));
  currenciesLoaded$ = this.store.pipe(select(selectCurrencyLoadStatus));
  currencies: ICurrency[];

  breadcrumbItems: IBreadcrumb[] = [
    { text: "Operations", to: null },
    { text: "Bonds", to: null }
  ];

  form: FormGroup;

  bondOperationAuthorizationStatuses: { name: string; value: number }[];
  bondOperationStatuses: { name: string; value: number }[];
  operationTypes: { name: string; value: number }[];

  columns: IColumn[];
  options: IOptions = {
    tableKey: "BondOperationsList",
    columnsTooboxEnable: true,
    dblClickEnable: true,
    detailShowEnable: true
  };
  excelIsDownloading: boolean = false;

  constructor(
    private fileDownloadService: FileDownloadService,
    private store: Store<IAppState>,
    private bondOperationService: BondOperationService
  ) { }

  ngOnInit() {
    this.bondOperationAuthorizationStatuses = constructSelectItemsFromEnum(EBondOperationAuthorizationStatuses);
    this.bondOperationStatuses = constructSelectItemsFromEnum(EOperationStatus);
    this.operationTypes = constructSelectItemsFromEnum(EBondOperationTypes);
    this.currencies$.pipe(untilDestroyed(this)).subscribe(currencies => {
      this.columns = [
        {
          key: "id",
          name: "ID",
          type: "number",
          filterConfig: {
            filterType: "number"
          }
        },
        {
          key: "operationStatus",
          name: "Operation status",
          type: "string",
          style: {
            colorsMapping: EOperationStatusColor,
            conditionalColor: true
          },
          filterConfig: {
            filterData: constructSelectItemsFromEnum(EOperationStatus),
            filterType: "dropdown"
          }
        },
        {
          key: "clientName",
          name: "Client name",
          type: "string",
          filterConfig: {
            filterType: "string"
          }
        },
        {
          key: "operationType",
          name: "Operation type",
          type: "string",
          filterConfig: {
            filterData: constructSelectItemsFromEnum(EBondOperationTypes),
            filterType: "dropdown"
          }
        },
        {
          key: "tradeDate",
          name: "Trade date",
          type: "date",
          filterConfig: {
            filterType: "date"
          }
        },
        {
          key: "bondName",
          name: "Name",
          type: "string",
          filterConfig: {
            filterType: "string"
          }
        },
        {
          key: "bondISIN",
          name: "ISIN",
          type: "string",
          filterConfig: {
            filterType: "string"
          }
        },
        // getCurrencyById(dataItem.bondCurrencyId)
        {
          key: "bondCurrencyId",
          name: "Currency",
          type: "string",
          filterConfig: {
            containsDataMapping: true,
            filterData: constructSelectItemsFromArray(currencies, { name: "All", id: null }),
            filterType: "dropdown",
            dropdownKeyKey: "name",
            dropdownValueKey: "id"
          }
        },
        {
          key: "createUserFullName",
          name: "Created by",
          type: "string",
          filterConfig: {
            filterType: "string"
          }
        },
        {
          key: "status",
          name: "Authorization status",
          type: "string",
          style: {
            colorsMapping: EBondOperationAuthorizationStatusesColors,
            conditionalColor: true,
            isCard: true
          },
          filterConfig: {
            filterData: constructSelectItemsFromEnum(EBondOperationAuthorizationStatuses),
            filterType: "dropdown"
          }
        }
      ];
      this.currencies = constructSelectItemsFromArray(currencies, { name: "All", id: null });
    });
  }

  getCurrencyById(id): string {
    return getObjectParamFromArray(this.currencies, id);
  }

  exportExcel() {
    this.excelIsDownloading = true;
    this.bondOperationService
      .exportExcel()
      .pipe(untilDestroyed(this))
      .subscribe(response => {
        this.fileDownloadService.downLoadFile(`${formatDate(new Date(), "MM/dd/yyyy")} bond-operations.xlsx`, response);
        this.excelIsDownloading = false;
      });
  }

  ngOnDestroy() { }

  authorizationStatusColor(status: string) {
    return EBondOperationAuthorizationStatusesColors[status];
  }

  operationStatusColor(status: string): string {
    return status ? EOperationStatusColor[status] : null;
  }
}
