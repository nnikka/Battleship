import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { BondOperationsListComponent } from "./bond-operations-list.component";

describe("BondOperationsListComponent", () => {
  let component: BondOperationsListComponent;
  let fixture: ComponentFixture<BondOperationsListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BondOperationsListComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BondOperationsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
