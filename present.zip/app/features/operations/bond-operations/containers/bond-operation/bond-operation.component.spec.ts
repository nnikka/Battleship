import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { BondOperationComponent } from "./bond-operation.component";

describe("BondOperationComponent", () => {
  let component: BondOperationComponent;
  let fixture: ComponentFixture<BondOperationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BondOperationComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BondOperationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
