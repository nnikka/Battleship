import { Component, OnInit, OnDestroy, Injector } from "@angular/core";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import { select, Store } from "@ngrx/store";
import { selectCurrencies, selectCurrencyLoadStatus } from "@core/store/currency/currency.selector";
import { IAppState } from "@core/store/app.state";
import { IHttpBondOperation } from "../../models/IHttpBondOperation";
import { ActivatedRoute, Router } from "@angular/router";
import { FormGroup } from "@angular/forms";
import { AuthService } from "@auth/services/auth.service";
import { PopupConfirmService } from "@components/popup-confirm/popup-confirm.service";
import { MarkFormGroupTouched } from "src/utils/mark-formgroup-touched.helper";
import {
  EBondOperationAuthorizationStatusesColors,
  EBondOperationAuthorizationStatuses
} from "../../models/EBondOperationAuthorizationStatuses";
import { EBondAuthorizationStatuses } from "@features/static-data/bonds/models/BondAuthorizationStatuses.enum";
import { BondOperationFormValue } from "../../components/bond-operation-form/BondOperationFormValue";
import { BondOperationParams } from "../../models/BondOperationParams";
import { selectIssuers, selectIssuerLoadStatus } from "@core/store/issuer/issuer.selector";
import { FadeInOutAnimation } from "src/app/general/animations/fadeInOut.animation";
import { BondOperation } from "../../helpers/BondOperation";
import { EOperationStatus, EOperationStatusColor } from "@core/models/enums/EOperationStatus";
import { TimerService, ICountDownResult } from "@core/services/timer.service";
import { OperationService, EOperationType } from "@core/services/operation.service";
import { untilDestroyed } from "ngx-take-until-destroy";
import { FileDownloadService } from "@core/services/file-download.service";

@Component({
  selector: "app-bond-operation",
  templateUrl: "./bond-operation.component.html",
  styleUrls: ["./bond-operation.component.scss"],
  animations: [FadeInOutAnimation]
})
export class BondOperationComponent extends BondOperation implements OnInit, OnDestroy {
  breadcrumbItems: IBreadcrumb[] = [
    { text: "Operations", to: null },
    { text: "Bonds", to: "/admin/operations/bonds" },
    { text: "Bond Operation", to: null }
  ];

  currencies$ = this.store.pipe(select(selectCurrencies));
  currenciesLoaded = this.store.pipe(select(selectCurrencyLoadStatus));
  issuers$ = this.store.pipe(select(selectIssuers));
  issuersLoaded$ = this.store.pipe(select(selectIssuerLoadStatus));

  authorizationIsDisabled: boolean = false;
  bondOperationId: string;
  bondOperationData: IHttpBondOperation;

  transactionTiming: ICountDownResult;
  transactionTimingInterval;

  buyerDocumentIsDownloading: boolean = false;
  sellerDocuemntIsDowloading: boolean = false;
  buyerConfirmationIsDownloading: boolean = false;
  sellerConfirmationIsDownloading: boolean = false;

  formIsUpdatedSuccessfully: boolean = false;

  get transactionTimingColor(): string {
    if (this.transactionTiming && this.transactionTiming.expired) {
      return "#fb311c";
    }
    return "#28a745";
  }

  get bondOperationAuthorizationStatus() {
    return this.bondOperationData ? EBondAuthorizationStatuses[this.bondOperationData.audit.status] : null;
  }

  get isBondOperationkAuthorized() {
    return this.bondOperationData
      ? EBondAuthorizationStatuses.Authorized === this.bondOperationData.audit.status
      : false;
  }

  get isBondOperationkUnauthorized() {
    return this.bondOperationData
      ? EBondAuthorizationStatuses.Unauthorized === this.bondOperationData.audit.status
      : false;
  }

  get operationStatus(): string {
    if (this.bondOperationData) {
      return EOperationStatus[this.bondOperationData.operationStatus];
    }
    return null;
  }

  get isOperationSucceed(): boolean {
    if (this.bondOperationData) {
      return this.bondOperationData.operationStatus === EOperationStatus.Success;
    }
    return false;
  }

  get isOperationCanceled(): boolean {
    if (this.bondOperationData) {
      return this.bondOperationData.operationStatus === EOperationStatus.Canceled;
    }
    return false;
  }

  get initialFormValue(): BondOperationFormValue {
    return new BondOperationFormValue(this.bondOperationData);
  }

  get canAuthorize() {
    if (this.formIsUpdatedSuccessfully) {
      return false;
    }
    if (this.bondOperationData) {
      const lastUserId = this.bondOperationData.audit.lastModifiedUserId
        ? this.bondOperationData.audit.lastModifiedUserId
        : this.bondOperationData.audit.createUserId;
      if (lastUserId !== Number(this.authService.getUserId())) {
        return true;
      }
    }
    return null;
  }

  get canDeauthorize(): boolean {
    if (this.bondOperationData && this.bondOperationData.operationStatus === EOperationStatus.Success) {
      return false;
    }
    return true;
  }

  get isExecutionOfTransactionsAvailable(): boolean {
    if (
      this.bondOperationData &&
      (this.bondOperationData.operationStatus === EOperationStatus.Pending ||
        this.bondOperationData.operationStatus === EOperationStatus.Fail)
    ) {
      const pattern = /(\d{2})\.(\d{2})\.(\d{4})/;
      const settlementDate = new Date(this.bondOperationData.settlementDate.replace(pattern, "$3-$2-$1")).getTime();
      if (settlementDate < Date.now()) {
        return true;
      }
    }
    return false;
  }

  get isBondOperationStatusPending(): boolean {
    return this.bondOperationData && this.bondOperationData.operationStatus === EOperationStatus.Pending;
  }

  constructor(
    injector: Injector,
    private store: Store<IAppState>,
    private route: ActivatedRoute,
    private router: Router,
    private authService: AuthService,
    private popupConfirmService: PopupConfirmService,
    private timerService: TimerService,
    private operationService: OperationService,
    private fileDownloadService: FileDownloadService
  ) {
    super(injector);
  }

  authorizationStatusColor(status: string): string {
    return status ? EBondOperationAuthorizationStatusesColors[status] : null;
  }

  operationStatusColor(status: string): string {
    return status ? EOperationStatusColor[status] : null;
  }

  ngOnInit() {
    this.currencies$.pipe(untilDestroyed(this)).subscribe(cur => {
      this.currencies = cur;
    });
    this.route.paramMap.pipe(untilDestroyed(this)).subscribe(paramsAsMap => {
      this.bondOperationId = paramsAsMap.get("id");
      this.loadBondOperation(this.bondOperationId);
    });
    this.transactionTimingInterval = setInterval(() => {
      if (
        this.bondOperationData &&
        this.bondOperationData.settlementDate &&
        this.bondOperationData.operationStatus === EOperationStatus.Pending
      ) {
        this.transactionTiming = this.timerService.countDown(this.bondOperationData.settlementDate);
      }
    }, 1000);
  }

  formInitialized(form: FormGroup) {
    this.form = form;
    if (this.form.get("bondId") && this.form.get("bondId").value) {
      this.loadBond(this.form.get("bondId").value);
    }
    if (this.isTrade && !this.isBondOperationkAuthorized) {
      this.openSettlementCalculation();
    }
    this.handleBondLoad();
  }

  loadBond(bondId) {
    this.bondIsLoading = true;
    this.bondOperationService
      .getBondById(bondId)
      .pipe(untilDestroyed(this))
      .subscribe(bondData => {
        this.bondData = bondData;
        this.bondIsLoading = false;
      });
  }

  loadBondOperation(id) {
    this.loading = true;
    this.bondOperationService
      .getById(id)
      .pipe(untilDestroyed(this))
      .subscribe(
        bondOperation => {
          this.bondOperationData = bondOperation;
          this.loading = false;
          this.operationType = bondOperation.operationType;
          if (this.isBondOperationkAuthorized) {
            this.loadBond(this.bondOperationData.bondId);
          }
        },
        err => {
          this.router.navigateByUrl("/not-found", { replaceUrl: true });
        }
      );
  }

  handleUpdate() {
    if (!this.form.dirty) {
      this.notificationMessageService.info("Nothing is changed");
    } else {
      if (!this.form.valid) {
        MarkFormGroupTouched(this.form.controls);
        this.notificationMessageService.error(
          "Form is invalid, please make sure all required fields are filled out correctly"
        );
      } else {
        this.popupConfirmService.show(null, null, () => {
          this.loading = true;
          this.bondOperationService
            .update(this.bondOperationId, new BondOperationParams(this.form.getRawValue()))
            .pipe(untilDestroyed(this))
            .subscribe(
              () => {
                // this.form.reset();
                this.form.markAsPristine();
                this.formIsUpdatedSuccessfully = true;
                this.loading = false;
                this.notificationMessageService.success("Bond operation has been updated successfully");
              },
              () => {
                this.loading = false;
              }
            );
        });
      }
    }
  }

  handleChangeAuthorize(status: string, message: string) {
    if (this.form && this.form.dirty) {
      this.notificationMessageService.warn(
        "Form is changed, if you want to change authorization status please update the form first"
      );
      return;
    }
    this.popupConfirmService.show(null, null, () => {
      this.authorizationIsDisabled = true;
      this.loading = true;
      this.bondOperationService
        .changeAuthorizationStatus(this.bondOperationId, EBondOperationAuthorizationStatuses[status])
        .pipe(untilDestroyed(this))
        .subscribe(
          () => {
            this.authorizationIsDisabled = false;
            this.loading = false;
            this.loadBondOperation(this.bondOperationId);
            this.notificationMessageService.success(message);
          },
          () => {
            this.authorizationIsDisabled = false;
            this.loading = false;
          }
        );
    });
  }

  handleExecuteTransactions() {
    this.popupConfirmService.show(null, null, () => {
      this.loading = true;
      this.operationService
        .makeOperationTransactions(this.bondOperationId, EOperationType.Bond)
        .pipe(untilDestroyed(this))
        .subscribe(
          () => {
            this.loadBondOperation(this.bondOperationId);
          },
          () => {
            this.loadBondOperation(this.bondOperationId);
          }
        );
    });
  }

  exportOrderDocument(isBuyerClient: boolean, bondOperationAuthorized: boolean): void {
    if (bondOperationAuthorized) {
      isBuyerClient ? (this.buyerDocumentIsDownloading = true) : (this.sellerDocuemntIsDowloading = true);
    } else {
      isBuyerClient ? (this.buyerConfirmationIsDownloading = true) : (this.sellerConfirmationIsDownloading = true);
    }
    this.bondOperationService
      .exportOrderDocument(this.bondOperationId, isBuyerClient, !bondOperationAuthorized)
      .pipe(untilDestroyed(this))
      .subscribe(
        resp => {
          const today = new Date();
          let dd: string | number = today.getDate();
          let mm: string | number = today.getMonth() + 1;
          const yyyy = today.getFullYear();
          if (dd < 10) {
            dd = "0" + dd;
          }
          if (mm < 10) {
            mm = "0" + mm;
          }
          const formatedToday = `${dd}/${mm}/${yyyy}`;
          let clientName = "";
          if (isBuyerClient) {
            clientName = this.bondOperationData.buyerClientName;
          } else {
            clientName = this.bondOperationData.sellerClientName;
          }

          this.fileDownloadService.downLoadFile(
            !bondOperationAuthorized
              ? `trade-order ${formatedToday} ${clientName}.pdf`
              : `trade-confirmation ${formatedToday} ${clientName}.pdf`,
            resp
          );
          if (bondOperationAuthorized) {
            isBuyerClient ? (this.buyerDocumentIsDownloading = false) : (this.sellerDocuemntIsDowloading = false);
          } else {
            isBuyerClient
              ? (this.buyerConfirmationIsDownloading = false)
              : (this.sellerConfirmationIsDownloading = false);
          }
        },
        err => {
          if (bondOperationAuthorized) {
            isBuyerClient ? (this.buyerDocumentIsDownloading = false) : (this.sellerDocuemntIsDowloading = false);
          } else {
            isBuyerClient
              ? (this.buyerConfirmationIsDownloading = false)
              : (this.sellerConfirmationIsDownloading = false);
          }
        }
      );
  }

  ngOnDestroy() {
    if (this.transactionTimingInterval) {
      clearInterval(this.transactionTimingInterval);
    }
  }
}
