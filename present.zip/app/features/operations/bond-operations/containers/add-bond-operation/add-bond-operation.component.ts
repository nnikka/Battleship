import { Component, OnInit, OnDestroy, Injector } from "@angular/core";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import { ActivatedRoute, Router } from "@angular/router";
import { EBondOperationTypes } from "../../models/EBondOperationTypes";
import { select, Store } from "@ngrx/store";
import { selectCurrencies, selectCurrencyLoadStatus } from "@core/store/currency/currency.selector";
import { IAppState } from "@core/store/app.state";
import { MarkFormGroupTouched } from "src/utils/mark-formgroup-touched.helper";
import { PopupConfirmService } from "@components/popup-confirm/popup-confirm.service";
import { BondOperationParams } from "../../models/BondOperationParams";
import { selectIssuerLoadStatus, selectIssuers } from "@core/store/issuer/issuer.selector";
import { FadeInOutAnimation } from "src/app/general/animations/fadeInOut.animation";
import { BondOperation } from "../../helpers/BondOperation";
import { untilDestroyed } from "ngx-take-until-destroy";

@Component({
  selector: "app-add-bond-operation",
  templateUrl: "./add-bond-operation.component.html",
  styleUrls: ["./add-bond-operation.component.scss"],
  animations: [FadeInOutAnimation]
})
export class AddBondOperationComponent extends BondOperation implements OnInit, OnDestroy {
  breadcrumbItems: IBreadcrumb[] = [
    { text: "Operations", to: null },
    { text: "Bonds", to: "/admin/operations/bonds" },
    { text: "Add operation", to: null }
  ];

  currencies$ = this.store.pipe(select(selectCurrencies));
  currenciesLoaded = this.store.pipe(select(selectCurrencyLoadStatus));
  issuers$ = this.store.pipe(select(selectIssuers));
  issuersLoaded$ = this.store.pipe(select(selectIssuerLoadStatus));
  bondDataFromRoute;
  constructor(
    injector: Injector,
    private route: ActivatedRoute,
    private store: Store<IAppState>,
    private popupConfirmService: PopupConfirmService,
    private router: Router
  ) {
    super(injector);
    if (this.router.getCurrentNavigation() && this.router.getCurrentNavigation().extras.state) {
      this.bondDataFromRoute = this.router.getCurrentNavigation().extras.state.data;
    }
  }

  ngOnInit() {
    this.loading = false;
    this.currencies$.pipe(untilDestroyed(this)).subscribe(cur => {
      this.currencies = cur;
    });
    if (this.route.snapshot.paramMap.get("operationType")) {
      this.operationType = EBondOperationTypes[this.route.snapshot.paramMap.get("operationType")];
      if (!this.operationType) {
        this.router.navigateByUrl("/not-found", { replaceUrl: true });
      }
    }
  }

  formInitialized(event) {
    this.form = event;
    this.handleBondLoad();

    if (this.bondDataFromRoute) {
      this.form.get("bondId").setValue(this.bondDataFromRoute.id);
      this.form.get("bondId").markAsDirty();
    }
  }

  handleRegister() {
    if (!this.form.valid) {
      MarkFormGroupTouched(this.form.controls);
      this.notificationMessageService.error(
        "Form is invalid, please make sure all required fields are filled out correctly"
      );
    } else {
      this.popupConfirmService.show(null, null, () => {
        this.loading = true;
        this.bondOperationService
          .create(new BondOperationParams(this.form.getRawValue()))
          .pipe(untilDestroyed(this))
          .subscribe(
            () => {
              this.form.reset();
              this.form.markAsPristine();
              this.router.navigate(["admin/operations/bonds"]);
              this.notificationMessageService.success("Bond operation has been added successfully");
            },
            () => {
              this.loading = false;
            }
          );
      });
    }
  }

  ngOnDestroy() {}
}
