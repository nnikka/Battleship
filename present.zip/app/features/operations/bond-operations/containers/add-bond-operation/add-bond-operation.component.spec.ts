import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { AddBondOperationComponent } from "./add-bond-operation.component";

describe("AddBondOperationComponent", () => {
  let component: AddBondOperationComponent;
  let fixture: ComponentFixture<AddBondOperationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AddBondOperationComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddBondOperationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
