import { NgModule } from "@angular/core";

import { SharedModule } from "@shared/shared.module";
import { BondOperationsRoutingRoutingModule } from "./bond-operations-routing.module";
import { BondOperationsListComponent } from "./containers/bond-operations-list/bond-operations-list.component";
import {
  BondOperationTypeSelectorComponent
} from "./components/bond-operation-type-selector/bond-operation-type-selector.component";
import { AddBondOperationComponent } from "./containers/add-bond-operation/add-bond-operation.component";
import { BondOperationComponent } from "./containers/bond-operation/bond-operation.component";
import { BondOperationFormComponent } from "./components/bond-operation-form/bond-operation-form.component";

import { BondOperationService } from "./services/bond-operation.service";
import {
  BondOperationCashFlowComponent
} from "./components/bond-operation-cash-flow/bond-operation-cash-flow.component";
import { BondOperationCardComponent } from "./components/bond-operation-card/bond-operation-card.component";
import { BondCardComponent } from "./components/bond-card/bond-card.component";
import {
  BondOperationTradeSettlementCalculationComponent
} from "./components/bond-operation-trade-settlement-calculation/bond-operation-trade-settlement-calculation.component";

@NgModule({
  declarations: [
    BondOperationsListComponent,
    BondOperationTypeSelectorComponent,
    AddBondOperationComponent,
    BondOperationComponent,
    BondOperationFormComponent,
    BondOperationCashFlowComponent,
    BondOperationCardComponent,
    BondCardComponent,
    BondOperationTradeSettlementCalculationComponent
  ],
  imports: [SharedModule, BondOperationsRoutingRoutingModule],
  providers: [BondOperationService]
})
export class BondOperationsModule { }
