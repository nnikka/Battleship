export interface IClientBondBalancesListItem {
  amount: number;
  clientName: string;
  currencyName: string;
  date: string;
  id: number;
  name: string;
  ticker: string;
}
