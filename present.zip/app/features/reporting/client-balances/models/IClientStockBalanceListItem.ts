export interface IClientStockBalanceListItem {
  clientCounterpartyName: string;
  clientName: string;
  currencyName: string;
  date: string;
  id: number;
  name: string;
  quantity: number;
  ticker: string;
}
