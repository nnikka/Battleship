export interface IClientCashBalanceListItem {
  amount: number;
  clientCounterpartyId: number;
  clientCounterpartyName: string;
  clientId: number;
  clientName: string;
  currencyId: number;
  currencyName: string;
  id: number;
}
