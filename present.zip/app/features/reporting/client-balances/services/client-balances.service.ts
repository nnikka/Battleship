import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { ConfigService } from "@env/service/config.service";
import { IHttpPagingQueryParams } from "@shared/models/IHttpPagingQueryParams";
import { IPagingHttpResponse } from "@shared/models/IPagingHttpResponse";
import { IClientCashBalanceListItem } from "../models/IClientCashBalanceListItem";
import { IClientStockBalanceListItem } from "../models/IClientStockBalanceListItem";
import { IClientBondBalancesListItem } from "../models/IClientBondBalancesListItem";

@Injectable()
export class ClientBalancesService {
  constructor(private http: HttpClient, private configService: ConfigService) {}

  getCashBalances(queryParams: IHttpPagingQueryParams): Observable<IPagingHttpResponse<IClientCashBalanceListItem>> {
    const params = queryParams as any;
    return this.http.get<IPagingHttpResponse<IClientCashBalanceListItem>>(
      `${this.configService.config.apiBaseurl}/api/Reporting/ClientBalances/GetClientCashBalances`,
      {
        params
      }
    );
  }

  getStockBalances(queryParams: IHttpPagingQueryParams): Observable<IPagingHttpResponse<IClientStockBalanceListItem>> {
    const params = queryParams as any;
    return this.http.get<IPagingHttpResponse<IClientStockBalanceListItem>>(
      `${this.configService.config.apiBaseurl}/api/Reporting/ClientBalances/GetClientStockBalances`,
      {
        params
      }
    );
  }

  getBondBalances(queryParams: IHttpPagingQueryParams): Observable<IPagingHttpResponse<IClientBondBalancesListItem>> {
    const params = queryParams as any;
    return this.http.get<IPagingHttpResponse<IClientBondBalancesListItem>>(
      `${this.configService.config.apiBaseurl}/api/Reporting/ClientBalances/GetClientBondBalances`,
      {
        params
      }
    );
  }

  exportExcel(endpoint: string, date: string): Observable<any> {
    return this.http.get(`${this.configService.config.apiBaseurl}/api/${endpoint}`, {
      params: { date },
      responseType: "blob"
    });
  }
}
