import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

// tslint:disable-next-line: max-line-length
import { ClientCashBalancesListComponent } from "./containers/client-cash-balances-list/client-cash-balances-list.component";
// tslint:disable-next-line: max-line-length
import { ClientStockBalancesListComponent } from "./containers/client-stock-balances-list/client-stock-balances-list.component";
// tslint:disable-next-line: max-line-length
import { ClientBondBalancesListComponent } from "./containers/client-bond-balances-list/client-bond-balances-list.component";

import { CounterPartyResolver } from "@core/resolvers/catalogs/counterParty.resolver";
import { CurrencyResolver } from "@core/resolvers/catalogs/currency.resolver";

const routes: Routes = [
  {
    path: "",
    component: ClientCashBalancesListComponent,
    data: { title: "Reporting - Cash Balances" },
    resolve: {
      currency: CurrencyResolver,
      counterParty: CounterPartyResolver
    }
  },
  {
    path: "stock-balances",
    component: ClientStockBalancesListComponent,
    data: { title: "Reporting - Stock Balances" },
    resolve: {
      currency: CurrencyResolver,
      counterParty: CounterPartyResolver
    }
  },
  {
    path: "bond-balances",
    component: ClientBondBalancesListComponent,
    data: { title: "Reporting - Bond Balances" },
    resolve: {
      currency: CurrencyResolver,
      counterParty: CounterPartyResolver
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StocksRoutingRoutingModule {}
