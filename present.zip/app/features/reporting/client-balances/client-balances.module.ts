import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { ClientBalancesListComponent } from "./containers/client-balances-list/client-balances-list.component";
// tslint:disable-next-line: max-line-length
import { ClientCashBalancesListComponent } from "./containers/client-cash-balances-list/client-cash-balances-list.component";

import { StocksRoutingRoutingModule } from "./client-balances-routing.module";
import { SharedModule } from "@shared/shared.module";

import { ClientBalancesService } from "./services/client-balances.service";
// tslint:disable-next-line: max-line-length
import { ClientStockBalancesListComponent } from "./containers/client-stock-balances-list/client-stock-balances-list.component";
// tslint:disable-next-line: max-line-length
import { ClientBondBalancesListComponent } from "./containers/client-bond-balances-list/client-bond-balances-list.component";
import { BalanceExportFormComponent } from "./components/balance-export-form/balance-export-form.component";

@NgModule({
  declarations: [
    ClientBalancesListComponent,
    ClientCashBalancesListComponent,
    ClientStockBalancesListComponent,
    ClientBondBalancesListComponent,
    BalanceExportFormComponent
  ],
  imports: [CommonModule, StocksRoutingRoutingModule, SharedModule],
  providers: [ClientBalancesService]
})
export class ClientBalancesModule {}
