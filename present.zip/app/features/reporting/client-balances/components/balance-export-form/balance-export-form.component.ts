import { Component, OnInit, Output, EventEmitter, Input } from "@angular/core";
import { FormGroup, FormBuilder } from "@angular/forms";
import { formatDate } from "@telerik/kendo-intl";

@Component({
  selector: "app-balance-export-form",
  templateUrl: "./balance-export-form.component.html",
  styleUrls: ["./balance-export-form.component.scss"]
})
export class BalanceExportFormComponent implements OnInit {
  @Input() excelIsDownloading: boolean = false;

  @Output() export = new EventEmitter();

  form: FormGroup;

  constructor(private formBuilder: FormBuilder) {}

  ngOnInit() {
    this.form = this.formBuilder.group({
      date: [formatDate(new Date(), "MM/dd/yyyy"), []]
    });
  }

  exportExcel() {
    this.export.emit(this.form.get("date").value);
  }
}
