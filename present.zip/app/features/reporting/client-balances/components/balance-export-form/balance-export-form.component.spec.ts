import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { BalanceExportFormComponent } from "./balance-export-form.component";

describe("BalanceExportFormComponent", () => {
  let component: BalanceExportFormComponent;
  let fixture: ComponentFixture<BalanceExportFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BalanceExportFormComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BalanceExportFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
