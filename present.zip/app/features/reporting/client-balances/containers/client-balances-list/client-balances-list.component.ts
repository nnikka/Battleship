import { Component, OnInit } from "@angular/core";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import { Router } from "@angular/router";

@Component({
  selector: "app-client-balances-list",
  templateUrl: "./client-balances-list.component.html",
  styleUrls: ["./client-balances-list.component.scss"]
})
export class ClientBalancesListComponent implements OnInit {
  breadcrumbItems: IBreadcrumb[] = [
    { text: "Reporting", to: null },
    { text: "Balances", to: null }
  ];

  constructor(private router: Router) {}

  ngOnInit() {}

  goToCashBalances() {
    this.router.navigateByUrl("/admin/reporting/client-balances/cash-balances");
  }
}
