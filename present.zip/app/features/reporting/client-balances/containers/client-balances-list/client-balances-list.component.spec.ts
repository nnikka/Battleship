import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { ClientBalancesListComponent } from "./client-balances-list.component";

describe("ClientBalancesListComponent", () => {
  let component: ClientBalancesListComponent;
  let fixture: ComponentFixture<ClientBalancesListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ClientBalancesListComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientBalancesListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
