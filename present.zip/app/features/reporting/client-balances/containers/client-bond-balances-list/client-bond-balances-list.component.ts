import { Component, OnInit, OnDestroy } from "@angular/core";
import { select, Store } from "@ngrx/store";
import { selectCurrencies, selectCurrencyLoadStatus } from "@core/store/currency/currency.selector";
import {
  selectAuthorizedCounterParties,
  selectCounterPartyLoadStatus
} from "@core/store/counterParty/counterParty.selector";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import { ICounterParty } from "@core/models/catalogs/counterParty.interface";
import { ICurrency } from "@core/models/catalogs/currency.interface";
import { Router, ActivatedRoute } from "@angular/router";
import { IAppState } from "@core/store/app.state";
import { IntlService } from "@progress/kendo-angular-intl";
import { ClientBalancesService } from "../../services/client-balances.service";
import { untilDestroyed } from "ngx-take-until-destroy";
import { constructSelectItemsFromArray } from "src/utils/array.helper";
import { FileDownloadService } from "@core/services/file-download.service";
import { zip } from "rxjs";
import { map } from "rxjs/operators";
import { IColumn } from "@shared/components/complex-grid/interfaces/IColumn";
import { IOptions } from "@shared/components/complex-grid/interfaces/IOptions";

@Component({
  selector: "app-client-bond-balances-list",
  templateUrl: "./client-bond-balances-list.component.html",
  styleUrls: ["./client-bond-balances-list.component.scss"]
})
export class ClientBondBalancesListComponent implements OnInit, OnDestroy {
  currencies$ = this.store.pipe(select(selectCurrencies));
  currenciesLoaded$ = this.store.pipe(select(selectCurrencyLoadStatus));
  counterParties$ = this.store.pipe(select(selectAuthorizedCounterParties));
  counterPartiesLoaded$ = this.store.pipe(select(selectCounterPartyLoadStatus));

  breadcrumbItems: IBreadcrumb[] = [
    { text: "Reporting", to: null },
    { text: "Bond balances", to: null }
  ];

  counterParties: ICounterParty[];
  currencies: ICurrency[];

  excelIsDownloading: boolean = false;

  columns: IColumn[];
  options: IOptions = {
    tableKey: "ClientBondBalancesList",
    columnsTooboxEnable: true
  };

  constructor(
    private router: Router,
    private store: Store<IAppState>,
    public intl: IntlService,
    private clientBalancesService: ClientBalancesService,
    private fileDownloadService: FileDownloadService
  ) {}

  ngOnInit() {
    this.counterParties$.pipe(untilDestroyed(this)).subscribe(counterParties => {});

    zip(this.counterParties$, this.currencies$)
      .pipe(map(arr => ({ counterParties: arr[0], currencies: arr[1] })))
      .subscribe(({ counterParties, currencies }) => {
        this.currencies = constructSelectItemsFromArray(currencies, { name: "All", id: null });
        this.counterParties = constructSelectItemsFromArray(counterParties, { name: "TBC Capital", id: "0" });
        this.counterParties = constructSelectItemsFromArray(this.counterParties, { name: "All", id: null });

        this.columns = [
          {
            key: "clientId",
            name: "Client ID",
            type: "number",
            filterConfig: {
              filterType: "number"
            }
          },
          {
            key: "clientName",
            name: "Client name",
            type: "string",
            filterConfig: {
              filterType: "string"
            }
          },
          {
            key: "name",
            name: "Bond name",
            type: "string",
            filterConfig: {
              filterType: "string"
            }
          },
          {
            // addSpaces(dataItem.operationType)
            key: "isin",
            name: "ISIN",
            type: "string",
            filterConfig: {
              filterType: "string"
            }
          },
          {
            key: "currencyName",
            name: "Currency",
            type: "string",
            filterConfig: {
              key: "currencyId",
              containsDataMapping: true,
              dataMappingSearchKey: "name",
              filterData: this.currencies,
              filterType: "dropdown",
              dropdownKeyKey: "name",
              dropdownValueKey: "id"
            }
          },
          {
            key: "amount",
            name: "Balance",
            type: "number",
            format: "##,#.##########",
            filterConfig: {
              filterType: "number"
            }
          },
          {
            key: "pledgedAmount",
            name: "Pldeged amount",
            type: "number",
            format: "##,#.##########",
            filterConfig: {
              filterType: "number"
            }
          },
          {
            key: "date",
            name: "Date",
            type: "date",
            filterConfig: {
              filterType: "date"
            }
          }
        ];
      });
  }

  handleBalanceExport(date: string) {
    this.excelIsDownloading = true;
    this.clientBalancesService
      .exportExcel("Reporting/ClientBalances/ExportBondBalances", date)
      .pipe(untilDestroyed(this))
      .subscribe(reponse => {
        this.fileDownloadService.downLoadFile(`${date} bond-balances.xlsx`, reponse);
        this.excelIsDownloading = false;
      });
  }

  goToCashBalances() {
    this.router.navigateByUrl("/admin/reporting/client-balances");
  }

  goToStockBalances() {
    this.router.navigateByUrl("/admin/reporting/client-balances/stock-balances");
  }

  ngOnDestroy(): void {}
}
