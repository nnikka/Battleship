import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { ClientBondBalancesListComponent } from "./client-bond-balances-list.component";

describe("ClientBondBalancesListComponent", () => {
  let component: ClientBondBalancesListComponent;
  let fixture: ComponentFixture<ClientBondBalancesListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ClientBondBalancesListComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientBondBalancesListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
