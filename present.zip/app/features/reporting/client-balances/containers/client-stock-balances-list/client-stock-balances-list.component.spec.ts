import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { ClientStockBalancesListComponent } from "./client-stock-balances-list.component";

describe("ClientStockBalancesListComponent", () => {
  let component: ClientStockBalancesListComponent;
  let fixture: ComponentFixture<ClientStockBalancesListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ClientStockBalancesListComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientStockBalancesListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
