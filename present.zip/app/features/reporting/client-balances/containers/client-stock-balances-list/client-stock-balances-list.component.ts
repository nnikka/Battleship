import { Component, OnInit, OnDestroy } from "@angular/core";
import { select, Store } from "@ngrx/store";
import { selectCurrencies, selectCurrencyLoadStatus } from "@core/store/currency/currency.selector";
import {
  selectAuthorizedCounterParties,
  selectCounterPartyLoadStatus
} from "@core/store/counterParty/counterParty.selector";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import { ICounterParty } from "@core/models/catalogs/counterParty.interface";
import { ICurrency } from "@core/models/catalogs/currency.interface";
import { GridDataResult } from "@progress/kendo-angular-grid";
import { Router, ActivatedRoute } from "@angular/router";
import { IAppState } from "@core/store/app.state";
import { FormBuilder } from "@angular/forms";
import { IntlService } from "@progress/kendo-angular-intl";
import { ClientBalancesService } from "../../services/client-balances.service";
import { untilDestroyed } from "ngx-take-until-destroy";
import { constructSelectItemsFromArray } from "src/utils/array.helper";
import { FileDownloadService } from "@core/services/file-download.service";
import { IColumn } from "@shared/components/complex-grid/interfaces/IColumn";
import { zip } from "rxjs";
import { map } from "rxjs/operators";
import { IOptions } from "@shared/components/complex-grid/interfaces/IOptions";

@Component({
  selector: "app-client-stock-balances-list",
  templateUrl: "./client-stock-balances-list.component.html",
  styleUrls: ["./client-stock-balances-list.component.scss"]
})
export class ClientStockBalancesListComponent implements OnInit, OnDestroy {
  currencies$ = this.store.pipe(select(selectCurrencies));
  currenciesLoaded$ = this.store.pipe(select(selectCurrencyLoadStatus));
  counterParties$ = this.store.pipe(select(selectAuthorizedCounterParties));
  counterPartiesLoaded$ = this.store.pipe(select(selectCounterPartyLoadStatus));

  breadcrumbItems: IBreadcrumb[] = [
    { text: "Reporting", to: null },
    { text: "Stock balances", to: null }
  ];

  counterParties: ICounterParty[];
  currencies: ICurrency[];

  excelIsDownloading: boolean = false;

  columns: IColumn[];
  options: IOptions = {
    tableKey: "ClientStockBalancesList",
    columnsTooboxEnable: true
  };

  constructor(
    private router: Router,
    private store: Store<IAppState>,
    private formBuilder: FormBuilder,
    route: ActivatedRoute,
    public intl: IntlService,
    private clientBalancesService: ClientBalancesService,
    private fileDownloadService: FileDownloadService
  ) { }

  ngOnInit() {
    zip(this.counterParties$, this.currencies$)
      .pipe(map(arr => ({ counterParties: arr[0], currencies: arr[1] })))
      .subscribe(({ counterParties, currencies }) => {
        this.currencies = constructSelectItemsFromArray(currencies, { name: "All", id: null });
        this.counterParties = constructSelectItemsFromArray(counterParties, { name: "TBC Capital", id: "0" });
        this.counterParties = constructSelectItemsFromArray(this.counterParties, { name: "All", id: null });

        this.columns = [
          {
            key: "clientId",
            name: "Client ID",
            type: "number",
            filterConfig: {
              filterType: "number"
            }
          },
          {
            key: "clientName",
            name: "Client name",
            type: "string",
            filterConfig: {
              filterType: "string"
            }
          },
          {
            key: "clientCounterpartyName",
            name: "Balance at",
            type: "string",
            filterConfig: {
              key: "clientCounterPartyId",
              filterData: this.counterParties,
              filterType: "dropdown",
              dropdownKeyKey: "name",
              dropdownValueKey: "id"
            }
          },
          {
            key: "name",
            name: "Stock name",
            type: "string",
            filterConfig: {
              filterType: "string"
            }
          },
          {
            key: "ticker",
            name: "Ticker",
            type: "string",
            filterConfig: {
              filterType: "string"
            }
          },
          {
            key: "currencyName",
            name: "Currency",
            type: "string",
            filterConfig: {
              key: "currencyId",
              containsDataMapping: true,
              dataMappingSearchKey: "name",
              filterData: this.currencies,
              filterType: "dropdown",
              dropdownKeyKey: "name",
              dropdownValueKey: "id"
            }
          },
          {
            key: "quantity",
            name: "Balance",
            type: "number",
            format: "##,#.##########",
            filterConfig: {
              filterType: "number"
            }
          },
          {
            key: "pledgedAmount",
            name: "Pledged amount",
            type: "number",
            format: "##,#.##########",
            filterConfig: {
              filterType: "number"
            }
          },
          {
            key: "date",
            name: "Date",
            type: "date",
            filterConfig: {
              filterType: "date"
            }
          }
        ];
      });
  }

  handleBalanceExport(date: string) {
    this.excelIsDownloading = true;
    this.clientBalancesService
      .exportExcel("Reporting/ClientBalances/ExportStockBalances", date)
      .pipe(untilDestroyed(this))
      .subscribe(reponse => {
        this.excelIsDownloading = false;
        this.fileDownloadService.downLoadFile(`${date} stock-balances.xlsx`, reponse);
      });
  }

  goToCashBalances() {
    this.router.navigateByUrl("/admin/reporting/client-balances");
  }

  goToBondBalances() {
    this.router.navigateByUrl("/admin/reporting/client-balances/bond-balances");
  }

  ngOnDestroy(): void { }
}
