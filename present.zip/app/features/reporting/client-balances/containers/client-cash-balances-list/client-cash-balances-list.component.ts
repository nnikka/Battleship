import { Component, OnInit, OnDestroy } from "@angular/core";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import { Router } from "@angular/router";
import { Store, select } from "@ngrx/store";
import { IAppState } from "@core/store/app.state";
import {
  selectAuthorizedCounterParties,
  selectCounterPartyLoadStatus
} from "@core/store/counterParty/counterParty.selector";
import { selectCurrencies, selectCurrencyLoadStatus } from "@core/store/currency/currency.selector";
import { ICounterParty } from "@core/models/catalogs/counterParty.interface";
import { ICurrency } from "@core/models/catalogs/currency.interface";
import { constructSelectItemsFromArray } from "src/utils/array.helper";
import { untilDestroyed } from "ngx-take-until-destroy";
import { ClientBalancesService } from "../../services/client-balances.service";
import { IntlService } from "@progress/kendo-angular-intl";
import { FileDownloadService } from "@core/services/file-download.service";
import { zip } from "rxjs";
import { map } from "rxjs/operators";
import { IColumn } from "@shared/components/complex-grid/interfaces/IColumn";
import { IOptions } from "@shared/components/complex-grid/interfaces/IOptions";

@Component({
  selector: "app-client-cash-balances-list",
  templateUrl: "./client-cash-balances-list.component.html",
  styleUrls: ["./client-cash-balances-list.component.scss"]
})
export class ClientCashBalancesListComponent implements OnInit, OnDestroy {
  currencies$ = this.store.pipe(select(selectCurrencies));
  currenciesLoaded$ = this.store.pipe(select(selectCurrencyLoadStatus));
  counterParties$ = this.store.pipe(select(selectAuthorizedCounterParties));
  counterPartiesLoaded$ = this.store.pipe(select(selectCounterPartyLoadStatus));

  breadcrumbItems: IBreadcrumb[] = [
    { text: "Reporting", to: null },
    { text: "Cash balances", to: null }
  ];

  counterParties: ICounterParty[];
  currencies: ICurrency[];

  columns: IColumn[];
  options: IOptions = {
    tableKey: "ClientCashBalancesList",
    columnsTooboxEnable: true
  };

  excelIsDownloading: boolean = false;

  constructor(
    private router: Router,
    private store: Store<IAppState>,
    public intl: IntlService,
    private clientBalancesService: ClientBalancesService,
    private fileDownloadService: FileDownloadService
  ) { }

  ngOnInit() {
    zip(this.counterParties$, this.currencies$)
      .pipe(map(arr => ({ counterParties: arr[0], currencies: arr[1] })))
      .subscribe(({ counterParties, currencies }) => {
        this.currencies = constructSelectItemsFromArray(currencies, { name: "All", id: null });
        this.counterParties = constructSelectItemsFromArray(counterParties, { name: "TBC Capital", id: "0" });
        this.counterParties = constructSelectItemsFromArray(this.counterParties, { name: "All", id: null });

        this.columns = [
          {
            key: "clientId",
            name: "Client ID",
            type: "number",
            filterConfig: {
              filterType: "number"
            }
          },
          {
            key: "clientName",
            name: "Client name",
            type: "string",
            filterConfig: {
              filterType: "string"
            }
          },
          {
            key: "clientCounterpartyName",
            name: "Balance at",
            type: "string",
            filterConfig: {
              key: "clientCounterPartyId",
              filterData: this.counterParties,
              filterType: "dropdown",
              dropdownKeyKey: "name",
              dropdownValueKey: "id"
            }
          },
          {
            key: "currencyName",
            name: "Currency",
            type: "string",
            filterConfig: {
              key: "currencyId",
              containsDataMapping: true,
              dataMappingSearchKey: "name",
              filterData: this.currencies,
              filterType: "dropdown",
              dropdownKeyKey: "name",
              dropdownValueKey: "id"
            }
          },
          {
            key: "amount",
            name: "Cash amount",
            type: "number",
            format: "##,#.##########",
            filterConfig: {
              filterType: "number"
            }
          },
          {
            key: "pledgedAmount",
            name: "Pledged amount",
            type: "number",
            format: "##,#.##########",
            filterConfig: {
              filterType: "number"
            }
          },

          {
            key: "date",
            name: "Date",
            type: "date",
            filterConfig: {
              filterType: "date"
            }
          }
        ];
      });
  }

  handleBalanceExport(date: string) {
    this.excelIsDownloading = true;
    this.clientBalancesService
      .exportExcel("Reporting/ClientBalances/ExportCashBalances", date)
      .pipe(untilDestroyed(this))
      .subscribe(reponse => {
        this.excelIsDownloading = false;
        this.fileDownloadService.downLoadFile(`${date} cash-balances.xlsx`, reponse);
      });
  }

  goToStockBalances() {
    this.router.navigateByUrl("/admin/reporting/client-balances/stock-balances");
  }

  goToBondBalances() {
    this.router.navigateByUrl("/admin/reporting/client-balances/bond-balances");
  }

  ngOnDestroy(): void { }
}
