import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { ClientCashBalancesListComponent } from "./client-cash-balances-list.component";

describe("ClientCashBalancesListComponent", () => {
  let component: ClientCashBalancesListComponent;
  let fixture: ComponentFixture<ClientCashBalancesListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ClientCashBalancesListComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientCashBalancesListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
