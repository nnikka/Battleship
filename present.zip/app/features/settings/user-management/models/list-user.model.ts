export interface IListUser {
  email: string;
  fullName: string;
  id: number;
  isAdmin: boolean;
  isDisabled: boolean;
}
