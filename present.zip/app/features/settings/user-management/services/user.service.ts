import { Injectable } from "@angular/core";
import { ConfigService } from "@env/service/config.service";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { RegisterUser } from "../models/register-user.model";
import { IPagingHttpResponse } from "@shared/models/IPagingHttpResponse";
import { IListUser } from "../models/list-user.model";

@Injectable()
export class UserService {
  constructor(private http: HttpClient, private config: ConfigService) {}

  getAll(queryParams): Observable<IPagingHttpResponse<IListUser>> {
    return this.http.get<IPagingHttpResponse<IListUser>>(`${this.config.config.apiBaseurl}/api/Users`, {
      params: queryParams
    });
  }

  register(data: RegisterUser): Observable<any> {
    return this.http.post(`${this.config.config.apiBaseurl}/api/Auth/register`, data);
  }

  SetIsUserDisabled(id, status): Observable<any> {
    return this.http.put(`${this.config.config.apiBaseurl}/api/users/SetIsUserDisabled/${id}/${status}`, {});
  }
}
