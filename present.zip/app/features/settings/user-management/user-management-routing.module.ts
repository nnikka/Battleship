import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { AddUserComponent } from "./containers/add-user/add-user.component";

import { RolesRequiredGuard } from "@core/guards/roles-required.guard";
import { Roles } from "@core/models/roles.enum";
import { UsersListComponent } from "./containers/users-list/users-list.component";

const routes: Routes = [
  {
    path: "",
    component: UsersListComponent,
    data: { title: "User management - Users List", roles: [Roles.Admin] },
    // canActivate: [RolesRequiredGuard],
    resolve: {}
  },
  {
    path: "add-user",
    component: AddUserComponent,
    data: { title: "User management - Add user", roles: [Roles.Admin] },
    canActivate: [RolesRequiredGuard],
    resolve: {}
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProfileManagementRoutingRoutingModule { }
