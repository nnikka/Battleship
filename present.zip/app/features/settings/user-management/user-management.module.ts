import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { AddUserComponent } from "./containers/add-user/add-user.component";
import { UserFormComponent } from "./containers/add-user/user-form/user-form.component";

import { UserService } from "./services/user.service";

import { ProfileManagementRoutingRoutingModule } from "./user-management-routing.module";
import { SharedModule } from "@shared/shared.module";
import { UsersListComponent } from "./containers/users-list/users-list.component";

@NgModule({
  declarations: [AddUserComponent, UserFormComponent, UsersListComponent],
  imports: [CommonModule, ProfileManagementRoutingRoutingModule, SharedModule],
  providers: [UserService]
})
export class UserManagementModule { }
