import { Component } from "@angular/core";
import { NotificationMessageService } from "@core/services/notification-message.service";
import { RegisterUser } from "../../models/register-user.model";
import { UserService } from "../../services/user.service";
import { Subject } from "rxjs";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";

@Component({
  selector: "app-add-user",
  templateUrl: "./add-user.component.html"
})
export class AddUserComponent {
  breadcrumbItems: IBreadcrumb[] = [
    { text: "Settings", to: null },
    { text: "Users", to: "/admin/settings/user-management" },
    { text: "Add user", to: null }
  ];
  loading: boolean = false;
  eventsSubject: Subject<boolean> = new Subject<boolean>();

  constructor(private notificationMessageService: NotificationMessageService, private userService: UserService) { }

  handleSubmit($event: RegisterUser) {
    this.loading = true;
    this.userService.register($event).subscribe(
      response => {
        this.eventsSubject.next(true);
        this.notificationMessageService.success("User has been added successfully");
        this.loading = false;
      },
      error => {
        this.loading = false;
      }
    );
  }
}
