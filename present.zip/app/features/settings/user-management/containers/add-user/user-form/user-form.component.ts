import { Component, OnInit, Output, EventEmitter, Input, OnDestroy } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { MustMatch } from "src/utils/must-match.helper";
import { PopupConfirmService } from "@components/popup-confirm/popup-confirm.service";
import { RegisterUser } from "../../../models/register-user.model";
import { CustomValidators } from "src/app/general/validators/custom.validator";
import { Observable } from "rxjs";
import { untilDestroyed } from "ngx-take-until-destroy";

@Component({
  selector: "app-user-form",
  templateUrl: "./user-form.component.html",
  styleUrls: ["./user-form.component.scss"]
})
export class UserFormComponent implements OnInit, OnDestroy {
  @Input() events: Observable<boolean>;
  @Output() eformSubmit: EventEmitter<RegisterUser> = new EventEmitter();

  form: FormGroup;

  constructor(private formBuilder: FormBuilder, private popupConfirmService: PopupConfirmService) { }

  ngOnInit() {
    this.events.pipe(untilDestroyed(this)).subscribe(bool => {
      if (bool) {
        this.form.reset();
      }
    });
    this.form = this.formBuilder.group(
      {
        firstName: ["", [Validators.required, CustomValidators.onlyLatLetters()]],
        lastName: ["", [Validators.required, CustomValidators.onlyLatLetters()]],
        email: ["", [Validators.required, Validators.email]],
        password: ["", [
          Validators.required,
          Validators.minLength(8),
          Validators.pattern(/^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/)
        ]],
        confirmPassword: ["", [Validators.required]]
      },
      { validator: MustMatch("password", "confirmPassword") }
    );
  }

  formSubmit() {
    this.popupConfirmService.show(null, null, () => this.eformSubmit.emit(this.form.value));
  }

  ngOnDestroy() { }
}
