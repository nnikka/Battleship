import { Component, OnInit, OnDestroy } from "@angular/core";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import { FormGroup, FormBuilder } from "@angular/forms";
import { Router, ActivatedRoute } from "@angular/router";
import { UserService } from "../../services/user.service";
import { PopupConfirmService } from "@components/popup-confirm/popup-confirm.service";
import { IColumn } from "@shared/components/complex-grid/interfaces/IColumn";
import { IOptions } from "@shared/components/complex-grid/interfaces/IOptions";
import { Subject } from "rxjs";

@Component({
  selector: "app-users-list",
  templateUrl: "./users-list.component.html",
  styleUrls: ["./users-list.component.scss"]
})
export class UsersListComponent implements OnInit, OnDestroy {
  breadcrumbItems: IBreadcrumb[] = [
    { text: "Settings", to: null },
    { text: "Users", to: "/admin/operations/user-management" }
  ];
  form: FormGroup;

  updateGrid: Subject<any> = new Subject();

  listIsLoading = true;

  statuses;

  columns: IColumn[];
  options: IOptions = {
    tableKey: "UsersList",
    columnsTooboxEnable: true,
  };

  constructor(
    private router: Router,
    private userService: UserService,
    private popupConfirmService: PopupConfirmService
  ) {
    this.statuses = [
      { name: "All", value: null },
      { name: "Enabled", value: false },
      { name: "Disabled", value: true }
    ];

    this.columns = [
      {
        key: "id",
        name: "ID",
        type: "number",
        filterConfig: {
          filterType: "number"
        }
      },
      {
        key: "fullName",
        name: "Name",
        type: "string",
        filterConfig: {
          filterType: "string",
        }
      },
      {
        key: "email",
        name: "Email",
        type: "string",
        filterConfig: {
          filterType: "string"
        }
      },
      {
        key: "isDisabled",
        name: "Change Status",
        type: "string",
        useTemplate: true,
        filterConfig: {
          filterData: this.statuses,
          filterType: "dropdown"
        }
      }
    ];

  }

  ngOnInit() { }

  handleAddUser() {
    this.router.navigate(["/admin/settings/user-management/add-user"]);
  }

  ngOnDestroy(): void { }

  changeStatus(id, isDisabled) {
    this.popupConfirmService.show(null, null, () => {
      this.userService.SetIsUserDisabled(id, isDisabled).subscribe(() => {
        this.updateGrid.next();
      });
    });
  }
}
