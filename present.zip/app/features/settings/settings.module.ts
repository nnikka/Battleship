import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { ProfileManagementRoutingRoutingModule } from "./settings-routing.module";

@NgModule({
  imports: [CommonModule, ProfileManagementRoutingRoutingModule]
})
export class SettingsModule { }
