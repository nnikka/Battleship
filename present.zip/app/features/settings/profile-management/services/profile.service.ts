import { Injectable } from "@angular/core";
import { ConfigService } from "@env/service/config.service";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";

@Injectable()
export class ProfileService {
  constructor(private http: HttpClient, private config: ConfigService) {}

  changePassword(data): Observable<any> {
    return this.http.post(`${this.config.config.apiBaseurl}/api/Auth/ChangePassword`, data);
  }
}
