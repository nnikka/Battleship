import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { ChangePasswordComponent } from "./containers/change-password/change-password.component";

const routes: Routes = [
  {
    path: "change-password",
    component: ChangePasswordComponent,
    data: { title: "Profile - Change password" },
    canDeactivate: [],
    resolve: {}
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProfileManagementRoutingRoutingModule {}
