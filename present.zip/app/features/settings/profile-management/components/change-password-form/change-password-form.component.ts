import { Component, OnInit, Output, EventEmitter } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { MustMatch } from "src/utils/must-match.helper";

@Component({
  selector: "app-change-password-form",
  templateUrl: "./change-password-form.component.html",
  styleUrls: ["./change-password-form.component.scss"]
})
export class ChangePasswordFormComponent implements OnInit {
  @Output() formReady = new EventEmitter<FormGroup>();

  form: FormGroup;

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.form = this.formBuilder.group(
      {
        currentPassword: [null, [Validators.required]],
        newPassword: [null, [
          Validators.required,
          Validators.minLength(8),
          Validators.pattern(/^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/)
        ]],
        confirmNewPassword: [null, Validators.required]
      },
      { validator: MustMatch("newPassword", "confirmNewPassword") }
    );

    this.formReady.emit(this.form);
  }
}
