import { Component, OnInit } from "@angular/core";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import { FormGroup } from "@angular/forms";
import { ProfileService } from "../../services/profile.service";
import { PopupConfirmService } from "@components/popup-confirm/popup-confirm.service";
import { NotificationMessageService } from "@core/services/notification-message.service";

@Component({
  selector: "app-change-password",
  templateUrl: "./change-password.component.html",
  styleUrls: ["./change-password.component.scss"]
})
export class ChangePasswordComponent implements OnInit {
  breadcrumbItems: IBreadcrumb[] = [
    { text: "Settings", to: null },
    { text: "Change password", to: null }
  ];

  loading: boolean = false;
  form: FormGroup;

  constructor(
    private profileService: ProfileService,
    private popupConfirmService: PopupConfirmService,
    private notificationMessageService: NotificationMessageService
  ) {}

  ngOnInit() {}

  handleFormReady(form: FormGroup) {
    this.form = form;
  }

  handleUpdate() {
    if (this.form.valid) {
      this.popupConfirmService.show(null, null, () => {
        this.loading = true;
        this.profileService.changePassword(this.form.value).subscribe(
          response => {
            this.form.reset();
            this.loading = false;
            this.notificationMessageService.success("Password has been changed successfully");
          },
          error => {
            this.loading = false;
          }
        );
      });
    }
  }
}
