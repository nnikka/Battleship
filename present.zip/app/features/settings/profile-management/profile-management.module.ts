import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { ChangePasswordComponent } from "./containers/change-password/change-password.component";

import { ProfileManagementRoutingRoutingModule } from "./profile-management-routing.module";
import { ChangePasswordFormComponent } from "./components/change-password-form/change-password-form.component";
import { ProfileService } from "./services/profile.service";
import { SharedModule } from "@shared/shared.module";

@NgModule({
  declarations: [ChangePasswordComponent, ChangePasswordFormComponent],
  imports: [CommonModule, ProfileManagementRoutingRoutingModule, SharedModule],
  providers: [ProfileService]
})
export class ProfileManagementModule {}
