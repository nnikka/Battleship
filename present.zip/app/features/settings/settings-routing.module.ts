import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

const routes: Routes = [
  {
    path: "profile",
    loadChildren: () => import("./profile-management/profile-management.module").then(m => m.ProfileManagementModule),
    data: { title: "Profile" }
  },
  {
    path: "user-management",
    loadChildren: () => import("./user-management/user-management.module").then(m => m.UserManagementModule),
    data: { title: "User management" }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProfileManagementRoutingRoutingModule {}
