import { ErrorHandler, Injectable } from "@angular/core";
import { HttpErrorResponse } from "@angular/common/http";
import { Router } from "@angular/router";
import { NotificationMessageService } from "../services/notification-message.service";

@Injectable()
export class GlobalErrorHandler implements ErrorHandler {
  constructor(private notificationMessageService: NotificationMessageService) {}

  handleError(error) {
    if (!(error instanceof HttpErrorResponse)) {
      const clientStack = error.stack;
      let clientMessage;
      if (!navigator.onLine) {
        clientMessage = "No Internet Connection";
      } else {
        clientMessage = error.message ? error.message : error.toString();
      }
      // this.notificationMessageService.error(clientMessage)
      window.location.href = "./error";
    }
  }
}
