import { Injectable } from "@angular/core";
import { Title } from "@angular/platform-browser";

@Injectable()
export class DynamicTitleService {
  constructor(private titleService: Title) {}

  updateTitle(text: string) {
    const oldTitle = this.titleService.getTitle();
    this.titleService.setTitle(`${oldTitle} - ${text}`);
  }
}
