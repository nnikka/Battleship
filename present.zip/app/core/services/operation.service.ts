import { Injectable } from "@angular/core";
import { ConfigService } from "@env/service/config.service";
import { Observable } from "rxjs";
import { HttpClient } from "@angular/common/http";

export enum EOperationType {
  Stock = 1,
  Bond = 2,
  BondPayout = 4,
  FX = 8,
  cash = 16,
  Pledge = 32,
}

@Injectable()
export class OperationService {
  constructor(private http: HttpClient, private configService: ConfigService) { }

  makeOperationTransactions(operationId: string | number, operationType: number): Observable<any> {
    return this.http.put(
      // tslint:disable
      `${this.configService.config.apiBaseurl}/api/Operations/MakeOperationTransactions/${operationId}/${operationType}`,
      {}
    );
  }
}
