import { Injectable } from "@angular/core";

export interface ICountDownResult {
  expired: boolean;
  result: string;
}

@Injectable()
export class TimerService {
  constructor() {}

  countDown(countDownInputDate: number | string): ICountDownResult {
    const result: ICountDownResult = {
      expired: null,
      result: null
    };

    let countDownDate: number = null;
    if (typeof countDownInputDate === "string") {
      const st = countDownInputDate.substr(0, 10);
      const pattern = /(\d{2})\.(\d{2})\.(\d{4})/;
      countDownDate = new Date(st.replace(pattern, "$3-$2-$1")).getTime();
    } else {
      countDownDate = countDownInputDate;
    }

    const now = Date.now();
    let distance = countDownDate - now;

    if (distance < 0) {
      result.expired = true;
    }

    distance = Math.abs(distance);

    const days = Math.floor(distance / (1000 * 60 * 60 * 24));
    const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((distance % (1000 * 60)) / 1000);

    result.result = (days ? days + "d " : "") + (hours ? hours + "h " : "") + minutes + "m " + seconds + "s ";

    return result;
  }
}
