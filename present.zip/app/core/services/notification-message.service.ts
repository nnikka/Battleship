import { Injectable } from "@angular/core";
import { NotificationService, NotificationRef } from "@progress/kendo-angular-notification";
import { INotificationRefHolder } from "@core/models/INotificationRefHolder";

@Injectable()
export class NotificationMessageService {
  errors: INotificationRefHolder[] = [];

  constructor(private notificationService: NotificationService) {}

  clearErrors() {
    this.errors.map(err => {
      if (Date.now() - err.timestamp > 3000 && err.ref.notification.instance) {
        err.ref.notification.instance.close.emit();
      }
    });
    this.errors = [];
  }

  error(content: string = "Error happened"): void {
    const err = this.notificationService.show({
      content,
      hideAfter: 30000,
      position: { horizontal: "right", vertical: "bottom" },
      animation: { type: "slide", duration: 200 },
      type: { style: "error", icon: true },
      closable: true
    });
    this.errors.push({ timestamp: Date.now(), ref: err });
  }

  warn(content: string, vertical: "top" | "bottom" = "bottom"): void {
    this.notificationService.show({
      content,
      hideAfter: 7000,
      position: { horizontal: "right", vertical },
      animation: { type: "slide", duration: 200 },
      type: { style: "warning", icon: true }
    });
  }

  info(content: string): void {
    this.notificationService.show({
      content,
      hideAfter: 7000,
      position: { horizontal: "right", vertical: "bottom" },
      animation: { type: "slide", duration: 200 },
      type: { style: "info", icon: true }
    });
  }

  success(content: string = "Some content"): void {
    this.notificationService.show({
      content,
      hideAfter: 7000,
      position: { horizontal: "right", vertical: "bottom" },
      animation: { type: "slide", duration: 200 },
      type: { style: "success", icon: true }
    });
  }
}
