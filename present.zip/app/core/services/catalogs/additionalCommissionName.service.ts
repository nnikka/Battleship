import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { ConfigService } from "@env/service/config.service";
import { IAdditionalCommision } from "../../models/catalogs/additionalCommision.interface";

@Injectable()
export class AdditionalCommissionService {
  constructor(private http: HttpClient, private configService: ConfigService) {}

  get(): Observable<IAdditionalCommision[]> {
    return this.http.get<IAdditionalCommision[]>(
      `${this.configService.config.apiBaseurl}/api/AdditionalCommissionNames`
    );
  }
}
