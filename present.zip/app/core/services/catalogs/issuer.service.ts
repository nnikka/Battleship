import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { ConfigService } from "@env/service/config.service";
import { IIssuer } from "../../models/catalogs/issuer.interface";

@Injectable()
export class IssuerService {
  constructor(private http: HttpClient, private configService: ConfigService) {}

  get(): Observable<IIssuer[]> {
    return this.http.get<IIssuer[]>(`${this.configService.config.apiBaseurl}/api/Clients/GetIssuers`);
  }
}
