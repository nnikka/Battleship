import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { ConfigService } from "@env/service/config.service";
import { IReferenceRate } from "../../models/catalogs/referenceRate.interface";

@Injectable()
export class ReferenceRateCatalogService {
  constructor(private http: HttpClient, private configService: ConfigService) {}

  get(): Observable<IReferenceRate[]> {
    return this.http.get<IReferenceRate[]>(`${this.configService.config.apiBaseurl}/api/Bonds/GetReferenceRates`);
  }
}
