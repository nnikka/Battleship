import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { ConfigService } from "@env/service/config.service";
import { ICurrency, IRatesForCurrency } from "../../models/catalogs/currency.interface";

@Injectable()
export class CurrencyService {
  constructor(private http: HttpClient, private configService: ConfigService) {}

  get(): Observable<ICurrency[]> {
    return this.http.get<ICurrency[]>(`${this.configService.config.apiBaseurl}/api/Currencies`);
  }

  getRatesForSingleCurrency(id, date): Observable<IRatesForCurrency> {
    return this.http.post<IRatesForCurrency>(
      `${this.configService.config.apiBaseurl}/api/CurrencyRates/GetRatesForSingleCurrency?id=${id}&date=${
        date ? date : ""
      }`,
      {}
    );
  }
}
