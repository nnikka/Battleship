import { Injectable } from "@angular/core";
import { Router, RouterEvent, NavigationEnd } from "@angular/router";

@Injectable()
export class RouterExtService {
  private previousUrl: string = undefined;
  private currentUrl: string = undefined;

  constructor(private router: Router) {
    this.currentUrl = this.router.url;
    router.events.subscribe((event: RouterEvent) => {
      if (event instanceof NavigationEnd) {
        this.previousUrl = this.currentUrl;
        this.currentUrl = event.url;
      }
    });
  }

  private queryStringToObject(queryString) {
    const queryObj = {};
    if (queryString) {
      queryString.split("&").map(item => {
        const splitItem = item.split("=");
        if (splitItem[0] && splitItem[1]) {
          queryObj[splitItem[0]] = splitItem[1];
        }
      });
    }
    return queryObj;
  }

  public handleRedirectionToList(listRoute: string) {
    if (this.previousUrl.split("?")[0] === listRoute) {
      this.router.navigate([listRoute]);
    } else {
      if (this.previousUrl.split("?")[1]) {
        this.router.navigate([this.previousUrl.split("?")[0]], {
          queryParams: this.queryStringToObject(this.previousUrl.split("?")[1])
        });
      } else {
        this.router.navigate([listRoute]);
      }
    }
  }

  public getPreviousUrl() {
    return this.previousUrl;
  }
}
