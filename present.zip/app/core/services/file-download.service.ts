import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { ConfigService } from "@env/service/config.service";

@Injectable()
export class FileDownloadService {
  constructor(private http: HttpClient, private configService: ConfigService) {}

  download(workDir: string, fileName: string) {
    return this.http.get(`${this.configService.config.apiBaseurl}/api/DownloadFile/`, {
      params: { workDir, fileName },
      responseType: "blob"
    });
  }

  downLoadFile(filename: string, data: any) {
    const blob = new Blob([data]);

    const link = document.createElement("a");
    link.href = window.URL.createObjectURL(blob);
    link.download = filename;
    link.click();
  }
}
