import { Injectable } from "@angular/core";
import {
  Router,
  NavigationStart,
  NavigationEnd,
  NavigationCancel,
  NavigationError,
  Event as RouterEvent,
  ActivatedRoute
} from "@angular/router";
import { PageLoaderService } from "../../components/page-loader/page-loader.service";
import { Title } from "@angular/platform-browser";

@Injectable()
export class LazyLoadModuleLoading {
  // es agaraa sachiro mara iyos mainc raici raxdeba.
  private counter: number = 0;

  get isLoading(): boolean {
    return this.counter > 0;
  }

  constructor(
    private router: Router,
    private titleService: Title,
    private activatedRoute: ActivatedRoute,
    private pageLoaderService: PageLoaderService
  ) {}

  startCounting() {
    this.router.events.subscribe((value: RouterEvent) => {
      switch (true) {
        case value instanceof NavigationStart: {
          this.counter++;
          this.pageLoaderService.show();
          break;
        }
        case value instanceof NavigationEnd:
        case value instanceof NavigationCancel:
        case value instanceof NavigationError: {
          let child = this.activatedRoute.firstChild;
          if (child) {
            while (child.firstChild) {
              child = child.firstChild;
            }
            if (child.snapshot.data.title) {
              this.titleService.setTitle(child.snapshot.data.title);
            } else {
              this.titleService.setTitle("TBC Capital");
            }
          }
          this.counter = 0;
          this.pageLoaderService.hide();
          break;
        }

        // case value instanceof RouteConfigLoadStart: {
        //     this.counter++;
        //     break;
        // }
        // case value instanceof RouteConfigLoadEnd: {
        //     this.counter--;
        //     break;
        // }

        // case value instanceof ChildActivationStart:
        // case value instanceof ActivationStart:
        // case value instanceof ResolveStart:
        // case value instanceof GuardsCheckStart: {
        //     this.counter++;
        //     break;
        // }
        // case value instanceof ChildActivationEnd:
        // case value instanceof ActivationEnd:
        // case value instanceof ResolveEnd:
        // case value instanceof GuardsCheckEnd: {
        //     this.counter--;
        //     break;
        // }

        default: {
          break;
        }
      }
    });
  }
}
