import { Component, OnInit, OnDestroy } from "@angular/core";
import { Location } from "@angular/common";
import { ActivatedRoute } from "@angular/router";
import { untilDestroyed } from "ngx-take-until-destroy";

@Component({
  selector: "app-error",
  templateUrl: "./error.component.html",
  styleUrls: ["./error.component.scss"]
})
export class ErrorComponent implements OnInit, OnDestroy {
  errorCode: string;

  constructor(private location: Location, private route: ActivatedRoute) {}

  ngOnInit() {
    this.route.queryParams.pipe(untilDestroyed(this)).subscribe(params => {
      this.errorCode = params.errorCode;
    });
  }

  back() {
    this.location.back();
  }

  ngOnDestroy() {}
}
