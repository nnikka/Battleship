export interface IOperationTransaction {
  id: number;
  assetTypeName: string;
  audit: {
    createDate: string;
    createUserFullName: string;
    createUserId: number;
    lastModifiedDate: string;
    lastModifiedUserFullName: string;
    lastModifiedUserId: number;
    status: number;
  };
  clientName: string;
  comment: string;
  creditAmount: number;
  debitAmount: string;
  operationTypeName: string;
  productName: string;
  transactionDate: string;
  transactionStatus: string;
  transactionTypeName: string;
  currencyName: string;
  transactionStatusMessage: string;
}
