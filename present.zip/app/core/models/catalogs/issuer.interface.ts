export interface IIssuer {
  id: number;
  name: string;
  ticker: string;
  status: number;
}
