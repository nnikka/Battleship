export interface IReferenceRate {
  id: number;
  name: string;
}
