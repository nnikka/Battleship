export interface ICurrency {
  id: number;
  name: string;
}

export interface IRate {
  date: string;
  rate: number;
  fromCurrencyId: number;
  fromCurrency: {
    name: string;
    id: number;
  };
  toCurrencyId: number;
  toCurrency: string;
  id: number;
}

export interface IRatesForCurrency {
  baseCurrencyId: number;
  baseCurrency: string;
  rates: IRate[];
}
