export interface ICounterParty {
  id: number;
  name: string;
  status: number;
}
