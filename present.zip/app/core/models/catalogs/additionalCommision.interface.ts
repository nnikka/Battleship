export interface IAdditionalCommision {
  id: number;
  name: string;
}
