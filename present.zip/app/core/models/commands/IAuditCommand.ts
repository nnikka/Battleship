export interface IAuditCommand {
  createUserId: number;
  lastModifiedUserId: number;
  createDate: string;
  status: number;
}
