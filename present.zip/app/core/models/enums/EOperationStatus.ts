export enum EOperationStatus {
  Pending = 1,
  Success = 2,
  Fail = 4,
  Canceled = 8,
  Terminated = 16
}

export enum EOperationStatusColor {
  Pending = "#ffc107",
  Success = "#28a745",
  Fail = "#fb311c",
  Canceled = "#6c757d",
  Terminated = "#4b5057"
}
