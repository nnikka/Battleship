import { NotificationRef } from "@progress/kendo-angular-notification";

export interface INotificationRefHolder {
  timestamp: number;
  ref: NotificationRef;
}
