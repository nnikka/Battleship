export enum Roles {
  NormalUser = "NormalUser",
  Admin = "Administrator"
}
