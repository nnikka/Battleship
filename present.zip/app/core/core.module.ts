import { NgModule, ErrorHandler } from "@angular/core";
import { CommonModule } from "@angular/common";
import { environment } from "@env/environment";

import { StoreModule } from "@ngrx/store";
import { StoreDevtoolsModule } from "@ngrx/store-devtools";
import { EffectsModule } from "@ngrx/effects";
import { appReducers } from "./store/app.reducer";
import { appEffects } from "./store/app.effect";

import { AppRoutingModule } from "../app-routing.module";
import { ErrorComponent } from "./pages/error/error.component";
import { NotFoundComponent } from "./pages/not-found/not-found.component";
import { DialogModule } from "@progress/kendo-angular-dialog";
import { ButtonModule } from "@progress/kendo-angular-buttons";
import { NotificationModule } from "@progress/kendo-angular-notification";
import { NotificationMessageService } from "./services/notification-message.service";
import { RoutingStateService } from "./services/routing-state.service";
import { LazyLoadModuleLoading } from "./services/lazy-load-modules-loading.service";
import { CountriesService } from "./services/catalogs/countries.service";
import { CurrencyService } from "./services/catalogs/currency.service";
import { IssuerService } from "./services/catalogs/issuer.service";
import { CounterPartyService } from "./services/catalogs/counterParty.service";
import { FileDownloadService } from "./services/file-download.service";
import { ReferenceRateCatalogService } from "./services/catalogs/referenceRate.service";
import { AdditionalCommissionService } from "./services/catalogs/additionalCommissionName.service";
import { RouterExtService } from "./services/router-ext.service";
import { TimerService } from "./services/timer.service";
import { OperationService } from "./services/operation.service";

import { ResponseMessageInterceptor } from "./interceptors/response-message.interceptor";
import { AuthRequestInterceptor } from "./interceptors/auth-request.interceptor";
import { HTTP_INTERCEPTORS } from "@angular/common/http";

import { RolesRequiredGuard } from "./guards/roles-required.guard";
import { ConfirmDeactivateGuard } from "./guards/confirm-deactivate-guard.guard";

import { CountriesResolver } from "./resolvers/catalogs/countries.resolver";
import { CurrencyResolver } from "./resolvers/catalogs/currency.resolver";
import { IssuerResolver } from "./resolvers/catalogs/issuer.resolver";
import { CounterPartyResolver } from "./resolvers/catalogs/counterParty.resolver";
import { ReferenceRateResolver } from "./resolvers/catalogs/referenceRate.resolver";
import { AdditionalCommissionResolver } from "./resolvers/catalogs/additionalCommission.resolver";

import { GlobalErrorHandler } from "./handlers/global-error.handler";
import { from } from "rxjs";

@NgModule({
  declarations: [ErrorComponent, NotFoundComponent],
  imports: [
    CommonModule,
    AppRoutingModule,
    ButtonModule,
    DialogModule,
    NotificationModule,

    StoreModule.forRoot(appReducers),
    EffectsModule.forRoot(appEffects),
    !environment.production ? StoreDevtoolsModule.instrument() : []
  ],
  exports: [AppRoutingModule],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: ResponseMessageInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: AuthRequestInterceptor, multi: true },
    // { provide: ErrorHandler, useClass: GlobalErrorHandler },
    NotificationMessageService,
    LazyLoadModuleLoading,
    RoutingStateService,
    CountriesService,
    CurrencyService,
    IssuerService,
    CounterPartyService,
    FileDownloadService,
    ReferenceRateCatalogService,
    AdditionalCommissionService,
    RouterExtService,
    TimerService,
    OperationService,

    RolesRequiredGuard,
    ConfirmDeactivateGuard,

    CountriesResolver,
    CurrencyResolver,
    IssuerResolver,
    CounterPartyResolver,
    ReferenceRateResolver,
    AdditionalCommissionResolver
  ]
})
export class CoreModule {}
