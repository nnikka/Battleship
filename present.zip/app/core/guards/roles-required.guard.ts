import { ActivatedRouteSnapshot, CanActivate, CanLoad, Route, Router, RouterStateSnapshot } from "@angular/router";
import { AuthService } from "@auth/services/auth.service";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { LoginRedirectService } from "@auth/services/login-redirect.service";
import { RoutingStateService } from "@core/services/routing-state.service";

@Injectable()
export class RolesRequiredGuard implements CanActivate, CanLoad {
  constructor(
    private authService: AuthService,
    private router: Router,
    private urlService: LoginRedirectService,
    private routingStateService: RoutingStateService
  ) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    if (route.data.roles && !this.authService.getUserRoles().some(r => route.data.roles.indexOf(r) >= 0)) {
      this.router.navigate([this.routingStateService.getPreviousUrl()]);
      return false;
    }
    return true;
  }

  canLoad(route: Route): Observable<boolean> | Promise<boolean> | boolean {
    return true;
  }
}
