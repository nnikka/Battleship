import { CanDeactivate } from "@angular/router";
import { Injectable } from "@angular/core";
import { ChangesDetector } from "../../general/abstractClasses/ChangesDetector.abstractClass";
import { PopupConfirmService } from "../../components/popup-confirm/popup-confirm.service";
import { Observable } from "rxjs";

@Injectable()
export class ConfirmDeactivateGuard implements CanDeactivate<ChangesDetector> {
  constructor(private popupConfirmService: PopupConfirmService) {}

  canDeactivate(target: ChangesDetector): boolean | Observable<boolean> {
    if (!target.hasUnsavedChanges()) {
      return true;
    } else {
      if (confirm("Are you sure you want to leave this page, changes will be lost?")) {
        return true;
      } else {
        return false;
      }
    }
  }
}
