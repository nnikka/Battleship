import {
  HttpEvent,
  HttpEventType,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
  HttpResponse,
  HttpErrorResponse
} from "@angular/common/http";
import { Observable, throwError } from "rxjs";
import { map, catchError } from "rxjs/operators";
import { Injectable } from "@angular/core";
import { NotificationMessageService } from "../services/notification-message.service";
import { Router } from "@angular/router";

@Injectable()
export class ResponseMessageInterceptor implements HttpInterceptor {
  blobErrorReader = new FileReader();

  constructor(private notificationMessageService: NotificationMessageService, private router: Router) {
    console.log("HERE");
    this.blobErrorReader.onload = () => {
      const errors = JSON.parse(this.blobErrorReader.result.toString());
      this.notificationMessageService.error(errors.errors[0]);
    };
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    // console.log('interceptor', req)
    return next.handle(req).pipe(
      map((event: HttpEvent<any>) => {
        this.notificationMessageService.clearErrors();
        if (event instanceof HttpResponse) {
          // console.log('Response message interceptor event--->>> ', event);
        }
        return event;
      }),
      catchError((errorResponse: HttpErrorResponse) => {
        this.notificationMessageService.clearErrors();
        if (errorResponse.status === 401) {
          this.router.navigateByUrl("/auth/logout");
        } else if (errorResponse.status === 403) {
          this.notificationMessageService.error("Access is denied, contact support");
          this.router.navigateByUrl("/auth/logout");
        } else if (errorResponse.error) {
          if (errorResponse.error instanceof Blob) {
            this.blobErrorReader.readAsText(errorResponse.error);
          } else {
            if (
              errorResponse.error.errors &&
              errorResponse.error.errors instanceof Array &&
              errorResponse.error.errors.length > 0
            ) {
              for (const errorMessage of errorResponse.error.errors) {
                this.notificationMessageService.error(errorMessage);
              }
            } else if (errorResponse.error.error) {
              this.notificationMessageService.error(errorResponse.error.error);
            }
          }
        }
        return throwError(errorResponse);
      })
    );
  }
}
