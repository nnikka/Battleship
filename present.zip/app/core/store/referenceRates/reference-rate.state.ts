import { IReferenceRate } from "../../models/catalogs/referenceRate.interface";

export interface IReferenceRateState {
  referenceRates: IReferenceRate[];
  loaded: boolean;
  failed: boolean;
  lastUpdated: Date;
}

export const initialReferenceRatestate = {
  referenceRates: [],
  loaded: false,
  failed: false,
  lastUpdated: null
};
