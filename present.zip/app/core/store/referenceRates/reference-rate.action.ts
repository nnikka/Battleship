import { Action } from "@ngrx/store";
import { IReferenceRate } from "../../models/catalogs/referenceRate.interface";
export enum EReferenceRateActions {
  GetReferenceRates = "[Reference rates] Get Reference Rates",
  GetReferenceRatesSuccess = "[Reference rates] Get Reference Rates Success",
  GetReferenceRatesFailed = "[Reference rates] Get Reference Rates Failed",
  ClearReferenceRate = "[Reference rates] Clear Reference Rate"
}

export class GetReferenceRates implements Action {
  public readonly type = EReferenceRateActions.GetReferenceRates;
}

export class GetReferenceRatesSuccess implements Action {
  public readonly type = EReferenceRateActions.GetReferenceRatesSuccess;
  constructor(public payload: IReferenceRate[]) {}
}

export class GetReferenceRatesFailed implements Action {
  public readonly type = EReferenceRateActions.GetReferenceRatesFailed;
}

export class ClearReferenceRate implements Action {
  public readonly type = EReferenceRateActions.ClearReferenceRate;
}

export type ReferenceRateActions =
  | GetReferenceRates
  | GetReferenceRatesSuccess
  | GetReferenceRatesFailed
  | ClearReferenceRate;
