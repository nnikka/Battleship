import { createSelector } from "@ngrx/store";

import { IAppState } from "../app.state";
import { IReferenceRateState } from "./reference-rate.state";

const selectReferenceRateState = (state: IAppState) => state.referenceRate;

export const selectReferenceRates = createSelector(
  selectReferenceRateState,
  (state: IReferenceRateState) => state.referenceRates
);

export const selectReferenceRateLoadStatus = createSelector(
  selectReferenceRateState,
  (state: IReferenceRateState) => state.loaded
);

export const selectReferenceRateStatuses = createSelector(selectReferenceRateState, (state: IReferenceRateState) => {
  return { failed: state.failed, loaded: state.loaded, lastUpdated: state.lastUpdated };
});
