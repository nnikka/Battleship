import { EReferenceRateActions, ReferenceRateActions } from "./reference-rate.action";
import { IReferenceRateState, initialReferenceRatestate } from "./reference-rate.state";

export function referenceRateReducer(
  state = initialReferenceRatestate,
  action: ReferenceRateActions
): IReferenceRateState {
  switch (action.type) {
    case EReferenceRateActions.GetReferenceRatesSuccess: {
      return {
        ...state,
        referenceRates: action.payload,
        lastUpdated: new Date(),
        loaded: true
      };
    }
    case EReferenceRateActions.GetReferenceRatesFailed: {
      return {
        ...state,
        ...initialReferenceRatestate,
        failed: true
      };
    }
    case EReferenceRateActions.ClearReferenceRate: {
      return {
        ...state,
        ...initialReferenceRatestate
      };
    }
    default:
      return state;
  }
}
