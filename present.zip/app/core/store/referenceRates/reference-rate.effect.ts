import { Injectable } from "@angular/core";
import { Effect, ofType, Actions } from "@ngrx/effects";
import { of } from "rxjs";
import { switchMap, map, catchError } from "rxjs/operators";

import { ReferenceRateCatalogService } from "../../services/catalogs/referenceRate.service";
import {
  EReferenceRateActions,
  GetReferenceRates,
  GetReferenceRatesSuccess,
  GetReferenceRatesFailed
} from "./reference-rate.action";
import { IReferenceRate } from "@core/models/catalogs/referenceRate.interface";

@Injectable()
export class ReferenceRateEffects {
  @Effect()
  referenceRates$ = this._actions.pipe(
    ofType<GetReferenceRates>(EReferenceRateActions.GetReferenceRates),
    switchMap(() => {
      return this._referenceRateService.get().pipe(
        map((referenceRates: IReferenceRate[]) => new GetReferenceRatesSuccess(referenceRates)),
        catchError(error => of(new GetReferenceRatesFailed()))
      );
    })
  );

  constructor(private _actions: Actions, private _referenceRateService: ReferenceRateCatalogService) {}
}
