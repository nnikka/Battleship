import { ICurrency } from "../../models/catalogs/currency.interface";

export interface ICurrencyState {
  currencies: ICurrency[];
  loaded: boolean;
  failed: boolean;
  lastUpdated: Date;
}

export const initialCurrencyState = {
  currencies: [],
  loaded: false,
  failed: false,
  lastUpdated: null
};
