import { ECurrencyActions, CurrencyActions } from "./currency.action";
import { ICurrencyState, initialCurrencyState } from "./currency.state";

export function currencyReducer(state = initialCurrencyState, action: CurrencyActions): ICurrencyState {
  switch (action.type) {
    case ECurrencyActions.GetCurrenciesSuccess: {
      return {
        ...state,
        currencies: action.payload,
        lastUpdated: new Date(),
        loaded: true
      };
    }
    case ECurrencyActions.GetCurrenciesFailed: {
      return {
        ...state,
        ...initialCurrencyState,
        failed: true
      };
    }
    case ECurrencyActions.ClearCurrency: {
      return {
        ...state,
        ...initialCurrencyState
      };
    }
    default:
      return state;
  }
}
