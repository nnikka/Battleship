import { Action } from "@ngrx/store";
import { ICurrency } from "../../models/catalogs/currency.interface";
export enum ECurrencyActions {
  GetCurrencies = "[Currency] Get Currencies",
  GetCurrenciesSuccess = "[Currency] Get Currencies Success",
  GetCurrenciesFailed = "[Currency] Get Currencies Failed",
  ClearCurrency = "[Currency] Clear Currency"
}

export class GetCurrencies implements Action {
  public readonly type = ECurrencyActions.GetCurrencies;
}

export class GetCurrenciesSuccess implements Action {
  public readonly type = ECurrencyActions.GetCurrenciesSuccess;
  constructor(public payload: ICurrency[]) {}
}

export class GetCurrenciesFailed implements Action {
  public readonly type = ECurrencyActions.GetCurrenciesFailed;
}

export class ClearCurrency implements Action {
  public readonly type = ECurrencyActions.ClearCurrency;
}

export type CurrencyActions = GetCurrencies | GetCurrenciesSuccess | GetCurrenciesFailed | ClearCurrency;
