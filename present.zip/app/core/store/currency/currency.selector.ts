import { createSelector } from "@ngrx/store";

import { IAppState } from "../app.state";
import { ICurrencyState } from "./currency.state";

const selectCurrencyState = (state: IAppState) => state.currency;

export const selectCurrencies = createSelector(selectCurrencyState, (state: ICurrencyState) => state.currencies);

export const selectCurrencyLoadStatus = createSelector(selectCurrencyState, (state: ICurrencyState) => state.loaded);

export const selectCurrencyStatuses = createSelector(selectCurrencyState, (state: ICurrencyState) => {
  return { failed: state.failed, loaded: state.loaded, lastUpdated: state.lastUpdated };
});
