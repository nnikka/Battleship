import { Injectable } from "@angular/core";
import { Effect, ofType, Actions } from "@ngrx/effects";
import { of } from "rxjs";
import { switchMap, map, catchError } from "rxjs/operators";

import { CurrencyService } from "../../services/catalogs/currency.service";
import { ECurrencyActions, GetCurrencies, GetCurrenciesSuccess, GetCurrenciesFailed } from "./currency.action";
import { ICurrency } from "@core/models/catalogs/currency.interface";

@Injectable()
export class CurrencyEffects {
  @Effect()
  getCurrencies$ = this._actions.pipe(
    ofType<GetCurrencies>(ECurrencyActions.GetCurrencies),
    switchMap(() => {
      return this._currencyService.get().pipe(
        map((currencies: ICurrency[]) => new GetCurrenciesSuccess(currencies)),
        catchError(error => of(new GetCurrenciesFailed()))
      );
    })
  );

  constructor(private _actions: Actions, private _currencyService: CurrencyService) {}
}
