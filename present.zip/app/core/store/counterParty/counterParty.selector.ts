import { createSelector } from "@ngrx/store";

import { IAppState } from "../app.state";
import { ICounterPartyState } from "./counterParty.state";
import { EClientStatuses } from "@features/static-data/clients/models/ClientStatuses.enum";

const selectCounterPartyState = (state: IAppState) => state.counterParty;

export const selectCounterParties = createSelector(
  selectCounterPartyState,
  (state: ICounterPartyState) => state.counterParties
);

export const selectAuthorizedCounterParties = createSelector(selectCounterPartyState, (state: ICounterPartyState) => {
  return state.counterParties.filter(cp => cp.status === EClientStatuses.Authorized);
});

export const selectCounterPartyLoadStatus = createSelector(
  selectCounterPartyState,
  (state: ICounterPartyState) => state.loaded
);

export const selectCounterPartyStatuses = createSelector(selectCounterPartyState, (state: ICounterPartyState) => {
  return { failed: state.failed, loaded: state.loaded, lastUpdated: state.lastUpdated };
});
