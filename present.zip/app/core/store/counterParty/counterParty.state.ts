import { ICounterParty } from "../../models/catalogs/counterParty.interface";

export interface ICounterPartyState {
  counterParties: ICounterParty[];
  loaded: boolean;
  failed: boolean;
  lastUpdated: Date;
}

export const initialCounterPartyState = {
  counterParties: [],
  loaded: false,
  failed: false,
  lastUpdated: null
};
