import { Action } from "@ngrx/store";
import { ICounterParty } from "../../models/catalogs/counterParty.interface";
export enum ECounterPartyActions {
  GetCounterParties = "[CounterParty] Get CounterParties",
  GetCounterPartiesSuccess = "[CounterParty] Get CounterParties Success",
  GetCounterPartiesFailed = "[CounterParty] Get CounterParties Failed",
  ClearCounterParty = "[CounterParty] Clear ClearCounterParty"
}

export class GetCounterParties implements Action {
  public readonly type = ECounterPartyActions.GetCounterParties;
}

export class GetCounterPartiesSuccess implements Action {
  public readonly type = ECounterPartyActions.GetCounterPartiesSuccess;
  constructor(public payload: ICounterParty[]) {}
}

export class GetCounterPartiesFailed implements Action {
  public readonly type = ECounterPartyActions.GetCounterPartiesFailed;
}

export class ClearCounterParty implements Action {
  public readonly type = ECounterPartyActions.ClearCounterParty;
}

export type CounterPartyActions =
  | GetCounterParties
  | GetCounterPartiesSuccess
  | GetCounterPartiesFailed
  | ClearCounterParty;
