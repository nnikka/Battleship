import { Injectable } from "@angular/core";
import { Effect, ofType, Actions } from "@ngrx/effects";
import { of } from "rxjs";
import { switchMap, map, catchError } from "rxjs/operators";

import { CounterPartyService } from "../../services/catalogs/counterParty.service";
import {
  ECounterPartyActions,
  GetCounterParties,
  GetCounterPartiesSuccess,
  GetCounterPartiesFailed
} from "./counterParty.action";
import { ICounterParty } from "@core/models/catalogs/counterParty.interface";

@Injectable()
export class CounterPartyEffects {
  @Effect()
  getCounterParties$ = this._actions.pipe(
    ofType<GetCounterParties>(ECounterPartyActions.GetCounterParties),
    switchMap(() => {
      return this._counterPartyService.get().pipe(
        map((counterParties: ICounterParty[]) => new GetCounterPartiesSuccess(counterParties)),
        catchError(error => of(new GetCounterPartiesFailed()))
      );
    })
  );

  constructor(private _actions: Actions, private _counterPartyService: CounterPartyService) {}
}
