import { ECounterPartyActions, CounterPartyActions } from "./counterParty.action";
import { ICounterPartyState, initialCounterPartyState } from "./counterParty.state";

export function counterPartyReducer(state = initialCounterPartyState, action: CounterPartyActions): ICounterPartyState {
  switch (action.type) {
    case ECounterPartyActions.GetCounterPartiesSuccess: {
      return {
        ...state,
        counterParties: action.payload,
        lastUpdated: new Date(),
        loaded: true
      };
    }
    case ECounterPartyActions.GetCounterPartiesFailed: {
      return {
        ...state,
        ...initialCounterPartyState,
        failed: true
      };
    }
    case ECounterPartyActions.ClearCounterParty: {
      return {
        ...state,
        ...initialCounterPartyState
      };
    }
    default:
      return state;
  }
}
