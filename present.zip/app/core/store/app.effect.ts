import { CountriesEffects } from "./countries/countries.effect";
import { CurrencyEffects } from "./currency/currency.effect";
import { CounterPartyEffects } from "./counterParty/counterParty.effect";
import { IssuerEffects } from "./issuer/issuer.effect";
import { ReferenceRateEffects } from "./referenceRates/reference-rate.effect";
import { AdditionalCommissionEffects } from "./additionalCommission/additionalCommission.effect";

export const appEffects = [
  CountriesEffects,
  CurrencyEffects,
  CounterPartyEffects,
  IssuerEffects,
  ReferenceRateEffects,
  AdditionalCommissionEffects
];
