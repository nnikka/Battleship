import { ICountriesState, initialCountriesState } from "./countries/countries.state";
import { ICurrencyState, initialCurrencyState } from "./currency/currency.state";
import { ICounterPartyState, initialCounterPartyState } from "./counterParty/counterParty.state";
import { IIssuerState, initialIssuerState } from "./issuer/issuer.state";
import { IReferenceRateState, initialReferenceRatestate } from "./referenceRates/reference-rate.state";
import {
  IAdditionalCommisionState,
  initialAdditionalCommissionState
} from "./additionalCommission/additionalCommission.state";

export interface IAppState {
  countries: ICountriesState;
  currency: ICurrencyState;
  counterParty: ICounterPartyState;
  issuer: IIssuerState;
  referenceRate: IReferenceRateState;
  additionalCommission: IAdditionalCommisionState;
}

export const initialAppState = {
  countries: initialCountriesState,
  currency: initialCurrencyState,
  counterParty: initialCounterPartyState,
  issuer: initialIssuerState,
  referenceRate: initialReferenceRatestate,
  additionalCommission: initialAdditionalCommissionState
};

export function getInitialState(): IAppState {
  return initialAppState;
}
