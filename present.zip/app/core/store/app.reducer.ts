import { ActionReducerMap } from "@ngrx/store";
import { IAppState } from "./app.state";
import { countriesReducer } from "./countries/countries.reducer";
import { currencyReducer } from "./currency/currency.reducer";
import { counterPartyReducer } from "./counterParty/counterParty.reducer";
import { issuerReducer } from "./issuer/issuer.reducer";
import { referenceRateReducer } from "./referenceRates/reference-rate.reducer";
import { additionalCommissionReducer } from "./additionalCommission/additionalCommission.reducer";

export const appReducers: ActionReducerMap<IAppState, any> = {
  countries: countriesReducer,
  currency: currencyReducer,
  counterParty: counterPartyReducer,
  issuer: issuerReducer,
  referenceRate: referenceRateReducer,
  additionalCommission: additionalCommissionReducer
};
