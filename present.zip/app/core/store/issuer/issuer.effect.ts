import { Injectable } from "@angular/core";
import { Effect, ofType, Actions } from "@ngrx/effects";
import { of } from "rxjs";
import { switchMap, map, catchError } from "rxjs/operators";

import { IssuerService } from "../../services/catalogs/issuer.service";
import { EIssuerActions, GetIssuers, GetIssuersSuccess, GetIssuersFailed } from "./issuer.action";
import { IIssuer } from "@core/models/catalogs/issuer.interface";

@Injectable()
export class IssuerEffects {
  @Effect()
  getIssuers$ = this._actions.pipe(
    ofType<GetIssuers>(EIssuerActions.GetIssuers),
    switchMap(() => {
      return this._issuerService.get().pipe(
        map((issuers: IIssuer[]) => new GetIssuersSuccess(issuers)),
        catchError(error => of(new GetIssuersFailed()))
      );
    })
  );

  constructor(private _actions: Actions, private _issuerService: IssuerService) {}
}
