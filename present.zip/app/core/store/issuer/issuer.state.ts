import { IIssuer } from "../../models/catalogs/issuer.interface";

export interface IIssuerState {
  issuers: IIssuer[];
  loaded: boolean;
  failed: boolean;
  lastUpdated: Date;
}

export const initialIssuerState = {
  issuers: [],
  loaded: false,
  failed: false,
  lastUpdated: null
};
