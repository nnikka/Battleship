import { createSelector } from "@ngrx/store";

import { IAppState } from "../app.state";
import { IIssuerState } from "./issuer.state";
import { EClientStatuses } from "@features/static-data/clients/models/ClientStatuses.enum";

const selectIssuerState = (state: IAppState) => state.issuer;

export const selectIssuers = createSelector(selectIssuerState, (state: IIssuerState) => state.issuers);

export const selectAuthorizedIssuers = createSelector(selectIssuerState, (state: IIssuerState) => {
  return state.issuers.filter(iss => iss.status === EClientStatuses.Authorized);
});

export const selectIssuerLoadStatus = createSelector(selectIssuerState, (state: IIssuerState) => state.loaded);

export const selectIssuerStatuses = createSelector(selectIssuerState, (state: IIssuerState) => {
  return { failed: state.failed, loaded: state.loaded, lastUpdated: state.lastUpdated };
});
