import { Action } from "@ngrx/store";
import { IIssuer } from "../../models/catalogs/issuer.interface";
export enum EIssuerActions {
  GetIssuers = "[Issuer] Get Issuers",
  GetIssuersSuccess = "[Issuer] Get Issuers Success",
  GetIssuersFailed = "[Issuer] Get Issuers Failed",
  ClearIssuer = "[Issuer] Clear ClearIssuer"
}

export class GetIssuers implements Action {
  public readonly type = EIssuerActions.GetIssuers;
}

export class GetIssuersSuccess implements Action {
  public readonly type = EIssuerActions.GetIssuersSuccess;
  constructor(public payload: IIssuer[]) {}
}

export class GetIssuersFailed implements Action {
  public readonly type = EIssuerActions.GetIssuersFailed;
}

export class ClearIssuer implements Action {
  public readonly type = EIssuerActions.ClearIssuer;
}

export type IssuerActions = GetIssuers | GetIssuersSuccess | GetIssuersFailed | ClearIssuer;
