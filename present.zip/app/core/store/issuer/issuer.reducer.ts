import { EIssuerActions, IssuerActions } from "./issuer.action";
import { IIssuerState, initialIssuerState } from "./issuer.state";

export function issuerReducer(state = initialIssuerState, action: IssuerActions): IIssuerState {
  switch (action.type) {
    case EIssuerActions.GetIssuersSuccess: {
      return {
        ...state,
        issuers: action.payload,
        lastUpdated: new Date(),
        loaded: true
      };
    }
    case EIssuerActions.GetIssuersFailed: {
      return {
        ...state,
        ...initialIssuerState,
        failed: true
      };
    }
    case EIssuerActions.ClearIssuer: {
      return {
        ...state,
        ...initialIssuerState
      };
    }
    default:
      return state;
  }
}
