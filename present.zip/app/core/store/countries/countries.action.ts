import { Action } from "@ngrx/store";
import { ICountry } from "../../models/catalogs/country.interface";
export enum ECountriesActions {
  GetCountries = "[Countries] Get Countries",
  GetCountriesSuccess = "[Countries] Get Countries Success",
  GetCountriesFailed = "[Countries] Get Countries Failed",
  ClearCountries = "[Countries] Clear Countries"
}

export class GetCountries implements Action {
  public readonly type = ECountriesActions.GetCountries;
}

export class GetCountriesSuccess implements Action {
  public readonly type = ECountriesActions.GetCountriesSuccess;
  constructor(public payload: ICountry[]) {}
}

export class GetCountriesFailed implements Action {
  public readonly type = ECountriesActions.GetCountriesFailed;
}

export class ClearCountries implements Action {
  public readonly type = ECountriesActions.ClearCountries;
}

export type CountriesActions = GetCountries | GetCountriesSuccess | GetCountriesFailed | ClearCountries;
