import { createSelector } from "@ngrx/store";

import { IAppState } from "../app.state";
import { ICountriesState } from "./countries.state";

const selectCountriesState = (state: IAppState) => state.countries;

export const selectCountries = createSelector(selectCountriesState, (state: ICountriesState) => state.countries);

export const selectCountriesLoadStatus = createSelector(selectCountriesState, (state: ICountriesState) => state.loaded);

export const selectCountriesStatuses = createSelector(selectCountriesState, (state: ICountriesState) => {
  return { failed: state.failed, loaded: state.loaded, lastUpdated: state.lastUpdated };
});
