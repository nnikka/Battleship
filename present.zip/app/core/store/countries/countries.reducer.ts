import { ECountriesActions, CountriesActions } from "./countries.action";
import { ICountriesState, initialCountriesState } from "./countries.state";

export function countriesReducer(state = initialCountriesState, action: CountriesActions): ICountriesState {
  switch (action.type) {
    case ECountriesActions.GetCountriesSuccess: {
      return {
        ...state,
        countries: action.payload,
        lastUpdated: new Date(),
        loaded: true
      };
    }
    case ECountriesActions.GetCountriesFailed: {
      return {
        ...state,
        ...initialCountriesState,
        failed: true
      };
    }
    case ECountriesActions.ClearCountries: {
      return {
        ...state,
        ...initialCountriesState
      };
    }
    default:
      return state;
  }
}
