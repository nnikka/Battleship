import { Injectable } from "@angular/core";
import { Effect, ofType, Actions } from "@ngrx/effects";
import { of } from "rxjs";
import { switchMap, map, catchError } from "rxjs/operators";

import { CountriesService } from "../../services/catalogs/countries.service";
import { ECountriesActions, GetCountries, GetCountriesSuccess, GetCountriesFailed } from "./countries.action";
import { ICountry } from "@core/models/catalogs/country.interface";

@Injectable()
export class CountriesEffects {
  @Effect()
  getCountries$ = this._actions.pipe(
    ofType<GetCountries>(ECountriesActions.GetCountries),
    switchMap(() => {
      return this._countriesService.get().pipe(
        map((countries: ICountry[]) => new GetCountriesSuccess(countries)),
        catchError(error => of(new GetCountriesFailed()))
      );
    })
  );

  constructor(private _actions: Actions, private _countriesService: CountriesService) {}
}
