import { ICountry } from "../../models/catalogs/country.interface";

export interface ICountriesState {
  countries: ICountry[];
  loaded: boolean;
  failed: boolean;
  lastUpdated: Date;
}

export const initialCountriesState = {
  countries: [],
  loaded: false,
  failed: false,
  lastUpdated: null
};
