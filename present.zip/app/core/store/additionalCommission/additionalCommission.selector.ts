import { createSelector } from "@ngrx/store";

import { IAppState } from "../app.state";
import { IAdditionalCommisionState } from "./additionalCommission.state";

const selectAdditionalCommissionState = (state: IAppState) => state.additionalCommission;

export const selectAdditionalCommissions = createSelector(
  selectAdditionalCommissionState,
  (state: IAdditionalCommisionState) => state.commissions
);

export const selectAdditionalCommissionLoadStatus = createSelector(
  selectAdditionalCommissionState,
  (state: IAdditionalCommisionState) => state.loaded
);

export const selectAdditionalCommissionStatuses = createSelector(
  selectAdditionalCommissionState,
  (state: IAdditionalCommisionState) => {
    return { failed: state.failed, loaded: state.loaded, lastUpdated: state.lastUpdated };
  }
);
