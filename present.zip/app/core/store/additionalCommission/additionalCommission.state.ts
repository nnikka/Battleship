import { IAdditionalCommision } from "../../models/catalogs/additionalCommision.interface";

export interface IAdditionalCommisionState {
  commissions: IAdditionalCommision[];
  loaded: boolean;
  failed: boolean;
  lastUpdated: Date;
}

export const initialAdditionalCommissionState = {
  commissions: [],
  loaded: false,
  failed: false,
  lastUpdated: null
};
