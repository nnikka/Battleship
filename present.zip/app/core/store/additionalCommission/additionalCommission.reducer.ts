import { EAdditionalCommissionActions, AdditionalCommissionActions } from "./additionalCommission.action";
import { IAdditionalCommisionState, initialAdditionalCommissionState } from "./additionalCommission.state";

export function additionalCommissionReducer(
  state = initialAdditionalCommissionState,
  action: AdditionalCommissionActions
): IAdditionalCommisionState {
  switch (action.type) {
    case EAdditionalCommissionActions.GetAdditionalCommissionsSuccess: {
      return {
        ...state,
        commissions: action.payload,
        lastUpdated: new Date(),
        loaded: true
      };
    }
    case EAdditionalCommissionActions.GetAdditionalCommissionsFailed: {
      return {
        ...state,
        ...initialAdditionalCommissionState,
        failed: true
      };
    }
    case EAdditionalCommissionActions.ClearAdditionalCommission: {
      return {
        ...state,
        ...initialAdditionalCommissionState
      };
    }
    default:
      return state;
  }
}
