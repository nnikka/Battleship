import { Injectable } from "@angular/core";
import { Effect, ofType, Actions } from "@ngrx/effects";
import { of } from "rxjs";
import { switchMap, map, catchError } from "rxjs/operators";

import { AdditionalCommissionService } from "../../services/catalogs/additionalCommissionName.service";
import {
  EAdditionalCommissionActions,
  GetAdditionalCommissions,
  GetAdditionalCommissionsSuccess,
  GetAdditionalCommissionsFailed
} from "./additionalCommission.action";
import { IAdditionalCommision } from "@core/models/catalogs/additionalCommision.interface";

@Injectable()
export class AdditionalCommissionEffects {
  @Effect()
  getAdditionalCommissions$ = this._actions.pipe(
    ofType<GetAdditionalCommissions>(EAdditionalCommissionActions.GetAdditionalCommissions),
    switchMap(() => {
      return this._additionalCommissionService.get().pipe(
        map((commissions: IAdditionalCommision[]) => new GetAdditionalCommissionsSuccess(commissions)),
        catchError(error => of(new GetAdditionalCommissionsFailed()))
      );
    })
  );

  constructor(private _actions: Actions, private _additionalCommissionService: AdditionalCommissionService) {}
}
