import { Action } from "@ngrx/store";
import { IAdditionalCommision } from "../../models/catalogs/additionalCommision.interface";
export enum EAdditionalCommissionActions {
  GetAdditionalCommissions = "[Additional commission] Get Additional Commissions",
  GetAdditionalCommissionsSuccess = "[Additional commission] Get Additional Commissions Success",
  GetAdditionalCommissionsFailed = "[Additional commission] Get Additional Commissions Failed",
  ClearAdditionalCommission = "[Additional commission] Clear Additional Commissions"
}

export class GetAdditionalCommissions implements Action {
  public readonly type = EAdditionalCommissionActions.GetAdditionalCommissions;
}

export class GetAdditionalCommissionsSuccess implements Action {
  public readonly type = EAdditionalCommissionActions.GetAdditionalCommissionsSuccess;
  constructor(public payload: IAdditionalCommision[]) {}
}

export class GetAdditionalCommissionsFailed implements Action {
  public readonly type = EAdditionalCommissionActions.GetAdditionalCommissionsFailed;
}

export class ClearAdditionalCommission implements Action {
  public readonly type = EAdditionalCommissionActions.ClearAdditionalCommission;
}

export type AdditionalCommissionActions =
  | GetAdditionalCommissions
  | GetAdditionalCommissionsSuccess
  | GetAdditionalCommissionsFailed
  | ClearAdditionalCommission;
