import { Injectable } from "@angular/core";
import { Resolve } from "@angular/router";
import { Observable } from "rxjs";
import { Store, select } from "@ngrx/store";
import { IAppState } from "../../store/app.state";
import { selectIssuerStatuses } from "../../store/issuer/issuer.selector";
import { GetIssuers, ClearIssuer } from "../../store/issuer/issuer.action";
import { tap, filter, take, map } from "rxjs/operators";
import { ConfigService } from "@env/service/config.service";

@Injectable()
export class IssuerResolver implements Resolve<boolean> {
  constructor(private store: Store<IAppState>, private configService: ConfigService) {}

  resolve(): Observable<boolean> {
    return this.store.pipe(
      select(selectIssuerStatuses),
      tap((statuses: any) => {
        const duration = statuses.lastUpdated ? Date.now() - new Date(statuses.lastUpdated).getTime() : 0;
        if ((!statuses.loaded || duration > this.configService.config.storeModuleDurationShort) && !statuses.failed) {
          this.store.dispatch(new GetIssuers());
        }
      }),
      filter(statuses => {
        if (statuses.loaded) {
          return true;
        } else if (statuses.failed) {
          this.store.dispatch(new ClearIssuer());
          return true;
        }
      }),
      map(statuses => {
        if (statuses.loaded) {
          return true;
        }
        return false;
      }),
      take(1)
    );
  }
}
