import { Injectable } from "@angular/core";
import { Resolve } from "@angular/router";
import { Observable } from "rxjs";
import { Store, select } from "@ngrx/store";
import { IAppState } from "../../store/app.state";
import { selectCountriesStatuses } from "../../store/countries/countries.selector";
import { GetCountries, ClearCountries } from "../../store/countries/countries.action";
import { tap, filter, take, map } from "rxjs/operators";

@Injectable()
export class CountriesResolver implements Resolve<boolean> {
  constructor(private store: Store<IAppState>) {}

  resolve(): Observable<boolean> {
    return this.store.pipe(
      select(selectCountriesStatuses),
      tap((statuses: any) => {
        if (!statuses.loaded && !statuses.failed) {
          this.store.dispatch(new GetCountries());
        }
      }),
      filter(statuses => {
        if (statuses.loaded) {
          return true;
        } else if (statuses.failed) {
          this.store.dispatch(new ClearCountries());
          return true;
        }
      }),
      map(statuses => {
        if (statuses.loaded) {
          return true;
        }
        return false;
      }),
      take(1)
    );
  }
}
