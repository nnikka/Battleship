import { Injectable } from "@angular/core";
import { Resolve } from "@angular/router";
import { Observable } from "rxjs";
import { Store, select } from "@ngrx/store";
import { IAppState } from "../../store/app.state";
import { selectAdditionalCommissionStatuses } from "../../store/additionalCommission/additionalCommission.selector";
import {
  GetAdditionalCommissions,
  ClearAdditionalCommission
} from "../../store/additionalCommission/additionalCommission.action";
import { tap, filter, take, map } from "rxjs/operators";
import { ConfigService } from "@env/service/config.service";

@Injectable()
export class AdditionalCommissionResolver implements Resolve<boolean> {
  constructor(private store: Store<IAppState>, private configService: ConfigService) {}

  resolve(): Observable<boolean> {
    return this.store.pipe(
      select(selectAdditionalCommissionStatuses),
      tap((statuses: any) => {
        const duration = statuses.lastUpdated ? Date.now() - new Date(statuses.lastUpdated).getTime() : 0;
        if ((!statuses.loaded || duration > this.configService.config.storeModuleDurationShort) && !statuses.failed) {
          this.store.dispatch(new GetAdditionalCommissions());
        }
      }),
      filter(statuses => {
        if (statuses.loaded) {
          return true;
        } else if (statuses.failed) {
          this.store.dispatch(new ClearAdditionalCommission());
          return true;
        }
      }),
      map(statuses => {
        if (statuses.loaded) {
          return true;
        }
        return false;
      }),
      take(1)
    );
  }
}
