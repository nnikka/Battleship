import { Injectable } from "@angular/core";
import { Resolve } from "@angular/router";
import { Observable } from "rxjs";
import { Store, select } from "@ngrx/store";
import { IAppState } from "../../store/app.state";
import { selectReferenceRateStatuses } from "../../store/referenceRates/reference-rate.selector";
import { GetReferenceRates, ClearReferenceRate } from "../../store/referenceRates/reference-rate.action";
import { tap, filter, take, map } from "rxjs/operators";

@Injectable()
export class ReferenceRateResolver implements Resolve<boolean> {
  constructor(private store: Store<IAppState>) {}

  resolve(): Observable<boolean> {
    return this.store.pipe(
      select(selectReferenceRateStatuses),
      tap((statuses: any) => {
        if (!statuses.loaded && !statuses.failed) {
          this.store.dispatch(new GetReferenceRates());
        }
      }),
      filter(statuses => {
        if (statuses.loaded) {
          return true;
        } else if (statuses.failed) {
          this.store.dispatch(new ClearReferenceRate());
          return true;
        }
      }),
      map(statuses => {
        if (statuses.loaded) {
          return true;
        }
        return false;
      }),
      take(1)
    );
  }
}
