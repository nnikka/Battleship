import { Component, OnInit } from "@angular/core";
import { AdminService } from "../services/admin.service";
import { IJobInfo } from "../models/IJobInfo";
import { IBreadcrumb } from "@shared/models/IBreadcrumb";
import { IListItemBondPayoutOperations } from "@features/operations/bond-payouts/models/IListItemBondPayoutOperations";
import { formatDate } from "@telerik/kendo-intl";
import { Router } from "@angular/router";
import { IListItemDividendPayout } from "@features/operations/dividend-payouts/models/IListItemDividendPayout";

@Component({
  selector: "app-welcome",
  templateUrl: "./welcome.component.html",
  styleUrls: ["./welcome.component.scss"]
})
export class WelcomeComponent implements OnInit {
  breadcrumbItems: IBreadcrumb[] = [
    { text: "Home", to: null },
    { text: "Statistics", to: null }
  ];

  lastJobInfo: IJobInfo;
  jobInfoLoading: boolean = true;

  todaysCouponOperations: IListItemBondPayoutOperations[] = [];
  todaysCouponOperationsLoading: boolean = true;
  bondPayoutPageQueryParams: {};

  todaysDividendPayouts: IListItemDividendPayout[] = [];
  todaysDividendPayoutsLoading: boolean = true;
  dividendPayoutsPageQueryParams: {};

  constructor(private adminService: AdminService, private router: Router) {
    this.bondPayoutPageQueryParams = {
      pageIndex: 0,
      pageSize: 15,
      "filterItem.settlementDate": formatDate(new Date(), "MM/dd/yyyy")
    };
    this.dividendPayoutsPageQueryParams = {
      pageIndex: 0,
      pageSize: 15,
      "filterItem.paymentDate": formatDate(new Date(), "MM/dd/yyyy")
    };
  }

  ngOnInit() {
    this.adminService.getJobInfo().subscribe(
      respo => {
        this.lastJobInfo = respo;
        this.jobInfoLoading = false;
      },
      err => {
        this.jobInfoLoading = false;
      }
    );
    this.adminService.getTodaysCoupons().subscribe(
      resp => {
        this.todaysCouponOperations = resp.data;
        this.todaysCouponOperationsLoading = false;
      },
      err => {
        this.todaysCouponOperationsLoading = false;
      }
    );
    this.adminService.getTodaysDividendPayouts().subscribe(
      resp => {
        this.todaysDividendPayouts = resp.data;
        this.todaysDividendPayoutsLoading = false;
      },
      err => {
        this.todaysDividendPayoutsLoading = false;
      }
    );
  }

  redirectToBondPayoutOperation(operationId: number) {
    this.router.navigateByUrl("/admin/operations/bond-payouts/" + operationId);
  }

  redirectToDividendPayoutOperation(operationId: number) {
    this.router.navigateByUrl("/admin/operations/dividend-payouts/" + operationId);
  }
}
