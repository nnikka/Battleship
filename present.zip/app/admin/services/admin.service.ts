import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { ConfigService } from "@env/service/config.service";
import { IJobInfo } from "../models/IJobInfo";
import { IPagingHttpResponse } from "@shared/models/IPagingHttpResponse";
import { IListItemBondPayoutOperations } from "@features/operations/bond-payouts/models/IListItemBondPayoutOperations";
import { formatDate } from "@telerik/kendo-intl";
import { IListItemDividendPayout } from "@features/operations/dividend-payouts/models/IListItemDividendPayout";

@Injectable()
export class AdminService {
  constructor(private http: HttpClient, private configService: ConfigService) {}

  getJobInfo(): Observable<IJobInfo> {
    return this.http.get<IJobInfo>(
      `${this.configService.config.apiBaseurl}/api/Reporting/BackgroundJobInfos/GetLastRunInfo`
    );
  }

  getTodaysCoupons(): Observable<IPagingHttpResponse<IListItemBondPayoutOperations>> {
    const params = {
      pageIndex: 0,
      pageSize: 5,
      "filterItem.settlementDate": formatDate(new Date(), "MM/dd/yyyy")
    } as any;
    return this.http.get<IPagingHttpResponse<IListItemBondPayoutOperations>>(
      `${this.configService.config.apiBaseurl}/api/BondPayoutOperations`,
      {
        params
      }
    );
  }

  getTodaysDividendPayouts(): Observable<IPagingHttpResponse<IListItemDividendPayout>> {
    const params = {
      pageIndex: 0,
      pageSize: 5,
      "filterItem.paymentDate": formatDate(new Date(), "MM/dd/yyyy")
    } as any;
    return this.http.get<IPagingHttpResponse<IListItemDividendPayout>>(
      `${this.configService.config.apiBaseurl}/api/DividendPayouts`,
      {
        params
      }
    );
  }
}
