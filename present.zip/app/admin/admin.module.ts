import { NgModule } from "@angular/core";
import { SharedModule } from "@shared/shared.module";
import { AdminRoutingModule } from "./admin-routing.module";

import { AdminComponent } from "./admin.component";
import { WelcomeComponent } from "./welcome/welcome.component";

import { AdminService } from "./services/admin.service";

@NgModule({
  declarations: [AdminComponent, WelcomeComponent],
  imports: [SharedModule, AdminRoutingModule],
  providers: [AdminService]
})
export class AdminModule {}
