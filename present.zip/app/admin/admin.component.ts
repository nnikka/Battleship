import { Component, OnInit } from "@angular/core";
import { SideBarMenuItem } from "@shared/components/layout/models/side-bar-menu";
import { slideInAnimation } from "src/app/general/animations/routes.animation";
import { AuthService } from "@auth/services/auth.service";
import { Roles } from "@core/models/roles.enum";
import { FilterSideBarItemsHelper } from "@shared/components/layout/helper/filter-side-bar-items.helper";

@Component({
  templateUrl: "./admin.component.html",
  animations: [slideInAnimation]
})
export class AdminComponent implements OnInit {
  sideBarMenuItems: SideBarMenuItem[] = [
    {
      key: "#staticData",
      parent: true,
      expanded: false,
      icon: "database",
      text: "Static data",
      children: [
        {
          link: "/admin/static-data/clients",
          text: "Clients",
          icon: "user-friends"
        },
        {
          link: "/admin/static-data/bonds",
          text: "Bonds",
          icon: "money-check-alt"
        },
        {
          link: "/admin/static-data/stocks",
          text: "Stocks",
          icon: "industry"
        },
        {
          link: "/admin/static-data/currencies",
          text: "Currency",
          icon: "funnel-dollar"
        },
        {
          link: "/admin/static-data/commissions",
          text: "Commissions",
          icon: "cut"
        },
        {
          link: "/admin/static-data/reference-rates",
          text: "Reference rates",
          icon: "percentage"
        },
        {
          link: "/admin/static-data/fx-instruments",
          text: "FX instruments",
          icon: "hand-holding-usd"
        },
        {
          link: "/admin/static-data/vesting-parameters",
          text: "Vesting parameters",
          icon: "chart-pie"
        }
      ]
    },
    {
      key: "#operations",
      parent: true,
      expanded: false,
      text: "Operations",
      icon: "exchange-alt",
      children: [
        {
          link: "/admin/operations/bonds",
          text: "Bonds",
          icon: "money-check-alt"
        },
        {
          link: "/admin/operations/bond-payouts",
          text: "Bond payouts",
          icon: "money-bill-wave"
        },
        {
          link: "/admin/operations/stocks",
          text: "Stocks",
          icon: "industry"
        },
        {
          link: "/admin/operations/dividend-payouts",
          text: "Dividend payouts",
          icon: "dollar-sign"
        },
        {
          link: "/admin/operations/fx",
          text: "FX",
          icon: "sync"
        },
        {
          link: "/admin/operations/cash",
          text: "Cash",
          icon: "money-bill"
        },
        {
          link: "/admin/operations/pledge",
          text: "Pledge",
          icon: "handshake"
        }
      ]
    },
    {
      key: "#reporting",
      parent: true,
      expanded: false,
      text: "Reporting",
      icon: "chart-bar",
      children: [
        {
          key: "#balances",
          parent: true,
          expanded: false,
          text: "Balances",
          icon: "balance-scale-right",
          children: [
            {
              link: "/admin/reporting/client-balances",
              text: "Cash",
              icon: "money-bill"
            },
            {
              link: "/admin/reporting/client-balances/stock-balances",
              text: "Stock",
              icon: "industry"
            },
            {
              link: "/admin/reporting/client-balances/bond-balances",
              text: "Bond",
              icon: "money-check-alt"
            }
          ]
        }
      ]
    },
    {
      key: "#settings",
      parent: true,
      expanded: false,
      text: "Settings",
      icon: "cogs",
      children: [
        {
          link: "/admin/settings/user-management",
          text: "Users",
          icon: "users",
          rolesRequired: [Roles.Admin]
        },
        {
          link: "/admin/settings/profile/change-password",
          text: "Change password",
          icon: "lock"
        }
      ]
    }
  ];

  get filteredSideBarItems(): SideBarMenuItem[] {
    return FilterSideBarItemsHelper.filter(this.sideBarMenuItems, this.authService.getUserRoles());
  }

  userName: string;

  constructor(private authService: AuthService) {}

  ngOnInit() {
    this.userName = this.authService.getUserFullName();
  }
}
