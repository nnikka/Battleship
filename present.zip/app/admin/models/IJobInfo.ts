export interface IJobInfo {
  date: string;
  isSkiped: boolean;
  isSuccess: boolean;
}
