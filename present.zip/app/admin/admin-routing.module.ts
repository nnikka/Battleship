import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";

import { AdminComponent } from "./admin.component";
import { WelcomeComponent } from "./welcome/welcome.component";

import { LoginRequiredGuard } from "@auth/guards/login-required.guard";

const routes: Routes = [
  {
    path: "",
    component: AdminComponent,
    children: [
      {
        path: "",
        component: WelcomeComponent,
        canActivate: [LoginRequiredGuard]
      },
      {
        path: "static-data",
        children: [
          {
            path: "clients",
            loadChildren: () => import("@features/static-data/clients/clients.module").then(m => m.ClientsModule),
            data: { title: "Static Data - Clients" }
          },
          {
            path: "stocks",
            loadChildren: () => import("@features/static-data/stocks/stocks.module").then(m => m.StocksModule),
            data: { title: "Static Data - Stocks" }
          },
          {
            path: "currencies",
            loadChildren: () =>
              import("@features/static-data/currencies/currencies.module").then(m => m.CurrenciesModule),
            data: { title: "Static Data - Currencies" }
          },
          {
            path: "bonds",
            loadChildren: () => import("@features/static-data/bonds/bonds.module").then(m => m.BondsModule),
            data: { title: "Static Data - Bonds" }
          },
          {
            path: "reference-rates",
            loadChildren: () =>
              import("@features/static-data/reference-rates/reference-rates.module").then(m => m.ReferenceRatesModule),
            data: { title: "Static Data - Reference rates" }
          },
          {
            path: "fx-instruments",
            loadChildren: () =>
              import("@features/static-data/fx-instruments/fx-instruments.module").then(m => m.FxInstrumentsModule),
            data: { title: "Static Data - FX instruments" }
          },
          {
            path: "commissions",
            loadChildren: () =>
              import("@features/static-data/commissions/commissions.module").then(m => m.CommissionsModule),
            data: { title: "Static Data - Commissions" }
          },
          {
            path: "vesting-parameters",
            loadChildren: () =>
              import("@features/static-data/vesting-parameters/vesting-parameters.module").then(
                m => m.VestingParametersModule
              ),
            data: { title: "Static Data - Vesting parameters" }
          }
        ]
      },
      {
        path: "operations",
        children: [
          {
            path: "bonds",
            loadChildren: () =>
              import("@features/operations/bond-operations/bond-operations.module").then(m => m.BondOperationsModule),
            data: { title: "Operations - Bonds" }
          },
          {
            path: "dividend-payouts",
            loadChildren: () =>
              import("@features/operations/dividend-payouts/dividend-payouts.module").then(
                m => m.DividendPayoutsModule
              ),
            data: { title: "Operations - Dividend payouts" }
          },
          {
            path: "stocks",
            loadChildren: () =>
              import("@features/operations/stock-operations/stock-operations.module").then(
                m => m.StockOperationsModule
              ),
            data: { title: "Operations - Stocks" }
          },
          {
            path: "bond-payouts",
            loadChildren: () =>
              import("@features/operations/bond-payouts/bond-payouts.module").then(m => m.BondPayoutsModule),
            data: { title: "Operations - Bond payouts" }
          },
          {
            path: "fx",
            loadChildren: () =>
              import("@features/operations/fx-operations/fx-operations.module").then(m => m.FxOperationsModule),
            data: { title: "Operations - Fx" }
          },
          {
            path: "cash",
            loadChildren: () =>
              import("@features/operations/cash-operations/cash-operations.module").then(m => m.CashOperationsModule),
            data: { title: "Operations - Cash" }
          },
          {
            path: "pledge",
            loadChildren: () =>
              import("@features/operations/pledge-operations/pledge-operations.module").then(
                m => m.PledgeOperationsModule
              ),
            data: { title: "Operations - pledge" }
          }
        ]
      },
      {
        path: "reporting",
        children: [
          {
            path: "client-balances",
            loadChildren: () =>
              import("@features/reporting/client-balances/client-balances.module").then(m => m.ClientBalancesModule),
            data: { title: "Reporting" }
          }
        ]
      },
      {
        path: "settings",
        loadChildren: () => import("@features/settings/settings.module").then(m => m.SettingsModule),
        data: { title: "Settings" }
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule {}
