import { Component, OnInit } from "@angular/core";
import { timer } from "rxjs";
import { AuthService } from "@auth/services/auth.service";
import { Router } from "@angular/router";
import { LoginRedirectService } from "@auth/services/login-redirect.service";
import { ConfigService } from "@env/service/config.service";
import { LazyLoadModuleLoading } from "@core/services/lazy-load-modules-loading.service";
import { RouterExtService } from "@core/services/router-ext.service";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.scss"]
})
export class AppComponent implements OnInit {
  constructor(
    private authService: AuthService,
    private loginRedirectService: LoginRedirectService,
    private routerExtService: RouterExtService,
    private router: Router,
    private lazyLoadModuleLoading: LazyLoadModuleLoading,
    private configService: ConfigService
  ) {}

  ngOnInit(): void {
    // console.log("API base url -------------> ", this.configService.config.apiBaseurl)
    this.lazyLoadModuleLoading.startCounting();
    timer(0, 1000).subscribe(() => {
      if (this.authService.getUser() != null && !this.authService.isAuthenticated()) {
        this.authService.clearUser();
        this.loginRedirectService.set(this.router.url);
        this.router.navigateByUrl("/auth/login");
      }
    });
  }
}
